import type { BlogPost } from "@/types/blog"

// Simulated blog posts data
const blogPosts: BlogPost[] = [
  {
    id: 1,
    title: "Los beneficios de la proteína de suero para el desarrollo muscular",
    slug: "beneficios-proteina-suero",
    excerpt:
      "Descubre por qué la proteína de suero es considerada una de las mejores opciones para el desarrollo muscular y la recuperación post-entrenamiento.",
    content:
      "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed euismod, nisl vel ultricies lacinia, nisl nisl aliquam nisl, eget aliquam nisl nisl sit amet nisl. Sed euismod, nisl vel ultricies lacinia, nisl nisl aliquam nisl, eget aliquam nisl nisl sit amet nisl.",
    image: "/placeholder.svg?height=600&width=800&query=fitness%20protein%20shake%20muscle%20building",
    date: "15 de abril, 2025",
    author: "Carlos Méndez",
  },
  {
    id: 2,
    title: "Guía completa sobre la creatina: mitos y realidades",
    slug: "guia-creatina-mitos-realidades",
    excerpt:
      "Analizamos los mitos más comunes sobre la creatina y te explicamos cómo utilizarla correctamente para maximizar tus resultados.",
    content:
      "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed euismod, nisl vel ultricies lacinia, nisl nisl aliquam nisl, eget aliquam nisl nisl sit amet nisl. Sed euismod, nisl vel ultricies lacinia, nisl nisl aliquam nisl, eget aliquam nisl nisl sit amet nisl.",
    image: "/placeholder.svg?height=600&width=800&query=creatine%20supplement%20fitness",
    date: "2 de abril, 2025",
    author: "María Rodríguez",
  },
  {
    id: 3,
    title: "Nutrición pre y post entrenamiento: optimiza tu rendimiento",
    slug: "nutricion-pre-post-entrenamiento",
    excerpt:
      "Aprende qué alimentos y suplementos consumir antes y después de entrenar para maximizar tu rendimiento y recuperación.",
    content:
      "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed euismod, nisl vel ultricies lacinia, nisl nisl aliquam nisl, eget aliquam nisl nisl sit amet nisl. Sed euismod, nisl vel ultricies lacinia, nisl nisl aliquam nisl, eget aliquam nisl nisl sit amet nisl.",
    image: "/placeholder.svg?height=600&width=800&query=pre%20workout%20meal%20fitness%20nutrition",
    date: "28 de marzo, 2025",
    author: "Juan Pérez",
  },
]

// Simulated API function
export async function getBlogPosts(): Promise<BlogPost[]> {
  // Simulate API delay
  await new Promise((resolve) => setTimeout(resolve, 500))
  return blogPosts
}

export async function getBlogPostBySlug(slug: string): Promise<BlogPost | undefined> {
  // Simulate API delay
  await new Promise((resolve) => setTimeout(resolve, 500))
  return blogPosts.find((post) => post.slug === slug)
}
