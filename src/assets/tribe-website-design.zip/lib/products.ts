import type { Product } from "@/types/product"

// Simulated API response
const products: Product[] = [
  {
    id: 1,
    name: "Whey Protein Premium",
    brand: "Optimum Nutrition",
    price: 2499.99,
    description:
      "Proteína de suero de leche de alta calidad con 24g de proteína por porción. Ideal para recuperación muscular y crecimiento.",
    image: "/whey-protein-gold.png",
    category: "Proteínas",
    categorySlug: "proteinas",
    featured: true,
    stock: 15,
  },
  {
    id: 2,
    name: "Creatina Monohidrato",
    brand: "MuscleTech",
    price: 1299.99,
    description:
      "Creatina monohidrato pura para aumentar la fuerza, potencia y rendimiento durante entrenamientos de alta intensidad.",
    image: "/creatine-black-jar.png",
    category: "Creatina",
    categorySlug: "creatina",
    featured: true,
    stock: 20,
  },
  {
    id: 3,
    name: "Multivitamínico Deportivo",
    brand: "Universal Nutrition",
    price: 899.99,
    description: "Fórmula completa de vitaminas y minerales diseñada específicamente para atletas y personas activas.",
    image: "/vitamin-white-bottle.png",
    category: "Vitaminas y Minerales",
    categorySlug: "vitaminas-minerales",
    featured: false,
    stock: 30,
  },
  {
    id: 4,
    name: "Pre-Entreno Explosive",
    brand: "Cellucor",
    price: 1599.99,
    description:
      "Fórmula pre-entrenamiento con cafeína, beta-alanina y creatina para máxima energía, enfoque y bombeo muscular.",
    image: "/pre-workout-black.png",
    category: "Pre-Entrenos",
    categorySlug: "pre-entrenos",
    featured: true,
    stock: 12,
  },
  {
    id: 5,
    name: "BCAA 2:1:1",
    brand: "Scivation",
    price: 1199.99,
    description:
      "Aminoácidos de cadena ramificada en proporción 2:1:1 para recuperación muscular y reducción del catabolismo.",
    image: "/bcaa-blue-container.png",
    category: "Aminoácidos",
    categorySlug: "aminoacidos",
    featured: false,
    stock: 25,
  },
  {
    id: 6,
    name: "Proteína Vegana",
    brand: "Vega Sport",
    price: 1899.99,
    description:
      "Proteína 100% vegetal a base de guisante, arroz y cáñamo. Ideal para atletas con dietas basadas en plantas.",
    image: "/vegan-protein-container.png",
    category: "Proteínas",
    categorySlug: "proteinas",
    featured: false,
    stock: 18,
  },
  {
    id: 7,
    name: "Omega 3 Fish Oil",
    brand: "NOW Foods",
    price: 799.99,
    description:
      "Ácidos grasos esenciales EPA y DHA para salud cardiovascular, función cerebral y reducción de inflamación.",
    image: "/omega3-bottle.png",
    category: "Vitaminas y Minerales",
    categorySlug: "vitaminas-minerales",
    featured: false,
    stock: 40,
  },
  {
    id: 8,
    name: "Mass Gainer 1200",
    brand: "Dymatize",
    price: 1999.99,
    description: "Fórmula alta en calorías y proteínas para personas que buscan aumentar masa muscular y peso.",
    image: "/mass-gainer-container.png",
    category: "Proteínas",
    categorySlug: "proteinas",
    featured: true,
    stock: 10,
  },
]

// Simulated API functions
export async function getProducts(): Promise<Product[]> {
  // Simulate API delay
  await new Promise((resolve) => setTimeout(resolve, 500))
  return products
}

export async function getProductById(id: number): Promise<Product | undefined> {
  // Simulate API delay
  await new Promise((resolve) => setTimeout(resolve, 500))
  return products.find((product) => product.id === id)
}

export async function getProductsByCategory(categorySlug: string): Promise<Product[]> {
  // Simulate API delay
  await new Promise((resolve) => setTimeout(resolve, 500))
  return products.filter((product) => product.categorySlug === categorySlug)
}

export async function getFeaturedProducts(): Promise<Product[]> {
  // Simulate API delay
  await new Promise((resolve) => setTimeout(resolve, 500))
  return products.filter((product) => product.featured)
}

export async function getCategories() {
  // Simulate API delay
  await new Promise((resolve) => setTimeout(resolve, 500))

  const categories = products.reduce(
    (acc, product) => {
      if (!acc.some((cat) => cat.slug === product.categorySlug)) {
        acc.push({
          name: product.category,
          slug: product.categorySlug,
        })
      }
      acc.push({
        name: product.category,
        slug: product.categorySlug,
      })
      return acc
    },
    [] as { name: string; slug: string }[],
  )

  return categories
}
