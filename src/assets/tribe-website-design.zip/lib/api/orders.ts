import { createClient } from "@/lib/supabase/server"
import type { AddressData } from "@/types/database"

interface CreateOrderParams {
  userId?: string
  customerEmail: string
  customerName: string
  customerPhone?: string
  shippingAddress: AddressData
  billingAddress?: AddressData
  items: {
    productId: string
    productName: string
    productSku: string
    productImage?: string
    variantId?: string
    variantName?: string
    quantity: number
    unitPrice: number
    taxRate: number
  }[]
  shippingMethod?: string
  customerNotes?: string
}

export async function createOrder(params: CreateOrderParams) {
  const supabase = await createClient()

  // Calculate totals
  const subtotal = params.items.reduce((sum, item) => sum + item.unitPrice * item.quantity, 0)
  const taxAmount = params.items.reduce((sum, item) => {
    const itemTotal = item.unitPrice * item.quantity
    return sum + itemTotal * (item.taxRate / 100)
  }, 0)

  // Calculate shipping (free over 2000)
  const shippingAmount = subtotal >= 2000 ? 0 : 250
  const total = subtotal + taxAmount + shippingAmount

  // Generate order number
  const year = new Date().getFullYear()
  const { count } = await supabase
    .from("orders")
    .select("*", { count: "exact", head: true })
    .like("order_number", `${year}-%`)

  const orderNumber = `${year}-${String((count || 0) + 1).padStart(6, "0")}`

  // Create order
  const { data: order, error: orderError } = await supabase
    .from("orders")
    .insert({
      order_number: orderNumber,
      user_id: params.userId || null,
      customer_email: params.customerEmail,
      customer_name: params.customerName,
      customer_phone: params.customerPhone || null,
      shipping_address: params.shippingAddress,
      billing_address: params.billingAddress || null,
      use_shipping_for_billing: !params.billingAddress,
      status: "pending_payment",
      subtotal,
      tax_amount: taxAmount,
      shipping_amount: shippingAmount,
      discount_amount: 0,
      total,
      currency: "DOP",
      shipping_method: params.shippingMethod || "standard",
      customer_notes: params.customerNotes || null,
    })
    .select()
    .single()

  if (orderError) {
    console.error("Error creating order:", orderError)
    throw new Error("No se pudo crear el pedido")
  }

  // Create order items
  const orderItems = params.items.map((item) => ({
    order_id: order.id,
    product_id: item.productId,
    variant_id: item.variantId || null,
    product_name: item.productName,
    product_sku: item.productSku,
    product_image: item.productImage || null,
    variant_name: item.variantName || null,
    quantity: item.quantity,
    unit_price: item.unitPrice,
    tax_rate: item.taxRate,
    tax_amount: item.unitPrice * item.quantity * (item.taxRate / 100),
    discount_amount: 0,
    total: item.unitPrice * item.quantity * (1 + item.taxRate / 100),
  }))

  const { error: itemsError } = await supabase.from("order_items").insert(orderItems)

  if (itemsError) {
    console.error("Error creating order items:", itemsError)
    // Rollback order
    await supabase.from("orders").delete().eq("id", order.id)
    throw new Error("No se pudieron crear los items del pedido")
  }

  // Log status change
  await supabase.from("order_status_history").insert({
    order_id: order.id,
    status: "pending_payment",
    notes: "Pedido creado",
  })

  return order
}

export async function updateOrderStatus(orderId: string, status: string, notes?: string, userId?: string) {
  const supabase = await createClient()

  const { error } = await supabase
    .from("orders")
    .update({
      status,
      updated_at: new Date().toISOString(),
    })
    .eq("id", orderId)

  if (error) throw error

  // Log status change
  await supabase.from("order_status_history").insert({
    order_id: orderId,
    status,
    notes: notes || null,
    created_by: userId || null,
  })
}

export async function confirmPayment(
  orderId: string,
  paymentMethod: string,
  transactionId?: string,
  providerResponse?: Record<string, unknown>,
) {
  const supabase = await createClient()

  // Get order with items
  const { data: order } = await supabase
    .from("orders")
    .select(`
      *,
      items:order_items(*)
    `)
    .eq("id", orderId)
    .single()

  if (!order) throw new Error("Pedido no encontrado")

  // Create payment record
  const { error: paymentError } = await supabase.from("payments").insert({
    order_id: orderId,
    method: paymentMethod,
    status: "completed",
    amount: order.total,
    currency: "DOP",
    provider_transaction_id: transactionId || null,
    provider_response: providerResponse || null,
  })

  if (paymentError) throw paymentError

  for (const item of order.items || []) {
    const { error: stockError } = await supabase.rpc("decrement_stock", {
      p_product_id: item.product_id,
      p_quantity: item.quantity,
    })

    // If RPC doesn't exist, do it manually
    if (stockError) {
      await supabase
        .from("products")
        .update({
          stock: supabase.rpc("greatest", { a: 0, b: supabase.raw(`stock - ${item.quantity}`) }),
        })
        .eq("id", item.product_id)
    }
  }

  // Update order status
  await updateOrderStatus(orderId, "paid", `Pago confirmado via ${paymentMethod}`)

  // Create invoice
  const year = new Date().getFullYear()
  const { count } = await supabase
    .from("invoices")
    .select("*", { count: "exact", head: true })
    .eq("invoice_series", "A")

  const invoiceNumber = `A-${String((count || 0) + 1).padStart(8, "0")}`

  const billingAddress = order.use_shipping_for_billing
    ? order.shipping_address
    : order.billing_address || order.shipping_address

  await supabase.from("invoices").insert({
    order_id: orderId,
    invoice_number: invoiceNumber,
    invoice_series: "A",
    status: "paid",
    customer_name: order.customer_name,
    customer_email: order.customer_email,
    billing_address: billingAddress,
    subtotal: order.subtotal,
    tax_amount: order.tax_amount,
    total: order.total,
    currency: "DOP",
    issued_at: new Date().toISOString(),
    paid_at: new Date().toISOString(),
  })

  return order
}

export async function getOrderWithItems(orderId: string) {
  const supabase = await createClient()

  const { data: order, error } = await supabase
    .from("orders")
    .select(
      `
      *,
      items:order_items(*),
      payments(*),
      invoice:invoices(*),
      status_history:order_status_history(*)
    `,
    )
    .eq("id", orderId)
    .single()

  if (error) throw error

  return order
}

export async function validateStock(items: { productId: string; quantity: number }[]) {
  const supabase = await createClient()

  const productIds = items.map((i) => i.productId)

  const { data: products } = await supabase.from("products").select("id, name, stock").in("id", productIds)

  if (!products) return { valid: false, errors: ["No se pudieron verificar los productos"] }

  const errors: string[] = []

  for (const item of items) {
    const product = products.find((p) => p.id === item.productId)
    if (!product) {
      errors.push(`Producto no encontrado`)
    } else if (product.stock < item.quantity) {
      errors.push(`${product.name}: Solo hay ${product.stock} unidades disponibles`)
    }
  }

  return {
    valid: errors.length === 0,
    errors,
  }
}
