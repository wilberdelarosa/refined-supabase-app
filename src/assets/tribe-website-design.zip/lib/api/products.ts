import { createClient } from "@/lib/supabase/server"
import { createStaticClient } from "@/lib/supabase/static"
import type { Product, Category, Brand } from "@/types/database"

async function getClient() {
  try {
    return await createClient()
  } catch {
    // During static generation, cookies() will throw
    // Fall back to static client
    return createStaticClient()
  }
}

export async function getProductsForStatic(): Promise<{ id: string; slug: string }[]> {
  const supabase = createStaticClient()
  if (!supabase) return []

  const { data, error } = await supabase.from("products").select("id, slug").eq("active", true)

  if (error) {
    console.error("Error fetching products for static:", error)
    return []
  }

  return data || []
}

export async function getCategoriesForStatic(): Promise<{ slug: string }[]> {
  const supabase = createStaticClient()
  if (!supabase) return []

  const { data, error } = await supabase.from("categories").select("slug")

  if (error) {
    console.error("Error fetching categories for static:", error)
    return []
  }

  return data || []
}

export async function getProducts(): Promise<Product[]> {
  const supabase = await getClient()
  if (!supabase) return []

  const { data, error } = await supabase
    .from("products")
    .select(`
      *,
      category:categories(*),
      brand:brands(*)
    `)
    .eq("active", true)
    .order("created_at", { ascending: false })

  if (error) {
    console.error("Error fetching products:", error)
    return []
  }

  return data || []
}

export async function getProductBySlug(slug: string): Promise<Product | null> {
  const supabase = await getClient()
  if (!supabase) return null

  const { data, error } = await supabase
    .from("products")
    .select(`
      *,
      category:categories(*),
      brand:brands(*)
    `)
    .eq("slug", slug)
    .eq("active", true)
    .single()

  if (error) {
    console.error("Error fetching product:", error)
    return null
  }

  return data
}

export async function getProductById(id: string): Promise<Product | null> {
  const supabase = await getClient()
  if (!supabase) return null

  const { data, error } = await supabase
    .from("products")
    .select(`
      *,
      category:categories(*),
      brand:brands(*)
    `)
    .eq("id", id)
    .eq("active", true)
    .single()

  if (error) {
    console.error("Error fetching product:", error)
    return null
  }

  return data
}

export async function getProductsByCategory(categorySlug: string): Promise<Product[]> {
  const supabase = await getClient()
  if (!supabase) return []

  const { data: category } = await supabase.from("categories").select("id").eq("slug", categorySlug).single()

  if (!category) return []

  const { data, error } = await supabase
    .from("products")
    .select(`
      *,
      category:categories(*),
      brand:brands(*)
    `)
    .eq("category_id", category.id)
    .eq("active", true)
    .order("created_at", { ascending: false })

  if (error) {
    console.error("Error fetching products by category:", error)
    return []
  }

  return data || []
}

export async function getFeaturedProducts(): Promise<Product[]> {
  const supabase = await getClient()
  if (!supabase) return []

  const { data, error } = await supabase
    .from("products")
    .select(`
      *,
      category:categories(*),
      brand:brands(*)
    `)
    .eq("featured", true)
    .eq("active", true)
    .limit(8)

  if (error) {
    console.error("Error fetching featured products:", error)
    return []
  }

  return data || []
}

export async function getCategories(): Promise<Category[]> {
  const supabase = await getClient()
  if (!supabase) return []

  const { data, error } = await supabase.from("categories").select("*").order("name")

  if (error) {
    console.error("Error fetching categories:", error)
    return []
  }

  return data || []
}

export async function getBrands(): Promise<Brand[]> {
  const supabase = await getClient()
  if (!supabase) return []

  const { data, error } = await supabase.from("brands").select("*").order("name")

  if (error) {
    console.error("Error fetching brands:", error)
    return []
  }

  return data || []
}

export async function searchProducts(query: string): Promise<Product[]> {
  const supabase = await getClient()
  if (!supabase) return []

  const { data, error } = await supabase
    .from("products")
    .select(`
      *,
      category:categories(*),
      brand:brands(*)
    `)
    .eq("active", true)
    .or(`name.ilike.%${query}%,description.ilike.%${query}%`)
    .limit(20)

  if (error) {
    console.error("Error searching products:", error)
    return []
  }

  return data || []
}
