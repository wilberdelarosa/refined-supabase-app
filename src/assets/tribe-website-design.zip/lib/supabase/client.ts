"use client"

import { createClient as createSupabaseClient } from "@supabase/supabase-js"

let supabaseInstance: ReturnType<typeof createSupabaseClient> | null = null

const noopStorage = {
  getItem: () => null,
  setItem: () => {},
  removeItem: () => {},
}

export function createClient() {
  if (typeof window === "undefined") {
    return null as unknown as ReturnType<typeof createSupabaseClient>
  }

  if (supabaseInstance) {
    return supabaseInstance
  }

  supabaseInstance = createSupabaseClient(
    process.env.NEXT_PUBLIC_SUPABASE_URL!,
    process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!,
    {
      auth: {
        storage: noopStorage,
        persistSession: false,
        autoRefreshToken: false,
        detectSessionInUrl: false,
      },
    },
  )

  return supabaseInstance
}

export const createBrowserClient = createClient
