"use client"

import type React from "react"
import { createContext, useContext, useState, useCallback, useMemo } from "react"
import type { User, Session } from "@supabase/supabase-js"
import type { Profile, Role } from "@/types/database"

interface AuthContextType {
  user: User | null
  profile: Profile | null
  role: Role | null
  session: Session | null
  isLoading: boolean
  isAdmin: boolean
  isManager: boolean
  isEditor: boolean
  isSupport: boolean
  hasPermission: (permission: string) => boolean
  signIn: (email: string, password: string) => Promise<{ error: Error | null }>
  signUp: (email: string, password: string, fullName: string) => Promise<{ error: Error | null }>
  signOut: () => Promise<void>
  refreshProfile: () => Promise<void>
}

const AuthContext = createContext<AuthContextType | undefined>(undefined)

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [user, setUser] = useState<User | null>(null)
  const [profile, setProfile] = useState<Profile | null>(null)
  const [role, setRole] = useState<Role | null>(null)
  const [session, setSession] = useState<Session | null>(null)
  const [isLoading, setIsLoading] = useState(false)

  const getSupabase = useCallback(async () => {
    if (typeof window === "undefined") return null
    const { createClient } = await import("@/lib/supabase/client")
    return createClient()
  }, [])

  const fetchProfile = useCallback(
    async (userId: string) => {
      const supabase = await getSupabase()
      if (!supabase) return

      try {
        const { data, error } = await supabase.from("profiles").select(`*, role:roles(*)`).eq("id", userId).single()

        if (!error && data) {
          setProfile(data)
          setRole(data.role || null)
        }
      } catch (error) {
        console.error("Error fetching profile:", error)
      }
    },
    [getSupabase],
  )

  const refreshProfile = useCallback(async () => {
    if (user) {
      await fetchProfile(user.id)
    }
  }, [user, fetchProfile])

  const signIn = useCallback(
    async (email: string, password: string) => {
      setIsLoading(true)
      try {
        const supabase = await getSupabase()
        if (!supabase) return { error: new Error("Not available") }

        const { data, error } = await supabase.auth.signInWithPassword({ email, password })

        if (!error && data.user) {
          setUser(data.user)
          setSession(data.session)
          await fetchProfile(data.user.id)
        }

        return { error }
      } catch (error) {
        return { error: error as Error }
      } finally {
        setIsLoading(false)
      }
    },
    [getSupabase, fetchProfile],
  )

  const signUp = useCallback(
    async (email: string, password: string, fullName: string) => {
      setIsLoading(true)
      try {
        const supabase = await getSupabase()
        if (!supabase) return { error: new Error("Not available") }

        const { error } = await supabase.auth.signUp({
          email,
          password,
          options: {
            data: { full_name: fullName },
            emailRedirectTo:
              process.env.NEXT_PUBLIC_DEV_SUPABASE_REDIRECT_URL ||
              (typeof window !== "undefined" ? window.location.origin : ""),
          },
        })
        return { error }
      } catch (error) {
        return { error: error as Error }
      } finally {
        setIsLoading(false)
      }
    },
    [getSupabase],
  )

  const signOut = useCallback(async () => {
    const supabase = await getSupabase()
    if (supabase) {
      await supabase.auth.signOut()
    }
    setUser(null)
    setProfile(null)
    setRole(null)
    setSession(null)
  }, [getSupabase])

  const hasPermission = useCallback(
    (permission: string): boolean => {
      if (!role) return false
      if (role.permissions.includes("*")) return true
      if (role.permissions.includes(permission)) return true

      const permissionParts = permission.split(".")
      for (const perm of role.permissions) {
        if (perm.endsWith(".*")) {
          const permBase = perm.slice(0, -2)
          if (permission.startsWith(permBase)) return true
        }
      }

      return false
    },
    [role],
  )

  const isAdmin = role?.key === "admin"
  const isManager = role?.key === "manager" || isAdmin
  const isEditor = role?.key === "editor" || isAdmin
  const isSupport = role?.key === "support" || isAdmin

  const value = useMemo(
    () => ({
      user,
      profile,
      role,
      session,
      isLoading,
      isAdmin,
      isManager,
      isEditor,
      isSupport,
      hasPermission,
      signIn,
      signUp,
      signOut,
      refreshProfile,
    }),
    [
      user,
      profile,
      role,
      session,
      isLoading,
      isAdmin,
      isManager,
      isEditor,
      isSupport,
      hasPermission,
      signIn,
      signUp,
      signOut,
      refreshProfile,
    ],
  )

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>
}

export function useAuth() {
  const context = useContext(AuthContext)
  if (context === undefined) {
    throw new Error("useAuth must be used within an AuthProvider")
  }
  return context
}
