"use client"

import type React from "react"

import { useEffect } from "react"
import { useRouter } from "next/navigation"
import { useAuth } from "./auth-context"
import { Loader2 } from "lucide-react"

interface RequireAuthProps {
  children: React.ReactNode
  requiredRole?: string[]
  requiredPermission?: string
  redirectTo?: string
}

export function RequireAuth({
  children,
  requiredRole,
  requiredPermission,
  redirectTo = "/cuenta/iniciar-sesion",
}: RequireAuthProps) {
  const { user, role, isLoading, hasPermission } = useAuth()
  const router = useRouter()

  useEffect(() => {
    if (!isLoading) {
      if (!user) {
        router.push(redirectTo)
        return
      }

      if (requiredRole && role && !requiredRole.includes(role.key)) {
        router.push("/")
        return
      }

      if (requiredPermission && !hasPermission(requiredPermission)) {
        router.push("/")
        return
      }
    }
  }, [user, role, isLoading, requiredRole, requiredPermission, hasPermission, router, redirectTo])

  if (isLoading) {
    return (
      <div className="flex min-h-screen items-center justify-center">
        <Loader2 className="h-8 w-8 animate-spin text-muted-foreground" />
      </div>
    )
  }

  if (!user) {
    return null
  }

  if (requiredRole && role && !requiredRole.includes(role.key)) {
    return null
  }

  if (requiredPermission && !hasPermission(requiredPermission)) {
    return null
  }

  return <>{children}</>
}
