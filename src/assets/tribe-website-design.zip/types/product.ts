export interface Product {
  id: number
  name: string
  brand: string
  price: number
  description: string
  image: string
  category: string
  categorySlug: string
  featured: boolean
  stock: number
}
