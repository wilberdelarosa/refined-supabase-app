// =====================================================
// TIPOS DE BASE DE DATOS - E-COMMERCE COMPLETO
// =====================================================

// Roles y permisos
export interface Role {
  id: string
  key: string
  name: string
  description: string | null
  permissions: string[]
  created_at: string
}

// Perfil de usuario
export interface Profile {
  id: string
  email: string
  full_name: string | null
  phone: string | null
  document_id: string | null
  document_type: string | null
  avatar_url: string | null
  role_id: string | null
  email_verified: boolean
  is_active: boolean
  preferences: Record<string, unknown>
  created_at: string
  updated_at: string
  role?: Role
}

// Direcciones
export interface Address {
  id: string
  user_id: string
  label: string
  full_name: string
  phone: string | null
  street_address: string
  street_address_2: string | null
  city: string
  province: string
  postal_code: string | null
  country: string
  is_default_shipping: boolean
  is_default_billing: boolean
  instructions: string | null
  created_at: string
  updated_at: string
}

// Categorías
export interface Category {
  id: string
  name: string
  slug: string
  description: string | null
  image_url: string | null
  parent_id: string | null
  sort_order: number
  is_active: boolean
  created_at: string
}

// Marcas
export interface Brand {
  id: string
  name: string
  slug: string
  logo_url: string | null
  description: string | null
  website: string | null
  is_active: boolean
  created_at: string
}

// Productos
export interface Product {
  id: string
  sku: string
  name: string
  slug: string
  brand_id: string | null
  category_id: string | null
  short_description: string | null
  description: string | null
  price: number
  compare_at_price: number | null
  cost_price: number | null
  tax_rate: number
  stock: number
  low_stock_threshold: number
  weight: number | null
  status: "draft" | "published" | "archived"
  is_featured: boolean
  meta_title: string | null
  meta_description: string | null
  created_at: string
  updated_at: string
  // Relaciones
  category?: Category
  brand?: Brand
  images?: ProductImage[]
  variants?: ProductVariant[]
}

export interface ProductImage {
  id: string
  product_id: string
  url: string
  alt_text: string | null
  sort_order: number
  is_primary: boolean
  created_at: string
}

export interface ProductVariant {
  id: string
  product_id: string
  sku: string
  name: string
  option_type: string | null
  option_value: string | null
  price_adjustment: number
  stock: number
  is_active: boolean
  created_at: string
}

// Pedidos
export type OrderStatus =
  | "draft"
  | "pending_payment"
  | "paid"
  | "processing"
  | "packed"
  | "shipped"
  | "delivered"
  | "cancelled"
  | "refunded"
  | "partially_refunded"

export interface Order {
  id: string
  order_number: string
  user_id: string | null
  customer_email: string
  customer_name: string
  customer_phone: string | null
  shipping_address: AddressData
  billing_address: AddressData | null
  use_shipping_for_billing: boolean
  status: OrderStatus
  subtotal: number
  tax_amount: number
  shipping_amount: number
  discount_amount: number
  total: number
  currency: string
  shipping_method: string | null
  tracking_number: string | null
  tracking_url: string | null
  shipped_at: string | null
  delivered_at: string | null
  customer_notes: string | null
  internal_notes: string | null
  ip_address: string | null
  user_agent: string | null
  created_at: string
  updated_at: string
  // Relaciones
  items?: OrderItem[]
  payments?: Payment[]
  invoice?: Invoice
  status_history?: OrderStatusHistory[]
}

export interface AddressData {
  full_name: string
  phone?: string
  street_address: string
  street_address_2?: string
  city: string
  province: string
  postal_code?: string
  country: string
  instructions?: string
}

export interface OrderItem {
  id: string
  order_id: string
  product_id: string | null
  variant_id: string | null
  product_name: string
  product_sku: string
  product_image: string | null
  variant_name: string | null
  quantity: number
  unit_price: number
  tax_rate: number
  tax_amount: number
  discount_amount: number
  total: number
  created_at: string
}

export interface OrderStatusHistory {
  id: string
  order_id: string
  status: string
  notes: string | null
  created_by: string | null
  created_at: string
}

// Pagos
export type PaymentMethod = "paypal" | "card" | "bank_transfer" | "cash_on_delivery"
export type PaymentStatus = "pending" | "processing" | "completed" | "failed" | "refunded" | "partially_refunded"

export interface Payment {
  id: string
  order_id: string
  method: PaymentMethod
  status: PaymentStatus
  amount: number
  currency: string
  provider_transaction_id: string | null
  provider_response: Record<string, unknown> | null
  refunded_amount: number
  created_at: string
  updated_at: string
}

// Facturas
export type InvoiceStatus = "draft" | "issued" | "paid" | "cancelled" | "credit_note"

export interface Invoice {
  id: string
  order_id: string | null
  invoice_number: string
  invoice_series: string
  status: InvoiceStatus
  customer_name: string
  customer_email: string
  customer_document: string | null
  customer_document_type: string | null
  billing_address: AddressData
  subtotal: number
  tax_amount: number
  total: number
  currency: string
  pdf_url: string | null
  related_invoice_id: string | null
  issued_at: string | null
  due_at: string | null
  paid_at: string | null
  cancelled_at: string | null
  notes: string | null
  created_at: string
  updated_at: string
  // Relaciones
  lines?: InvoiceLine[]
}

export interface InvoiceLine {
  id: string
  invoice_id: string
  description: string
  quantity: number
  unit_price: number
  tax_rate: number
  tax_amount: number
  total: number
  created_at: string
}

// Blog / CMS
export interface BlogPost {
  id: string
  title: string
  slug: string
  excerpt: string | null
  content: string | null
  featured_image: string | null
  author_id: string | null
  category: string | null
  tags: string[]
  status: "draft" | "published" | "archived"
  published_at: string | null
  meta_title: string | null
  meta_description: string | null
  view_count: number
  created_at: string
  updated_at: string
  // Relaciones
  author?: Profile
}

export interface Page {
  id: string
  title: string
  slug: string
  content: string | null
  template: string
  status: "draft" | "published"
  meta_title: string | null
  meta_description: string | null
  created_at: string
  updated_at: string
}

export interface Banner {
  id: string
  title: string
  subtitle: string | null
  image_url: string
  link_url: string | null
  button_text: string | null
  position: string
  sort_order: number
  is_active: boolean
  starts_at: string | null
  ends_at: string | null
  created_at: string
}

// Tickets de soporte
export type TicketStatus = "open" | "in_progress" | "waiting_customer" | "resolved" | "closed"
export type TicketPriority = "low" | "normal" | "high" | "urgent"

export interface SupportTicket {
  id: string
  ticket_number: string
  user_id: string | null
  order_id: string | null
  subject: string
  message: string
  status: TicketStatus
  priority: TicketPriority
  assigned_to: string | null
  created_at: string
  updated_at: string
  // Relaciones
  messages?: TicketMessage[]
  user?: Profile
  order?: Order
}

export interface TicketMessage {
  id: string
  ticket_id: string
  user_id: string | null
  message: string
  is_internal: boolean
  attachments: string[]
  created_at: string
  // Relaciones
  user?: Profile
}

// Audit Log
export interface AuditLog {
  id: string
  user_id: string | null
  action: string
  entity_type: string
  entity_id: string | null
  old_values: Record<string, unknown> | null
  new_values: Record<string, unknown> | null
  ip_address: string | null
  user_agent: string | null
  created_at: string
  // Relaciones
  user?: Profile
}

// Configuración de tienda
export interface StoreSetting {
  id: string
  key: string
  value: unknown
  description: string | null
  updated_at: string
}

// Cupones
export interface Coupon {
  id: string
  code: string
  description: string | null
  discount_type: "percentage" | "fixed_amount"
  discount_value: number
  minimum_order_amount: number | null
  maximum_discount_amount: number | null
  usage_limit: number | null
  usage_count: number
  usage_limit_per_user: number
  is_active: boolean
  starts_at: string | null
  expires_at: string | null
  created_at: string
}

// Carrito (cliente)
export interface CartItem {
  product: Product
  variant?: ProductVariant
  quantity: number
}

// Movimientos de inventario
export interface InventoryMovement {
  id: string
  product_id: string
  variant_id: string | null
  type: "purchase" | "sale" | "adjustment" | "return" | "damaged"
  quantity: number
  reference_type: string | null
  reference_id: string | null
  notes: string | null
  created_by: string | null
  created_at: string
}
