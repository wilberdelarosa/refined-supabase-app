import { redirect } from "next/navigation"
import { createClient } from "@/lib/supabase/server"
import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { ArrowLeft, FileText, Download } from "lucide-react"
import Link from "next/link"

async function getInvoices() {
  const supabase = await createClient()

  const {
    data: { user },
  } = await supabase.auth.getUser()

  if (!user) return []

  // Get invoices for user's orders
  const { data: orders } = await supabase.from("orders").select("id").eq("user_id", user.id)

  if (!orders || orders.length === 0) return []

  const orderIds = orders.map((o) => o.id)

  const { data: invoices, error } = await supabase
    .from("invoices")
    .select("*")
    .in("order_id", orderIds)
    .order("created_at", { ascending: false })

  if (error) {
    console.error("Error fetching invoices:", error)
    return []
  }

  return invoices || []
}

function formatCurrency(amount: number) {
  return new Intl.NumberFormat("es-DO", {
    style: "currency",
    currency: "DOP",
    minimumFractionDigits: 0,
  }).format(amount)
}

function formatDate(date: string) {
  return new Intl.DateTimeFormat("es-DO", {
    day: "numeric",
    month: "long",
    year: "numeric",
  }).format(new Date(date))
}

const statusConfig: Record<string, { label: string; color: string }> = {
  draft: { label: "Borrador", color: "bg-gray-100 text-gray-800" },
  issued: { label: "Emitida", color: "bg-blue-100 text-blue-800" },
  paid: { label: "Pagada", color: "bg-green-100 text-green-800" },
  cancelled: { label: "Anulada", color: "bg-red-100 text-red-800" },
}

export default async function InvoicesPage() {
  const supabase = await createClient()
  const {
    data: { user },
  } = await supabase.auth.getUser()

  if (!user) {
    redirect("/cuenta/iniciar-sesion?redirect=/cuenta/facturas")
  }

  const invoices = await getInvoices()

  return (
    <div className="container py-8 md:py-12">
      <div className="max-w-4xl mx-auto space-y-6">
        <div className="flex items-center gap-4">
          <Button asChild variant="ghost" size="icon">
            <Link href="/cuenta">
              <ArrowLeft className="h-5 w-5" />
            </Link>
          </Button>
          <div>
            <h1 className="text-2xl font-bold">Mis Facturas</h1>
            <p className="text-muted-foreground">Descarga tus comprobantes fiscales</p>
          </div>
        </div>

        {invoices.length === 0 ? (
          <Card>
            <CardContent className="py-12 text-center">
              <FileText className="h-12 w-12 mx-auto text-muted-foreground mb-4" />
              <h3 className="text-lg font-medium mb-2">No tienes facturas aún</h3>
              <p className="text-muted-foreground mb-4">
                Las facturas se generan automáticamente cuando realizas una compra
              </p>
              <Button asChild>
                <Link href="/tienda">Ir a la tienda</Link>
              </Button>
            </CardContent>
          </Card>
        ) : (
          <div className="space-y-4">
            {invoices.map((invoice) => (
              <Card key={invoice.id} className="hover:shadow-md transition-shadow">
                <CardContent className="p-6">
                  <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
                    <div className="flex items-center gap-4">
                      <div className="h-12 w-12 rounded-lg bg-muted flex items-center justify-center">
                        <FileText className="h-6 w-6 text-muted-foreground" />
                      </div>
                      <div>
                        <p className="font-semibold">Factura {invoice.invoice_number}</p>
                        <p className="text-sm text-muted-foreground">
                          {invoice.issued_at ? formatDate(invoice.issued_at) : "Sin emitir"}
                        </p>
                      </div>
                    </div>

                    <div className="flex items-center gap-4">
                      <div className="text-right">
                        <p className="font-semibold">{formatCurrency(invoice.total)}</p>
                        <span
                          className={`inline-flex items-center rounded-full px-2.5 py-0.5 text-xs font-medium ${statusConfig[invoice.status]?.color || "bg-gray-100"}`}
                        >
                          {statusConfig[invoice.status]?.label || invoice.status}
                        </span>
                      </div>
                      {invoice.pdf_url ? (
                        <Button asChild variant="outline" size="sm">
                          <a href={invoice.pdf_url} target="_blank" rel="noopener noreferrer">
                            <Download className="mr-2 h-4 w-4" />
                            Descargar
                          </a>
                        </Button>
                      ) : (
                        <Button variant="outline" size="sm" disabled>
                          <Download className="mr-2 h-4 w-4" />
                          No disponible
                        </Button>
                      )}
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        )}
      </div>
    </div>
  )
}
