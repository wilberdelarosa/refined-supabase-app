"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { useAuth } from "@/lib/auth/auth-context"
import { createClient } from "@/lib/supabase/client"
import type { Address } from "@/types/database"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Checkbox } from "@/components/ui/checkbox"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { ArrowLeft, Plus, Edit, Trash2, MapPin, Loader2 } from "lucide-react"
import Link from "next/link"
import { useToast } from "@/hooks/use-toast"

const provinces = [
  "Distrito Nacional",
  "Santo Domingo",
  "Santiago",
  "La Vega",
  "San Cristóbal",
  "Puerto Plata",
  "Duarte",
  "La Romana",
  "San Pedro de Macorís",
  "Espaillat",
  "La Altagracia",
  "Peravia",
  "Azua",
  "Barahona",
  "Monte Cristi",
  "Valverde",
  "Sánchez Ramírez",
  "Monseñor Nouel",
  "María Trinidad Sánchez",
  "Samaná",
]

export default function AddressesPage() {
  const { user } = useAuth()
  const { toast } = useToast()
  const [addresses, setAddresses] = useState<Address[]>([])
  const [isLoading, setIsLoading] = useState(true)
  const [isDialogOpen, setIsDialogOpen] = useState(false)
  const [editingAddress, setEditingAddress] = useState<Address | null>(null)
  const [isSaving, setIsSaving] = useState(false)

  const [formData, setFormData] = useState({
    label: "Casa",
    full_name: "",
    phone: "",
    street_address: "",
    street_address_2: "",
    city: "",
    province: "",
    postal_code: "",
    instructions: "",
    is_default_shipping: false,
    is_default_billing: false,
  })

  useEffect(() => {
    if (user) {
      fetchAddresses()
    }
  }, [user])

  const fetchAddresses = async () => {
    const supabase = createClient()
    const { data, error } = await supabase
      .from("addresses")
      .select("*")
      .eq("user_id", user?.id)
      .order("created_at", { ascending: false })

    if (!error && data) {
      setAddresses(data)
    }
    setIsLoading(false)
  }

  const resetForm = () => {
    setFormData({
      label: "Casa",
      full_name: "",
      phone: "",
      street_address: "",
      street_address_2: "",
      city: "",
      province: "",
      postal_code: "",
      instructions: "",
      is_default_shipping: false,
      is_default_billing: false,
    })
    setEditingAddress(null)
  }

  const handleEdit = (address: Address) => {
    setEditingAddress(address)
    setFormData({
      label: address.label,
      full_name: address.full_name,
      phone: address.phone || "",
      street_address: address.street_address,
      street_address_2: address.street_address_2 || "",
      city: address.city,
      province: address.province,
      postal_code: address.postal_code || "",
      instructions: address.instructions || "",
      is_default_shipping: address.is_default_shipping,
      is_default_billing: address.is_default_billing,
    })
    setIsDialogOpen(true)
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsSaving(true)

    const supabase = createClient()

    try {
      if (editingAddress) {
        const { error } = await supabase
          .from("addresses")
          .update({
            ...formData,
            updated_at: new Date().toISOString(),
          })
          .eq("id", editingAddress.id)

        if (error) throw error

        toast({ title: "Dirección actualizada" })
      } else {
        const { error } = await supabase.from("addresses").insert({
          ...formData,
          user_id: user?.id,
        })

        if (error) throw error

        toast({ title: "Dirección agregada" })
      }

      await fetchAddresses()
      setIsDialogOpen(false)
      resetForm()
    } catch {
      toast({
        title: "Error",
        description: "No se pudo guardar la dirección",
        variant: "destructive",
      })
    } finally {
      setIsSaving(false)
    }
  }

  const handleDelete = async (id: string) => {
    if (!confirm("¿Estás seguro de eliminar esta dirección?")) return

    const supabase = createClient()
    const { error } = await supabase.from("addresses").delete().eq("id", id)

    if (!error) {
      setAddresses(addresses.filter((a) => a.id !== id))
      toast({ title: "Dirección eliminada" })
    }
  }

  return (
    <div className="container py-8 md:py-12">
      <div className="max-w-4xl mx-auto space-y-6">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-4">
            <Button asChild variant="ghost" size="icon">
              <Link href="/cuenta">
                <ArrowLeft className="h-5 w-5" />
              </Link>
            </Button>
            <div>
              <h1 className="text-2xl font-bold">Mis Direcciones</h1>
              <p className="text-muted-foreground">Gestiona tus direcciones de envío</p>
            </div>
          </div>

          <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
            <DialogTrigger asChild>
              <Button
                onClick={() => {
                  resetForm()
                  setIsDialogOpen(true)
                }}
              >
                <Plus className="mr-2 h-4 w-4" />
                Nueva Dirección
              </Button>
            </DialogTrigger>
            <DialogContent className="max-w-lg max-h-[90vh] overflow-y-auto">
              <DialogHeader>
                <DialogTitle>{editingAddress ? "Editar Dirección" : "Nueva Dirección"}</DialogTitle>
                <DialogDescription>
                  {editingAddress ? "Actualiza los datos de tu dirección" : "Agrega una nueva dirección de envío"}
                </DialogDescription>
              </DialogHeader>

              <form onSubmit={handleSubmit} className="space-y-4">
                <div className="grid gap-4 md:grid-cols-2">
                  <div className="space-y-2">
                    <Label htmlFor="label">Etiqueta</Label>
                    <Select
                      value={formData.label}
                      onValueChange={(value) => setFormData({ ...formData, label: value })}
                    >
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="Casa">Casa</SelectItem>
                        <SelectItem value="Oficina">Oficina</SelectItem>
                        <SelectItem value="Otro">Otro</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="full_name">Nombre completo</Label>
                    <Input
                      id="full_name"
                      value={formData.full_name}
                      onChange={(e) => setFormData({ ...formData, full_name: e.target.value })}
                      required
                    />
                  </div>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="phone">Teléfono</Label>
                  <Input
                    id="phone"
                    type="tel"
                    value={formData.phone}
                    onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="street_address">Dirección</Label>
                  <Input
                    id="street_address"
                    value={formData.street_address}
                    onChange={(e) => setFormData({ ...formData, street_address: e.target.value })}
                    placeholder="Calle, número, sector"
                    required
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="street_address_2">Referencia (opcional)</Label>
                  <Input
                    id="street_address_2"
                    value={formData.street_address_2}
                    onChange={(e) => setFormData({ ...formData, street_address_2: e.target.value })}
                    placeholder="Apartamento, edificio, etc."
                  />
                </div>

                <div className="grid gap-4 md:grid-cols-2">
                  <div className="space-y-2">
                    <Label htmlFor="city">Ciudad</Label>
                    <Input
                      id="city"
                      value={formData.city}
                      onChange={(e) => setFormData({ ...formData, city: e.target.value })}
                      required
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="province">Provincia</Label>
                    <Select
                      value={formData.province}
                      onValueChange={(value) => setFormData({ ...formData, province: value })}
                    >
                      <SelectTrigger>
                        <SelectValue placeholder="Selecciona" />
                      </SelectTrigger>
                      <SelectContent>
                        {provinces.map((province) => (
                          <SelectItem key={province} value={province}>
                            {province}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                <div className="space-y-4">
                  <div className="flex items-center space-x-2">
                    <Checkbox
                      id="is_default_shipping"
                      checked={formData.is_default_shipping}
                      onCheckedChange={(checked) =>
                        setFormData({ ...formData, is_default_shipping: checked as boolean })
                      }
                    />
                    <label htmlFor="is_default_shipping" className="text-sm">
                      Usar como dirección de envío predeterminada
                    </label>
                  </div>

                  <div className="flex items-center space-x-2">
                    <Checkbox
                      id="is_default_billing"
                      checked={formData.is_default_billing}
                      onCheckedChange={(checked) =>
                        setFormData({ ...formData, is_default_billing: checked as boolean })
                      }
                    />
                    <label htmlFor="is_default_billing" className="text-sm">
                      Usar como dirección de facturación predeterminada
                    </label>
                  </div>
                </div>

                <div className="flex justify-end gap-2">
                  <Button type="button" variant="outline" onClick={() => setIsDialogOpen(false)}>
                    Cancelar
                  </Button>
                  <Button type="submit" disabled={isSaving}>
                    {isSaving ? (
                      <>
                        <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                        Guardando...
                      </>
                    ) : editingAddress ? (
                      "Actualizar"
                    ) : (
                      "Agregar"
                    )}
                  </Button>
                </div>
              </form>
            </DialogContent>
          </Dialog>
        </div>

        {isLoading ? (
          <div className="flex items-center justify-center py-12">
            <Loader2 className="h-8 w-8 animate-spin text-muted-foreground" />
          </div>
        ) : addresses.length === 0 ? (
          <Card>
            <CardContent className="py-12 text-center">
              <MapPin className="h-12 w-12 mx-auto text-muted-foreground mb-4" />
              <h3 className="text-lg font-medium mb-2">No tienes direcciones guardadas</h3>
              <p className="text-muted-foreground mb-4">Agrega una dirección para agilizar tus compras</p>
            </CardContent>
          </Card>
        ) : (
          <div className="grid gap-4 md:grid-cols-2">
            {addresses.map((address) => (
              <Card key={address.id}>
                <CardHeader className="pb-2">
                  <div className="flex items-center justify-between">
                    <CardTitle className="text-base flex items-center gap-2">
                      <MapPin className="h-4 w-4" />
                      {address.label}
                    </CardTitle>
                    <div className="flex gap-1">
                      <Button variant="ghost" size="icon" onClick={() => handleEdit(address)}>
                        <Edit className="h-4 w-4" />
                      </Button>
                      <Button
                        variant="ghost"
                        size="icon"
                        className="text-red-600"
                        onClick={() => handleDelete(address.id)}
                      >
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    </div>
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="text-sm space-y-1">
                    <p className="font-medium">{address.full_name}</p>
                    <p className="text-muted-foreground">{address.street_address}</p>
                    {address.street_address_2 && <p className="text-muted-foreground">{address.street_address_2}</p>}
                    <p className="text-muted-foreground">
                      {address.city}, {address.province}
                    </p>
                    {address.phone && <p className="text-muted-foreground">{address.phone}</p>}
                  </div>
                  <div className="flex gap-2 mt-3">
                    {address.is_default_shipping && (
                      <span className="text-xs bg-primary/10 text-primary px-2 py-1 rounded">Envío</span>
                    )}
                    {address.is_default_billing && (
                      <span className="text-xs bg-primary/10 text-primary px-2 py-1 rounded">Facturación</span>
                    )}
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        )}
      </div>
    </div>
  )
}
