import { redirect } from "next/navigation"
import { createClient } from "@/lib/supabase/server"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Package, MapPin, User, FileText, MessageSquare, Settings, ChevronRight } from "lucide-react"
import Link from "next/link"

async function getProfile() {
  const supabase = await createClient()

  const {
    data: { user },
  } = await supabase.auth.getUser()

  if (!user) return null

  const { data: profile } = await supabase.from("profiles").select("*").eq("id", user.id).single()

  return profile
}

async function getOrdersCount() {
  const supabase = await createClient()

  const {
    data: { user },
  } = await supabase.auth.getUser()

  if (!user) return 0

  const { count } = await supabase.from("orders").select("*", { count: "exact", head: true }).eq("user_id", user.id)

  return count || 0
}

const menuItems = [
  {
    title: "Mis Pedidos",
    description: "Ver historial de pedidos y seguimiento",
    href: "/cuenta/pedidos",
    icon: Package,
  },
  {
    title: "Mis Direcciones",
    description: "Gestionar direcciones de envío y facturación",
    href: "/cuenta/direcciones",
    icon: MapPin,
  },
  {
    title: "Mis Facturas",
    description: "Descargar facturas de tus compras",
    href: "/cuenta/facturas",
    icon: FileText,
  },
  {
    title: "Soporte",
    description: "Ver tickets de soporte y crear nuevos",
    href: "/cuenta/soporte",
    icon: MessageSquare,
  },
  {
    title: "Configuración",
    description: "Cambiar contraseña y preferencias",
    href: "/cuenta/configuracion",
    icon: Settings,
  },
]

export default async function AccountPage() {
  const profile = await getProfile()
  const ordersCount = await getOrdersCount()

  if (!profile) {
    redirect("/cuenta/iniciar-sesion")
  }

  return (
    <div className="container py-8 md:py-12">
      <div className="max-w-4xl mx-auto space-y-8">
        {/* Header */}
        <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
          <div>
            <h1 className="text-3xl font-bold">Mi Cuenta</h1>
            <p className="text-muted-foreground">Bienvenido, {profile.full_name || profile.email}</p>
          </div>
          <Button asChild variant="outline">
            <Link href="/cuenta/perfil">
              <User className="mr-2 h-4 w-4" />
              Editar Perfil
            </Link>
          </Button>
        </div>

        {/* Stats */}
        <div className="grid gap-4 md:grid-cols-3">
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium text-muted-foreground">Total de Pedidos</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{ordersCount}</div>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium text-muted-foreground">Estado</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-green-600">Activo</div>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium text-muted-foreground">Miembro desde</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">
                {new Intl.DateTimeFormat("es-DO", { month: "short", year: "numeric" }).format(
                  new Date(profile.created_at),
                )}
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Menu */}
        <div className="grid gap-4 md:grid-cols-2">
          {menuItems.map((item) => (
            <Link key={item.href} href={item.href}>
              <Card className="hover:bg-muted/50 transition-colors cursor-pointer h-full">
                <CardHeader>
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-4">
                      <div className="h-10 w-10 rounded-lg bg-primary/10 flex items-center justify-center">
                        <item.icon className="h-5 w-5 text-primary" />
                      </div>
                      <div>
                        <CardTitle className="text-base">{item.title}</CardTitle>
                        <CardDescription>{item.description}</CardDescription>
                      </div>
                    </div>
                    <ChevronRight className="h-5 w-5 text-muted-foreground" />
                  </div>
                </CardHeader>
              </Card>
            </Link>
          ))}
        </div>
      </div>
    </div>
  )
}
