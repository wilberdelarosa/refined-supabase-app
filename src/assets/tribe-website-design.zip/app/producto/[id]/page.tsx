import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { ProductDetail } from "@/components/product-detail"
import { createStaticClient } from "@/lib/supabase/static"
import type { Product } from "@/types/database"

export const dynamic = "force-dynamic"

async function getProduct(id: string): Promise<Product | null> {
  const supabase = createStaticClient()
  if (!supabase) return null

  // Try by slug first, then by ID
  const { data: bySlug } = await supabase
    .from("products")
    .select(`*, category:categories(*), brand:brands(*)`)
    .eq("slug", id)
    .eq("active", true)
    .single()

  if (bySlug) return bySlug

  const { data: byId } = await supabase
    .from("products")
    .select(`*, category:categories(*), brand:brands(*)`)
    .eq("id", id)
    .eq("active", true)
    .single()

  return byId || null
}

export async function generateMetadata({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params
  const product = await getProduct(id)
  if (!product) {
    return { title: "Producto no encontrado | Barbaro Nutrition" }
  }
  return {
    title: `${product.name} | Barbaro Nutrition`,
    description: product.description,
  }
}

export default async function ProductPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params
  const product = await getProduct(id)

  // Fallback product for demo
  const displayProduct = product || {
    id: "1",
    name: "Gold Standard 100% Whey",
    slug: "gold-standard-whey",
    description:
      "La proteína de suero más vendida del mundo. 24g de proteína por porción con aminoácidos de rápida absorción para recuperación muscular óptima. Fórmula premium con bajo contenido de grasa y azúcar.",
    price: 2899,
    compare_price: 3299,
    image: "https://images.unsplash.com/photo-1593095948071-474c5cc2989d?w=500",
    images: null,
    stock: 25,
    sku: "ON-GS-001",
    featured: true,
    active: true,
    weight: "2.27 kg",
    servings: 74,
    flavor: "Double Rich Chocolate",
    category_id: "1",
    brand_id: "1",
    created_at: new Date().toISOString(),
    updated_at: new Date().toISOString(),
    brand: { id: "1", name: "Optimum Nutrition", logo: null, description: null, created_at: "" },
    category: { id: "1", name: "Proteínas", slug: "proteinas", description: null, image: null, created_at: "" },
  }

  return (
    <main className="min-h-screen">
      <Header />
      <section className="pt-24 pb-12">
        <div className="container mx-auto px-4">
          <ProductDetail product={displayProduct as Product} />
        </div>
      </section>
      <Footer />
    </main>
  )
}
