"use client"

import { useEffect } from "react"
import { useRouter } from "next/navigation"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { CheckoutForm } from "@/components/checkout-form"
import { OrderSummary } from "@/components/order-summary"
import { useCart } from "@/hooks/use-cart"
import { ChevronLeft } from "lucide-react"
import Link from "next/link"

export default function CheckoutPage() {
  const { items } = useCart()
  const router = useRouter()

  useEffect(() => {
    if (items.length === 0) {
      router.push("/tienda")
    }
  }, [items, router])

  if (items.length === 0) {
    return null
  }

  return (
    <main className="min-h-screen bg-neutral-50">
      <Header />

      <section className="pt-24 pb-12">
        <div className="container mx-auto px-4">
          {/* Back Link */}
          <Link
            href="/carrito"
            className="inline-flex items-center text-sm text-muted-foreground hover:text-foreground mb-6"
          >
            <ChevronLeft className="h-4 w-4 mr-1" />
            Volver al carrito
          </Link>

          <h1 className="text-2xl md:text-3xl font-bold mb-8">Finalizar Compra</h1>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
            {/* Checkout Form */}
            <div>
              <CheckoutForm />
            </div>

            {/* Order Summary */}
            <div className="lg:order-first lg:order-last">
              <div className="sticky top-24">
                <OrderSummary />
              </div>
            </div>
          </div>
        </div>
      </section>

      <Footer />
    </main>
  )
}
