import { Suspense } from "react"
import { createClient } from "@/lib/supabase/server"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { CheckCircle, Package, Mail, Phone, MapPin, ArrowRight } from "lucide-react"
import Link from "next/link"

async function getOrder(orderId: string) {
  const supabase = await createClient()

  const { data: order, error } = await supabase
    .from("orders")
    .select(
      `
      *,
      items:order_items(*)
    `,
    )
    .eq("id", orderId)
    .single()

  if (error) return null
  return order
}

function formatCurrency(amount: number) {
  return new Intl.NumberFormat("es-DO", {
    style: "currency",
    currency: "DOP",
    minimumFractionDigits: 0,
  }).format(amount)
}

async function OrderConfirmationContent({ orderId }: { orderId: string }) {
  const order = await getOrder(orderId)

  if (!order) {
    return (
      <div className="container py-12">
        <Card className="max-w-lg mx-auto">
          <CardContent className="py-12 text-center">
            <p className="text-muted-foreground">Pedido no encontrado</p>
            <Button asChild className="mt-4">
              <Link href="/tienda">Volver a la tienda</Link>
            </Button>
          </CardContent>
        </Card>
      </div>
    )
  }

  const shippingAddress = order.shipping_address as {
    full_name: string
    street_address: string
    city: string
    province: string
    phone?: string
  }

  return (
    <div className="container py-12">
      <div className="max-w-2xl mx-auto space-y-8">
        {/* Success Message */}
        <div className="text-center space-y-4">
          <div className="mx-auto w-16 h-16 bg-green-100 rounded-full flex items-center justify-center">
            <CheckCircle className="h-8 w-8 text-green-600" />
          </div>
          <h1 className="text-2xl md:text-3xl font-bold">¡Pedido Confirmado!</h1>
          <p className="text-muted-foreground">
            Gracias por tu compra. Te hemos enviado un correo de confirmación a <strong>{order.customer_email}</strong>
          </p>
        </div>

        {/* Order Details */}
        <Card>
          <CardContent className="p-6 space-y-6">
            <div className="flex items-center justify-between pb-4 border-b">
              <div>
                <p className="text-sm text-muted-foreground">Número de Pedido</p>
                <p className="text-xl font-bold">{order.order_number}</p>
              </div>
              <div className="text-right">
                <p className="text-sm text-muted-foreground">Total</p>
                <p className="text-xl font-bold">{formatCurrency(order.total)}</p>
              </div>
            </div>

            {/* Items */}
            <div>
              <h3 className="font-semibold mb-3 flex items-center gap-2">
                <Package className="h-4 w-4" />
                Productos ({order.items?.length || 0})
              </h3>
              <div className="space-y-3">
                {order.items?.map(
                  (item: { id: string; product_name: string; quantity: number; unit_price: number }) => (
                    <div key={item.id} className="flex items-center justify-between py-2 border-b last:border-0">
                      <div>
                        <p className="font-medium">{item.product_name}</p>
                        <p className="text-sm text-muted-foreground">Cantidad: {item.quantity}</p>
                      </div>
                      <p className="font-medium">{formatCurrency(item.unit_price * item.quantity)}</p>
                    </div>
                  ),
                )}
              </div>
            </div>

            {/* Shipping Address */}
            <div>
              <h3 className="font-semibold mb-3 flex items-center gap-2">
                <MapPin className="h-4 w-4" />
                Dirección de Envío
              </h3>
              <div className="text-sm text-muted-foreground space-y-1">
                <p className="font-medium text-foreground">{shippingAddress.full_name}</p>
                <p>{shippingAddress.street_address}</p>
                <p>
                  {shippingAddress.city}, {shippingAddress.province}
                </p>
                {shippingAddress.phone && <p>{shippingAddress.phone}</p>}
              </div>
            </div>

            {/* Contact Info */}
            <div className="pt-4 border-t">
              <h3 className="font-semibold mb-3">¿Tienes preguntas?</h3>
              <div className="flex flex-col sm:flex-row gap-4">
                <a
                  href={`mailto:info@barbaronutrition.com?subject=Pedido ${order.order_number}`}
                  className="flex items-center gap-2 text-sm text-muted-foreground hover:text-foreground transition-colors"
                >
                  <Mail className="h-4 w-4" />
                  info@barbaronutrition.com
                </a>
                <a
                  href="tel:+18095550100"
                  className="flex items-center gap-2 text-sm text-muted-foreground hover:text-foreground transition-colors"
                >
                  <Phone className="h-4 w-4" />
                  +1 809-555-0100
                </a>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Actions */}
        <div className="flex flex-col sm:flex-row gap-4 justify-center">
          <Button asChild>
            <Link href="/tienda">
              Seguir Comprando
              <ArrowRight className="ml-2 h-4 w-4" />
            </Link>
          </Button>
          <Button asChild variant="outline">
            <Link href="/cuenta/pedidos">Ver Mis Pedidos</Link>
          </Button>
        </div>
      </div>
    </div>
  )
}

export default async function OrderConfirmedPage({
  searchParams,
}: {
  searchParams: Promise<{ order?: string }>
}) {
  const { order: orderId } = await searchParams

  return (
    <main className="min-h-screen bg-neutral-50">
      <Header />
      <section className="pt-24 pb-12">
        <Suspense
          fallback={
            <div className="container py-12">
              <div className="max-w-2xl mx-auto text-center">
                <p className="text-muted-foreground">Cargando detalles del pedido...</p>
              </div>
            </div>
          }
        >
          {orderId ? (
            <OrderConfirmationContent orderId={orderId} />
          ) : (
            <div className="container py-12">
              <Card className="max-w-lg mx-auto">
                <CardContent className="py-12 text-center">
                  <p className="text-muted-foreground">No se encontró información del pedido</p>
                  <Button asChild className="mt-4">
                    <Link href="/tienda">Volver a la tienda</Link>
                  </Button>
                </CardContent>
              </Card>
            </div>
          )}
        </Suspense>
      </section>
      <Footer />
    </main>
  )
}
