import { type NextRequest, NextResponse } from "next/server"
import { validateStock } from "@/lib/api/orders"

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const { items } = body

    if (!items || !Array.isArray(items)) {
      return NextResponse.json({ valid: false, errors: ["Items inválidos"] }, { status: 400 })
    }

    const result = await validateStock(items)
    return NextResponse.json(result)
  } catch (error) {
    console.error("Error validating stock:", error)
    return NextResponse.json({ valid: false, errors: ["Error al validar stock"] }, { status: 500 })
  }
}
