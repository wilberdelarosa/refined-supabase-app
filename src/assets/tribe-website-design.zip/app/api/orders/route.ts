import { type NextRequest, NextResponse } from "next/server"
import { createClient } from "@/lib/supabase/server"
import { createOrder, validateStock } from "@/lib/api/orders"

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()

    const { customerEmail, customerName, customerPhone, shippingAddress, billingAddress, items, customerNotes } = body

    // Validate required fields
    if (!customerEmail || !customerName || !shippingAddress || !items || items.length === 0) {
      return NextResponse.json({ error: "Faltan datos requeridos" }, { status: 400 })
    }

    // Validate stock
    const stockValidation = await validateStock(
      items.map((i: { productId: string; quantity: number }) => ({
        productId: i.productId,
        quantity: i.quantity,
      })),
    )

    if (!stockValidation.valid) {
      return NextResponse.json({ error: "Stock insuficiente", details: stockValidation.errors }, { status: 400 })
    }

    // Get current user if logged in
    const supabase = await createClient()
    const {
      data: { user },
    } = await supabase.auth.getUser()

    // Create order
    const order = await createOrder({
      userId: user?.id,
      customerEmail,
      customerName,
      customerPhone,
      shippingAddress,
      billingAddress,
      items,
      customerNotes,
    })

    return NextResponse.json({ order })
  } catch (error) {
    console.error("Error creating order:", error)
    return NextResponse.json(
      { error: error instanceof Error ? error.message : "Error al crear el pedido" },
      { status: 500 },
    )
  }
}
