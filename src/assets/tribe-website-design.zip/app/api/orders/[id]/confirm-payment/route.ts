import { type NextRequest, NextResponse } from "next/server"
import { confirmPayment } from "@/lib/api/orders"

export async function POST(request: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  try {
    const { id } = await params
    const body = await request.json()

    const { paymentMethod, transactionId, providerResponse } = body

    if (!paymentMethod) {
      return NextResponse.json({ error: "Método de pago requerido" }, { status: 400 })
    }

    const order = await confirmPayment(id, paymentMethod, transactionId, providerResponse)

    return NextResponse.json({ order })
  } catch (error) {
    console.error("Error confirming payment:", error)
    return NextResponse.json(
      { error: error instanceof Error ? error.message : "Error al confirmar el pago" },
      { status: 500 },
    )
  }
}
