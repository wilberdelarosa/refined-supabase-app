import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Button } from "@/components/ui/button"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Separator } from "@/components/ui/separator"
import { Store, Truck, FileText, Bell, CreditCard } from "lucide-react"

export default function SettingsPage() {
  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-3xl font-bold tracking-tight">Configuración</h2>
        <p className="text-muted-foreground">Gestiona la configuración de tu tienda</p>
      </div>

      <Tabs defaultValue="general" className="space-y-6">
        <TabsList className="grid w-full grid-cols-2 lg:grid-cols-5">
          <TabsTrigger value="general" className="gap-2">
            <Store className="h-4 w-4" />
            <span className="hidden sm:inline">General</span>
          </TabsTrigger>
          <TabsTrigger value="shipping" className="gap-2">
            <Truck className="h-4 w-4" />
            <span className="hidden sm:inline">Envíos</span>
          </TabsTrigger>
          <TabsTrigger value="invoicing" className="gap-2">
            <FileText className="h-4 w-4" />
            <span className="hidden sm:inline">Facturación</span>
          </TabsTrigger>
          <TabsTrigger value="payments" className="gap-2">
            <CreditCard className="h-4 w-4" />
            <span className="hidden sm:inline">Pagos</span>
          </TabsTrigger>
          <TabsTrigger value="notifications" className="gap-2">
            <Bell className="h-4 w-4" />
            <span className="hidden sm:inline">Notificaciones</span>
          </TabsTrigger>
        </TabsList>

        <TabsContent value="general">
          <Card>
            <CardHeader>
              <CardTitle>Información de la Tienda</CardTitle>
              <CardDescription>Datos generales que aparecerán en la tienda y facturas</CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="grid gap-4 md:grid-cols-2">
                <div className="space-y-2">
                  <Label htmlFor="store_name">Nombre de la tienda</Label>
                  <Input id="store_name" defaultValue="Barbaro Nutrition" />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="store_email">Email de contacto</Label>
                  <Input id="store_email" type="email" defaultValue="info@barbaronutrition.com" />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="store_phone">Teléfono</Label>
                  <Input id="store_phone" defaultValue="+1 809-555-0100" />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="store_whatsapp">WhatsApp</Label>
                  <Input id="store_whatsapp" defaultValue="+18095550100" />
                </div>
              </div>

              <Separator />

              <div className="space-y-2">
                <Label htmlFor="store_address">Dirección</Label>
                <Input id="store_address" defaultValue="Av. 27 de Febrero, Santo Domingo" />
              </div>

              <div className="grid gap-4 md:grid-cols-3">
                <div className="space-y-2">
                  <Label htmlFor="currency">Moneda</Label>
                  <Input id="currency" defaultValue="DOP" disabled />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="currency_symbol">Símbolo</Label>
                  <Input id="currency_symbol" defaultValue="RD$" disabled />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="tax_rate">ITBIS (%)</Label>
                  <Input id="tax_rate" type="number" defaultValue="18" />
                </div>
              </div>

              <div className="flex justify-end">
                <Button>Guardar Cambios</Button>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="shipping">
          <Card>
            <CardHeader>
              <CardTitle>Configuración de Envíos</CardTitle>
              <CardDescription>Define las opciones de envío para tus clientes</CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="grid gap-4 md:grid-cols-2">
                <div className="space-y-2">
                  <Label htmlFor="shipping_cost">Costo de envío estándar (RD$)</Label>
                  <Input id="shipping_cost" type="number" defaultValue="250" />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="free_shipping">Envío gratis a partir de (RD$)</Label>
                  <Input id="free_shipping" type="number" defaultValue="2000" />
                </div>
              </div>

              <div className="flex justify-end">
                <Button>Guardar Cambios</Button>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="invoicing">
          <Card>
            <CardHeader>
              <CardTitle>Configuración de Facturación</CardTitle>
              <CardDescription>Personaliza la numeración y contenido de las facturas</CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="grid gap-4 md:grid-cols-2">
                <div className="space-y-2">
                  <Label htmlFor="invoice_series">Serie de facturación</Label>
                  <Input id="invoice_series" defaultValue="A" />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="invoice_prefix">Prefijo de factura</Label>
                  <Input id="invoice_prefix" placeholder="FAC-" />
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="invoice_footer">Pie de factura</Label>
                <Input
                  id="invoice_footer"
                  defaultValue="Gracias por su compra. Esta factura es válida como comprobante fiscal."
                />
              </div>

              <div className="flex justify-end">
                <Button>Guardar Cambios</Button>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="payments">
          <Card>
            <CardHeader>
              <CardTitle>Métodos de Pago</CardTitle>
              <CardDescription>Configura los métodos de pago disponibles</CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="p-4 border rounded-lg">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <div className="h-10 w-10 bg-blue-100 rounded-lg flex items-center justify-center">
                      <span className="text-blue-600 font-bold text-sm">PP</span>
                    </div>
                    <div>
                      <p className="font-medium">PayPal</p>
                      <p className="text-sm text-muted-foreground">Acepta pagos con PayPal</p>
                    </div>
                  </div>
                  <Button variant="outline">Configurar</Button>
                </div>
              </div>

              <div className="p-4 border rounded-lg opacity-60">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <div className="h-10 w-10 bg-purple-100 rounded-lg flex items-center justify-center">
                      <CreditCard className="h-5 w-5 text-purple-600" />
                    </div>
                    <div>
                      <p className="font-medium">Tarjeta de Crédito/Débito</p>
                      <p className="text-sm text-muted-foreground">Stripe - Próximamente</p>
                    </div>
                  </div>
                  <Button variant="outline" disabled>
                    Próximamente
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="notifications">
          <Card>
            <CardHeader>
              <CardTitle>Notificaciones por Email</CardTitle>
              <CardDescription>Configura qué emails se envían automáticamente</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <p className="text-sm text-muted-foreground">
                Para configurar las notificaciones por email, necesitas conectar un proveedor de email como SendGrid o
                Resend.
              </p>
              <Button variant="outline">Configurar Email Provider</Button>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}
