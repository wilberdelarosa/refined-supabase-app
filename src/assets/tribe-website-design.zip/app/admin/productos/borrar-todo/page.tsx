"use client"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { createBrowserClient } from "@/lib/supabase/client"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { ArrowLeft, Trash2, Loader2, AlertTriangle } from "lucide-react"
import Link from "next/link"

export default function DeleteAllProductsPage() {
  const router = useRouter()
  const supabase = createBrowserClient()

  const [confirmation, setConfirmation] = useState("")
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState("")
  const [success, setSuccess] = useState("")

  const handleDeleteAll = async () => {
    if (confirmation !== "ELIMINAR TODO") {
      setError("Debes escribir 'ELIMINAR TODO' para confirmar")
      return
    }

    setLoading(true)
    setError("")
    setSuccess("")

    try {
      // Primero eliminar todas las imágenes
      const { error: imagesError } = await supabase
        .from("product_images")
        .delete()
        .neq("id", "00000000-0000-0000-0000-000000000000") // Elimina todo

      if (imagesError) {
        console.error("Error deleting images:", imagesError)
      }

      // Luego eliminar todos los productos
      const { error: productsError } = await supabase
        .from("products")
        .delete()
        .neq("id", "00000000-0000-0000-0000-000000000000") // Elimina todo

      if (productsError) throw productsError

      setSuccess("Todos los productos han sido eliminados exitosamente")
      setConfirmation("")

      setTimeout(() => {
        router.push("/admin/productos")
      }, 2000)
    } catch (err: unknown) {
      console.error("Error deleting products:", err)
      const errorMessage = err instanceof Error ? err.message : "Error al eliminar los productos"
      setError(errorMessage)
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="max-w-2xl mx-auto space-y-6">
      <div className="flex items-center gap-4">
        <Button variant="ghost" size="icon" asChild>
          <Link href="/admin/productos">
            <ArrowLeft className="h-5 w-5" />
          </Link>
        </Button>
        <div>
          <h2 className="text-3xl font-bold tracking-tight text-red-600">Eliminar Todo el Stock</h2>
          <p className="text-muted-foreground">Esta acción es irreversible</p>
        </div>
      </div>

      <Card className="border-red-200">
        <CardHeader>
          <div className="flex items-center gap-3 text-red-600">
            <AlertTriangle className="h-8 w-8" />
            <div>
              <CardTitle className="text-red-600">Zona de Peligro</CardTitle>
              <CardDescription>
                Esta acción eliminará TODOS los productos y sus imágenes de la base de datos
              </CardDescription>
            </div>
          </div>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="bg-red-50 border border-red-200 rounded-lg p-4 space-y-2">
            <p className="font-medium text-red-800">¿Qué se eliminará?</p>
            <ul className="list-disc list-inside text-sm text-red-700 space-y-1">
              <li>Todos los productos del catálogo</li>
              <li>Todas las imágenes asociadas a los productos</li>
              <li>No se eliminarán categorías ni marcas</li>
            </ul>
          </div>

          {error && <div className="bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded-lg">{error}</div>}

          {success && (
            <div className="bg-green-50 border border-green-200 text-green-700 px-4 py-3 rounded-lg">{success}</div>
          )}

          <div className="space-y-2">
            <Label htmlFor="confirmation">
              Escribe <strong>ELIMINAR TODO</strong> para confirmar:
            </Label>
            <Input
              id="confirmation"
              value={confirmation}
              onChange={(e) => setConfirmation(e.target.value)}
              placeholder="ELIMINAR TODO"
              className="border-red-300 focus:border-red-500"
            />
          </div>

          <div className="flex gap-4">
            <Button variant="outline" asChild className="flex-1 bg-transparent">
              <Link href="/admin/productos">Cancelar</Link>
            </Button>
            <Button
              variant="destructive"
              onClick={handleDeleteAll}
              disabled={loading || confirmation !== "ELIMINAR TODO"}
              className="flex-1"
            >
              {loading ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  Eliminando...
                </>
              ) : (
                <>
                  <Trash2 className="mr-2 h-4 w-4" />
                  Eliminar Todo
                </>
              )}
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
