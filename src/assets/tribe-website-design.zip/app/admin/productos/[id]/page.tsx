"use client"

import type React from "react"

import { useState, useEffect, use } from "react"
import { useRouter } from "next/navigation"
import { createBrowserClient } from "@/lib/supabase/client"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Switch } from "@/components/ui/switch"
import { ArrowLeft, Save, Loader2, Trash2, X, ImagePlus } from "lucide-react"
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog"
import Link from "next/link"
import Image from "next/image"
import useSWR from "swr"

interface ProductImage {
  id?: string
  url: string
  is_primary: boolean
}

const fetcherCategories = async () => {
  const supabase = createBrowserClient()
  const { data } = await supabase.from("categories").select("id, name").eq("is_active", true).order("sort_order")
  return data || []
}

const fetcherBrands = async () => {
  const supabase = createBrowserClient()
  const { data } = await supabase.from("brands").select("id, name").eq("is_active", true).order("name")
  return data || []
}

export default function EditProductPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = use(params)
  const router = useRouter()
  const supabase = createBrowserClient()

  const { data: categories = [] } = useSWR("admin-categories", fetcherCategories)
  const { data: brands = [] } = useSWR("admin-brands", fetcherBrands)

  const [loading, setLoading] = useState(true)
  const [saving, setSaving] = useState(false)
  const [deleting, setDeleting] = useState(false)
  const [error, setError] = useState("")

  const [formData, setFormData] = useState({
    sku: "",
    name: "",
    slug: "",
    brand_id: "",
    category_id: "",
    short_description: "",
    description: "",
    price: "",
    compare_at_price: "",
    cost_price: "",
    stock: "0",
    low_stock_threshold: "10",
    weight: "",
    status: "draft",
    is_featured: false,
  })

  const [images, setImages] = useState<ProductImage[]>([{ url: "", is_primary: true }])

  useEffect(() => {
    const fetchProduct = async () => {
      const { data: product, error } = await supabase
        .from("products")
        .select(`
          *,
          images:product_images(id, url, is_primary, sort_order)
        `)
        .eq("id", id)
        .single()

      if (error || !product) {
        setError("Producto no encontrado")
        setLoading(false)
        return
      }

      setFormData({
        sku: product.sku || "",
        name: product.name || "",
        slug: product.slug || "",
        brand_id: product.brand_id || "",
        category_id: product.category_id || "",
        short_description: product.short_description || "",
        description: product.description || "",
        price: product.price?.toString() || "",
        compare_at_price: product.compare_at_price?.toString() || "",
        cost_price: product.cost_price?.toString() || "",
        stock: product.stock?.toString() || "0",
        low_stock_threshold: product.low_stock_threshold?.toString() || "10",
        weight: product.weight?.toString() || "",
        status: product.status || "draft",
        is_featured: product.is_featured || false,
      })

      if (product.images && product.images.length > 0) {
        setImages(
          product.images.sort(
            (a: ProductImage & { sort_order: number }, b: ProductImage & { sort_order: number }) =>
              a.sort_order - b.sort_order,
          ),
        )
      }

      setLoading(false)
    }

    fetchProduct()
  }, [id, supabase])

  const generateSlug = (name: string) => {
    return name
      .toLowerCase()
      .normalize("NFD")
      .replace(/[\u0300-\u036f]/g, "")
      .replace(/[^a-z0-9]+/g, "-")
      .replace(/(^-|-$)/g, "")
  }

  const handleNameChange = (name: string) => {
    setFormData((prev) => ({
      ...prev,
      name,
      slug: generateSlug(name),
    }))
  }

  const addImage = () => {
    setImages((prev) => [...prev, { url: "", is_primary: false }])
  }

  const removeImage = (index: number) => {
    setImages((prev) => {
      const newImages = prev.filter((_, i) => i !== index)
      // Si eliminamos la primaria, hacer la primera la nueva primaria
      if (prev[index].is_primary && newImages.length > 0) {
        newImages[0].is_primary = true
      }
      return newImages
    })
  }

  const updateImageUrl = (index: number, url: string) => {
    setImages((prev) => prev.map((img, i) => (i === index ? { ...img, url } : img)))
  }

  const setPrimaryImage = (index: number) => {
    setImages((prev) => prev.map((img, i) => ({ ...img, is_primary: i === index })))
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setSaving(true)
    setError("")

    try {
      // Actualizar producto
      const { error: productError } = await supabase
        .from("products")
        .update({
          sku: formData.sku,
          name: formData.name,
          slug: formData.slug,
          brand_id: formData.brand_id || null,
          category_id: formData.category_id || null,
          short_description: formData.short_description,
          description: formData.description,
          price: Number.parseFloat(formData.price) || 0,
          compare_at_price: formData.compare_at_price ? Number.parseFloat(formData.compare_at_price) : null,
          cost_price: formData.cost_price ? Number.parseFloat(formData.cost_price) : null,
          stock: Number.parseInt(formData.stock) || 0,
          low_stock_threshold: Number.parseInt(formData.low_stock_threshold) || 10,
          weight: formData.weight ? Number.parseFloat(formData.weight) : null,
          status: formData.status,
          is_featured: formData.is_featured,
          updated_at: new Date().toISOString(),
        })
        .eq("id", id)

      if (productError) throw productError

      // Eliminar imágenes existentes
      await supabase.from("product_images").delete().eq("product_id", id)

      // Crear nuevas imágenes
      const validImages = images.filter((img) => img.url.trim())
      if (validImages.length > 0) {
        const newImages = validImages.map((img, index) => ({
          product_id: id,
          url: img.url.trim(),
          alt_text: `${formData.name} - Imagen ${index + 1}`,
          sort_order: index,
          is_primary: img.is_primary,
        }))

        const { error: imagesError } = await supabase.from("product_images").insert(newImages)

        if (imagesError) console.error("Error updating images:", imagesError)
      }

      router.push("/admin/productos")
    } catch (err: unknown) {
      console.error("Error updating product:", err)
      const errorMessage = err instanceof Error ? err.message : "Error al actualizar el producto"
      setError(errorMessage)
    } finally {
      setSaving(false)
    }
  }

  const handleDelete = async () => {
    setDeleting(true)
    try {
      // Eliminar imágenes primero
      await supabase.from("product_images").delete().eq("product_id", id)

      // Eliminar producto
      const { error } = await supabase.from("products").delete().eq("id", id)

      if (error) throw error

      router.push("/admin/productos")
    } catch (err: unknown) {
      console.error("Error deleting product:", err)
      const errorMessage = err instanceof Error ? err.message : "Error al eliminar el producto"
      setError(errorMessage)
    } finally {
      setDeleting(false)
    }
  }

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-[400px]">
        <Loader2 className="h-8 w-8 animate-spin text-muted-foreground" />
      </div>
    )
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-4">
          <Button variant="ghost" size="icon" asChild>
            <Link href="/admin/productos">
              <ArrowLeft className="h-5 w-5" />
            </Link>
          </Button>
          <div>
            <h2 className="text-3xl font-bold tracking-tight">Editar Producto</h2>
            <p className="text-muted-foreground">SKU: {formData.sku}</p>
          </div>
        </div>

        <AlertDialog>
          <AlertDialogTrigger asChild>
            <Button variant="destructive" disabled={deleting}>
              {deleting ? <Loader2 className="h-4 w-4 animate-spin" /> : <Trash2 className="h-4 w-4 mr-2" />}
              Eliminar
            </Button>
          </AlertDialogTrigger>
          <AlertDialogContent>
            <AlertDialogHeader>
              <AlertDialogTitle>¿Eliminar este producto?</AlertDialogTitle>
              <AlertDialogDescription>
                Esta acción no se puede deshacer. El producto &quot;{formData.name}&quot; será eliminado
                permanentemente.
              </AlertDialogDescription>
            </AlertDialogHeader>
            <AlertDialogFooter>
              <AlertDialogCancel>Cancelar</AlertDialogCancel>
              <AlertDialogAction onClick={handleDelete} className="bg-red-600 hover:bg-red-700">
                Eliminar
              </AlertDialogAction>
            </AlertDialogFooter>
          </AlertDialogContent>
        </AlertDialog>
      </div>

      {error && <div className="bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded-lg">{error}</div>}

      <form onSubmit={handleSubmit} className="grid gap-6 lg:grid-cols-3">
        <div className="lg:col-span-2 space-y-6">
          {/* Información básica */}
          <Card>
            <CardHeader>
              <CardTitle>Información Básica</CardTitle>
              <CardDescription>Nombre, SKU y descripción del producto</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid gap-4 sm:grid-cols-2">
                <div className="space-y-2">
                  <Label htmlFor="sku">SKU *</Label>
                  <Input
                    id="sku"
                    value={formData.sku}
                    onChange={(e) => setFormData((prev) => ({ ...prev, sku: e.target.value.toUpperCase() }))}
                    placeholder="ON-WH-001"
                    required
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="name">Nombre *</Label>
                  <Input
                    id="name"
                    value={formData.name}
                    onChange={(e) => handleNameChange(e.target.value)}
                    placeholder="Gold Standard Whey 5lb"
                    required
                  />
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="slug">Slug (URL)</Label>
                <Input
                  id="slug"
                  value={formData.slug}
                  onChange={(e) => setFormData((prev) => ({ ...prev, slug: e.target.value }))}
                  placeholder="gold-standard-whey-5lb"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="short_description">Descripción Corta</Label>
                <Input
                  id="short_description"
                  value={formData.short_description}
                  onChange={(e) => setFormData((prev) => ({ ...prev, short_description: e.target.value }))}
                  placeholder="24g de proteína por servicio"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="description">Descripción Completa</Label>
                <Textarea
                  id="description"
                  value={formData.description}
                  onChange={(e) => setFormData((prev) => ({ ...prev, description: e.target.value }))}
                  placeholder="Descripción detallada del producto..."
                  rows={5}
                />
              </div>
            </CardContent>
          </Card>

          {/* Precios e inventario */}
          <Card>
            <CardHeader>
              <CardTitle>Precios e Inventario</CardTitle>
              <CardDescription>Configura precios en RD$ y stock</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid gap-4 sm:grid-cols-3">
                <div className="space-y-2">
                  <Label htmlFor="price">Precio (RD$) *</Label>
                  <Input
                    id="price"
                    type="number"
                    min="0"
                    step="0.01"
                    value={formData.price}
                    onChange={(e) => setFormData((prev) => ({ ...prev, price: e.target.value }))}
                    placeholder="4500.00"
                    required
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="compare_at_price">Precio Anterior</Label>
                  <Input
                    id="compare_at_price"
                    type="number"
                    min="0"
                    step="0.01"
                    value={formData.compare_at_price}
                    onChange={(e) => setFormData((prev) => ({ ...prev, compare_at_price: e.target.value }))}
                    placeholder="5200.00"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="cost_price">Costo</Label>
                  <Input
                    id="cost_price"
                    type="number"
                    min="0"
                    step="0.01"
                    value={formData.cost_price}
                    onChange={(e) => setFormData((prev) => ({ ...prev, cost_price: e.target.value }))}
                    placeholder="3000.00"
                  />
                </div>
              </div>

              <div className="grid gap-4 sm:grid-cols-3">
                <div className="space-y-2">
                  <Label htmlFor="stock">Stock *</Label>
                  <Input
                    id="stock"
                    type="number"
                    min="0"
                    value={formData.stock}
                    onChange={(e) => setFormData((prev) => ({ ...prev, stock: e.target.value }))}
                    required
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="low_stock_threshold">Alerta Stock Bajo</Label>
                  <Input
                    id="low_stock_threshold"
                    type="number"
                    min="0"
                    value={formData.low_stock_threshold}
                    onChange={(e) => setFormData((prev) => ({ ...prev, low_stock_threshold: e.target.value }))}
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="weight">Peso (kg)</Label>
                  <Input
                    id="weight"
                    type="number"
                    min="0"
                    step="0.01"
                    value={formData.weight}
                    onChange={(e) => setFormData((prev) => ({ ...prev, weight: e.target.value }))}
                    placeholder="2.27"
                  />
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Imágenes */}
          <Card>
            <CardHeader>
              <CardTitle>Imágenes</CardTitle>
              <CardDescription>URLs de imágenes del producto</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              {images.map((img, index) => (
                <div key={index} className="flex gap-4 items-start p-4 border rounded-lg">
                  {img.url && (
                    <div className="h-20 w-20 rounded-lg overflow-hidden bg-muted flex-shrink-0">
                      <Image
                        src={img.url || "/placeholder.svg"}
                        alt={`Imagen ${index + 1}`}
                        width={80}
                        height={80}
                        className="h-full w-full object-cover"
                        onError={(e) => {
                          ;(e.target as HTMLImageElement).src = "/placeholder.svg?height=80&width=80"
                        }}
                      />
                    </div>
                  )}
                  <div className="flex-1 space-y-2">
                    <Input
                      value={img.url}
                      onChange={(e) => updateImageUrl(index, e.target.value)}
                      placeholder="https://ejemplo.com/imagen.jpg"
                    />
                    <div className="flex items-center justify-between">
                      <label className="flex items-center gap-2 text-sm">
                        <input
                          type="radio"
                          name="primary_image"
                          checked={img.is_primary}
                          onChange={() => setPrimaryImage(index)}
                          className="h-4 w-4"
                        />
                        Imagen principal
                      </label>
                      {images.length > 1 && (
                        <Button type="button" variant="ghost" size="sm" onClick={() => removeImage(index)}>
                          <X className="h-4 w-4 mr-1" />
                          Eliminar
                        </Button>
                      )}
                    </div>
                  </div>
                </div>
              ))}
              <Button type="button" variant="outline" onClick={addImage} className="w-full bg-transparent">
                <ImagePlus className="mr-2 h-4 w-4" />
                Añadir otra imagen
              </Button>
            </CardContent>
          </Card>
        </div>

        {/* Sidebar */}
        <div className="space-y-6">
          {/* Estado */}
          <Card>
            <CardHeader>
              <CardTitle>Estado</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="status">Visibilidad</Label>
                <Select
                  value={formData.status}
                  onValueChange={(value) => setFormData((prev) => ({ ...prev, status: value }))}
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="draft">Borrador</SelectItem>
                    <SelectItem value="published">Publicado</SelectItem>
                    <SelectItem value="archived">Archivado</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="flex items-center justify-between">
                <Label htmlFor="is_featured">Producto Destacado</Label>
                <Switch
                  id="is_featured"
                  checked={formData.is_featured}
                  onCheckedChange={(checked) => setFormData((prev) => ({ ...prev, is_featured: checked }))}
                />
              </div>
            </CardContent>
          </Card>

          {/* Organización */}
          <Card>
            <CardHeader>
              <CardTitle>Organización</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="category">Categoría</Label>
                <Select
                  value={formData.category_id}
                  onValueChange={(value) => setFormData((prev) => ({ ...prev, category_id: value }))}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Seleccionar categoría" />
                  </SelectTrigger>
                  <SelectContent>
                    {categories.map((cat: { id: string; name: string }) => (
                      <SelectItem key={cat.id} value={cat.id}>
                        {cat.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label htmlFor="brand">Marca</Label>
                <Select
                  value={formData.brand_id}
                  onValueChange={(value) => setFormData((prev) => ({ ...prev, brand_id: value }))}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Seleccionar marca" />
                  </SelectTrigger>
                  <SelectContent>
                    {brands.map((brand: { id: string; name: string }) => (
                      <SelectItem key={brand.id} value={brand.id}>
                        {brand.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </CardContent>
          </Card>

          {/* Acciones */}
          <Card>
            <CardContent className="pt-6">
              <Button type="submit" className="w-full" disabled={saving}>
                {saving ? (
                  <>
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    Guardando...
                  </>
                ) : (
                  <>
                    <Save className="mr-2 h-4 w-4" />
                    Guardar Cambios
                  </>
                )}
              </Button>
            </CardContent>
          </Card>
        </div>
      </form>
    </div>
  )
}
