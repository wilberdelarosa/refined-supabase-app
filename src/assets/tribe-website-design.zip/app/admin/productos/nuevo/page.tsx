"use client"

import type React from "react"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { createBrowserClient } from "@/lib/supabase/client"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Switch } from "@/components/ui/switch"
import { ArrowLeft, Save, Loader2, X, ImagePlus } from "lucide-react"
import Link from "next/link"
import Image from "next/image"
import useSWR from "swr"

const fetcher = async (url: string) => {
  const supabase = createBrowserClient()
  if (url === "categories") {
    const { data } = await supabase.from("categories").select("id, name").eq("is_active", true).order("sort_order")
    return data || []
  }
  if (url === "brands") {
    const { data } = await supabase.from("brands").select("id, name").eq("is_active", true).order("name")
    return data || []
  }
  return []
}

export default function NewProductPage() {
  const router = useRouter()
  const supabase = createBrowserClient()

  const { data: categories = [] } = useSWR("categories", fetcher)
  const { data: brands = [] } = useSWR("brands", fetcher)

  const [loading, setLoading] = useState(false)
  const [error, setError] = useState("")

  const [formData, setFormData] = useState({
    sku: "",
    name: "",
    slug: "",
    brand_id: "",
    category_id: "",
    short_description: "",
    description: "",
    price: "",
    compare_at_price: "",
    cost_price: "",
    stock: "0",
    low_stock_threshold: "10",
    weight: "",
    status: "draft",
    is_featured: false,
    image_urls: [""],
  })

  const generateSlug = (name: string) => {
    return name
      .toLowerCase()
      .normalize("NFD")
      .replace(/[\u0300-\u036f]/g, "")
      .replace(/[^a-z0-9]+/g, "-")
      .replace(/(^-|-$)/g, "")
  }

  const handleNameChange = (name: string) => {
    setFormData((prev) => ({
      ...prev,
      name,
      slug: generateSlug(name),
    }))
  }

  const addImageUrl = () => {
    setFormData((prev) => ({
      ...prev,
      image_urls: [...prev.image_urls, ""],
    }))
  }

  const removeImageUrl = (index: number) => {
    setFormData((prev) => ({
      ...prev,
      image_urls: prev.image_urls.filter((_, i) => i !== index),
    }))
  }

  const updateImageUrl = (index: number, url: string) => {
    setFormData((prev) => ({
      ...prev,
      image_urls: prev.image_urls.map((u, i) => (i === index ? url : u)),
    }))
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setLoading(true)
    setError("")

    try {
      // Crear producto
      const { data: product, error: productError } = await supabase
        .from("products")
        .insert({
          sku: formData.sku,
          name: formData.name,
          slug: formData.slug,
          brand_id: formData.brand_id || null,
          category_id: formData.category_id || null,
          short_description: formData.short_description,
          description: formData.description,
          price: Number.parseFloat(formData.price) || 0,
          compare_at_price: formData.compare_at_price ? Number.parseFloat(formData.compare_at_price) : null,
          cost_price: formData.cost_price ? Number.parseFloat(formData.cost_price) : null,
          stock: Number.parseInt(formData.stock) || 0,
          low_stock_threshold: Number.parseInt(formData.low_stock_threshold) || 10,
          weight: formData.weight ? Number.parseFloat(formData.weight) : null,
          status: formData.status,
          is_featured: formData.is_featured,
        })
        .select()
        .single()

      if (productError) throw productError

      // Crear imágenes
      const validUrls = formData.image_urls.filter((url) => url.trim())
      if (validUrls.length > 0 && product) {
        const images = validUrls.map((url, index) => ({
          product_id: product.id,
          url: url.trim(),
          alt_text: `${formData.name} - Imagen ${index + 1}`,
          sort_order: index,
          is_primary: index === 0,
        }))

        const { error: imagesError } = await supabase.from("product_images").insert(images)

        if (imagesError) console.error("Error creating images:", imagesError)
      }

      router.push("/admin/productos")
    } catch (err: unknown) {
      console.error("Error creating product:", err)
      const errorMessage = err instanceof Error ? err.message : "Error al crear el producto"
      setError(errorMessage)
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center gap-4">
        <Button variant="ghost" size="icon" asChild>
          <Link href="/admin/productos">
            <ArrowLeft className="h-5 w-5" />
          </Link>
        </Button>
        <div>
          <h2 className="text-3xl font-bold tracking-tight">Nuevo Producto</h2>
          <p className="text-muted-foreground">Añade un nuevo producto al catálogo</p>
        </div>
      </div>

      {error && <div className="bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded-lg">{error}</div>}

      <form onSubmit={handleSubmit} className="grid gap-6 lg:grid-cols-3">
        <div className="lg:col-span-2 space-y-6">
          {/* Información básica */}
          <Card>
            <CardHeader>
              <CardTitle>Información Básica</CardTitle>
              <CardDescription>Nombre, SKU y descripción del producto</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid gap-4 sm:grid-cols-2">
                <div className="space-y-2">
                  <Label htmlFor="sku">SKU *</Label>
                  <Input
                    id="sku"
                    value={formData.sku}
                    onChange={(e) => setFormData((prev) => ({ ...prev, sku: e.target.value.toUpperCase() }))}
                    placeholder="ON-WH-001"
                    required
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="name">Nombre *</Label>
                  <Input
                    id="name"
                    value={formData.name}
                    onChange={(e) => handleNameChange(e.target.value)}
                    placeholder="Gold Standard Whey 5lb"
                    required
                  />
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="slug">Slug (URL)</Label>
                <Input
                  id="slug"
                  value={formData.slug}
                  onChange={(e) => setFormData((prev) => ({ ...prev, slug: e.target.value }))}
                  placeholder="gold-standard-whey-5lb"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="short_description">Descripción Corta</Label>
                <Input
                  id="short_description"
                  value={formData.short_description}
                  onChange={(e) => setFormData((prev) => ({ ...prev, short_description: e.target.value }))}
                  placeholder="24g de proteína por servicio"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="description">Descripción Completa</Label>
                <Textarea
                  id="description"
                  value={formData.description}
                  onChange={(e) => setFormData((prev) => ({ ...prev, description: e.target.value }))}
                  placeholder="Descripción detallada del producto..."
                  rows={5}
                />
              </div>
            </CardContent>
          </Card>

          {/* Precios e inventario */}
          <Card>
            <CardHeader>
              <CardTitle>Precios e Inventario</CardTitle>
              <CardDescription>Configura precios en RD$ y stock</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid gap-4 sm:grid-cols-3">
                <div className="space-y-2">
                  <Label htmlFor="price">Precio (RD$) *</Label>
                  <Input
                    id="price"
                    type="number"
                    min="0"
                    step="0.01"
                    value={formData.price}
                    onChange={(e) => setFormData((prev) => ({ ...prev, price: e.target.value }))}
                    placeholder="4500.00"
                    required
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="compare_at_price">Precio Comparación</Label>
                  <Input
                    id="compare_at_price"
                    type="number"
                    min="0"
                    step="0.01"
                    value={formData.compare_at_price}
                    onChange={(e) => setFormData((prev) => ({ ...prev, compare_at_price: e.target.value }))}
                    placeholder="5200.00"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="cost_price">Costo</Label>
                  <Input
                    id="cost_price"
                    type="number"
                    min="0"
                    step="0.01"
                    value={formData.cost_price}
                    onChange={(e) => setFormData((prev) => ({ ...prev, cost_price: e.target.value }))}
                    placeholder="3000.00"
                  />
                </div>
              </div>

              <div className="grid gap-4 sm:grid-cols-3">
                <div className="space-y-2">
                  <Label htmlFor="stock">Stock *</Label>
                  <Input
                    id="stock"
                    type="number"
                    min="0"
                    value={formData.stock}
                    onChange={(e) => setFormData((prev) => ({ ...prev, stock: e.target.value }))}
                    required
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="low_stock_threshold">Alerta Stock Bajo</Label>
                  <Input
                    id="low_stock_threshold"
                    type="number"
                    min="0"
                    value={formData.low_stock_threshold}
                    onChange={(e) => setFormData((prev) => ({ ...prev, low_stock_threshold: e.target.value }))}
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="weight">Peso (kg)</Label>
                  <Input
                    id="weight"
                    type="number"
                    min="0"
                    step="0.01"
                    value={formData.weight}
                    onChange={(e) => setFormData((prev) => ({ ...prev, weight: e.target.value }))}
                    placeholder="2.27"
                  />
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Imágenes */}
          <Card>
            <CardHeader>
              <CardTitle>Imágenes</CardTitle>
              <CardDescription>URLs de imágenes del producto (la primera será la principal)</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              {formData.image_urls.map((url, index) => (
                <div key={index} className="flex gap-2 items-start">
                  <div className="flex-1 space-y-2">
                    <div className="flex gap-2">
                      <Input
                        value={url}
                        onChange={(e) => updateImageUrl(index, e.target.value)}
                        placeholder="https://ejemplo.com/imagen.jpg"
                      />
                      {formData.image_urls.length > 1 && (
                        <Button type="button" variant="ghost" size="icon" onClick={() => removeImageUrl(index)}>
                          <X className="h-4 w-4" />
                        </Button>
                      )}
                    </div>
                    {url && (
                      <div className="h-20 w-20 rounded-lg overflow-hidden bg-muted">
                        <Image
                          src={url || "/placeholder.svg"}
                          alt={`Preview ${index + 1}`}
                          width={80}
                          height={80}
                          className="h-full w-full object-cover"
                          onError={(e) => {
                            ;(e.target as HTMLImageElement).src = "/placeholder.svg?height=80&width=80"
                          }}
                        />
                      </div>
                    )}
                  </div>
                </div>
              ))}
              <Button type="button" variant="outline" onClick={addImageUrl} className="w-full bg-transparent">
                <ImagePlus className="mr-2 h-4 w-4" />
                Añadir otra imagen
              </Button>
            </CardContent>
          </Card>
        </div>

        {/* Sidebar */}
        <div className="space-y-6">
          {/* Estado */}
          <Card>
            <CardHeader>
              <CardTitle>Estado</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="status">Visibilidad</Label>
                <Select
                  value={formData.status}
                  onValueChange={(value) => setFormData((prev) => ({ ...prev, status: value }))}
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="draft">Borrador</SelectItem>
                    <SelectItem value="published">Publicado</SelectItem>
                    <SelectItem value="archived">Archivado</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="flex items-center justify-between">
                <Label htmlFor="is_featured">Producto Destacado</Label>
                <Switch
                  id="is_featured"
                  checked={formData.is_featured}
                  onCheckedChange={(checked) => setFormData((prev) => ({ ...prev, is_featured: checked }))}
                />
              </div>
            </CardContent>
          </Card>

          {/* Organización */}
          <Card>
            <CardHeader>
              <CardTitle>Organización</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="category">Categoría</Label>
                <Select
                  value={formData.category_id}
                  onValueChange={(value) => setFormData((prev) => ({ ...prev, category_id: value }))}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Seleccionar categoría" />
                  </SelectTrigger>
                  <SelectContent>
                    {categories.map((cat: { id: string; name: string }) => (
                      <SelectItem key={cat.id} value={cat.id}>
                        {cat.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label htmlFor="brand">Marca</Label>
                <Select
                  value={formData.brand_id}
                  onValueChange={(value) => setFormData((prev) => ({ ...prev, brand_id: value }))}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Seleccionar marca" />
                  </SelectTrigger>
                  <SelectContent>
                    {brands.map((brand: { id: string; name: string }) => (
                      <SelectItem key={brand.id} value={brand.id}>
                        {brand.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </CardContent>
          </Card>

          {/* Acciones */}
          <Card>
            <CardContent className="pt-6">
              <Button type="submit" className="w-full" disabled={loading}>
                {loading ? (
                  <>
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    Guardando...
                  </>
                ) : (
                  <>
                    <Save className="mr-2 h-4 w-4" />
                    Crear Producto
                  </>
                )}
              </Button>
            </CardContent>
          </Card>
        </div>
      </form>
    </div>
  )
}
