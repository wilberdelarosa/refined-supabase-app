import { Header } from "@/components/header"
import { Hero } from "@/components/hero"
import { CategorySection } from "@/components/category-section"
import { FeaturedProducts } from "@/components/featured-products"
import { Testimonials } from "@/components/testimonials"
import { Footer } from "@/components/footer"

export default function Home() {
  return (
    <main className="min-h-screen">
      <Header />
      <Hero />
      <CategorySection />
      <FeaturedProducts />
      <Testimonials />
      <Footer />
    </main>
  )
}
