"use client"

import Link from "next/link"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { CartItems } from "@/components/cart-items"
import { CartSummary } from "@/components/cart-summary"
import { Button } from "@/components/ui/button"
import { useCart } from "@/hooks/use-cart"
import { ShoppingBag, ArrowRight, ChevronLeft } from "lucide-react"

export default function CartPage() {
  const { items } = useCart()

  return (
    <main className="min-h-screen bg-neutral-50">
      <Header />

      <section className="pt-24 pb-12">
        <div className="container mx-auto px-4">
          {/* Back Link */}
          <Link
            href="/tienda"
            className="inline-flex items-center text-sm text-muted-foreground hover:text-foreground mb-6"
          >
            <ChevronLeft className="h-4 w-4 mr-1" />
            Continuar comprando
          </Link>

          <h1 className="text-2xl md:text-3xl font-bold mb-8">Tu Carrito</h1>

          {items.length > 0 ? (
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
              {/* Cart Items */}
              <div className="lg:col-span-2">
                <CartItems />
              </div>

              {/* Summary */}
              <div className="lg:col-span-1">
                <div className="sticky top-24 space-y-4">
                  <CartSummary />
                  <Button asChild size="lg" className="w-full">
                    <Link href="/checkout">
                      Proceder al Pago
                      <ArrowRight className="ml-2 h-5 w-5" />
                    </Link>
                  </Button>
                </div>
              </div>
            </div>
          ) : (
            <div className="text-center py-16 bg-white rounded-2xl border">
              <div className="inline-flex items-center justify-center w-20 h-20 rounded-full bg-neutral-100 mb-6">
                <ShoppingBag className="h-10 w-10 text-muted-foreground" />
              </div>
              <h2 className="text-xl font-semibold mb-2">Tu carrito está vacío</h2>
              <p className="text-muted-foreground mb-6">Agrega productos para comenzar tu compra</p>
              <Button asChild>
                <Link href="/tienda">Explorar Productos</Link>
              </Button>
            </div>
          )}
        </div>
      </section>

      <Footer />
    </main>
  )
}
