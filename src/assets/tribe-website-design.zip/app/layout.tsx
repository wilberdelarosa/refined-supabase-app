import type React from "react"
import type { Metadata, Viewport } from "next"
import { Inter } from "next/font/google"
import "./globals.css"
import { CartProvider } from "@/components/cart-provider"
import { AuthProvider } from "@/lib/auth/auth-context"
import { Toaster } from "@/components/ui/toaster"

const inter = Inter({
  subsets: ["latin"],
  display: "swap",
  variable: "--font-inter",
})

export const metadata: Metadata = {
  title: "Barbaro Nutrition | Suplementos Deportivos Premium",
  description:
    "Tienda de suplementos deportivos premium en República Dominicana. Proteínas, creatina, pre-entrenos y más al mejor precio.",
  keywords: ["suplementos", "proteínas", "creatina", "fitness", "gym", "República Dominicana"],
  authors: [{ name: "Barbaro Nutrition" }],
  openGraph: {
    title: "Barbaro Nutrition | Suplementos Deportivos Premium",
    description: "Suplementos deportivos premium al mejor precio",
    type: "website",
    locale: "es_DO",
  },
    generator: 'v0.app'
}

export const viewport: Viewport = {
  width: "device-width",
  initialScale: 1,
  maximumScale: 5,
  themeColor: "#171717",
}

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <html lang="es" className={inter.variable} suppressHydrationWarning>
      <body className="font-sans">
        <AuthProvider>
          <CartProvider>
            {children}
            <Toaster />
          </CartProvider>
        </AuthProvider>
      </body>
    </html>
  )
}
