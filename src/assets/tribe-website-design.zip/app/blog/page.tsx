import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { BlogPostCard } from "@/components/blog-post-card"
import { getBlogPosts } from "@/lib/blog"

export default async function BlogPage() {
  const posts = await getBlogPosts()

  return (
    <main className="min-h-screen">
      <Header />
      <div className="container mx-auto py-12">
        <h1 className="text-4xl font-bold mb-8">Blog</h1>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {posts.map((post) => (
            <BlogPostCard key={post.id} post={post} />
          ))}
        </div>
      </div>
      <Footer />
    </main>
  )
}
