import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import Image from "next/image"
import { Target, Users, Award, Heart } from "lucide-react"

export const metadata = {
  title: "Sobre Nosotros | Barbaro Nutrition",
  description: "Conoce la historia y misión de Barbaro Nutrition, tu tienda de suplementos deportivos premium.",
}

const values = [
  {
    icon: Award,
    title: "Calidad Premium",
    description:
      "Ofrecemos solo los mejores suplementos deportivos con ingredientes de la más alta calidad y respaldados por la ciencia.",
  },
  {
    icon: Users,
    title: "Asesoría Personalizada",
    description:
      "Nuestro equipo de expertos está disponible para guiarte y ayudarte a encontrar los productos ideales para tus objetivos.",
  },
  {
    icon: Heart,
    title: "Comunidad",
    description:
      "Más que una tienda, somos una comunidad de personas comprometidas con el fitness y el bienestar integral.",
  },
  {
    icon: Target,
    title: "Resultados",
    description: "Nos enfocamos en ayudarte a alcanzar tus metas con productos efectivos y un servicio de excelencia.",
  },
]

export default function AboutPage() {
  return (
    <main className="min-h-screen">
      <Header />

      {/* Hero Section */}
      <section className="relative bg-neutral-900 text-white pt-32 pb-20 overflow-hidden">
        <div className="absolute inset-0 opacity-30">
          <Image src="/gym-team-bw.png" alt="" fill className="object-cover" priority />
        </div>
        <div className="absolute inset-0 bg-gradient-to-b from-neutral-900/80 via-neutral-900/90 to-neutral-900" />
        <div className="container mx-auto px-4 relative z-10">
          <div className="max-w-3xl">
            <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold mb-6">Sobre Nosotros</h1>
            <p className="text-lg md:text-xl text-neutral-300">
              Conoce la historia detrás de Barbaro Nutrition y nuestra pasión por el fitness
            </p>
          </div>
        </div>
      </section>

      {/* Story Section */}
      <section className="py-16 md:py-24">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <div>
              <span className="text-sm font-medium text-muted-foreground uppercase tracking-wider">
                Nuestra Historia
              </span>
              <h2 className="text-3xl md:text-4xl font-bold mt-2 mb-6">Bienvenidos Bárbaros</h2>
              <div className="space-y-4 text-muted-foreground leading-relaxed">
                <p>
                  Con mucho orgullo y entusiasmo les invito a ser parte de esta tribu la que se caracterizará por ser
                  una gran familia. Que tendrá como norte mejorar cada día en una mejor versión de nosotros mismos
                  promoviendo siempre el bienestar físico y emocional de todos sus miembros.
                </p>
                <p>
                  Pronto estaremos listos para iniciar con ustedes este camino el cual nos llenará de gratas
                  experiencias y de conocimientos.
                </p>
                <p className="text-foreground font-semibold text-lg">
                  Acompáñanos en este gran reto y sé parte de la tribu…
                </p>
              </div>
            </div>
            <div className="relative">
              <div className="aspect-[4/3] relative rounded-2xl overflow-hidden">
                <Image
                  src="/gym-team-bw.png"
                  alt="Equipo Barbaro Nutrition"
                  fill
                  className="object-cover"
                  sizes="(max-width: 1024px) 100vw, 50vw"
                />
              </div>
              {/* Decorative element */}
              <div className="absolute -bottom-6 -left-6 w-24 h-24 bg-neutral-900 rounded-2xl -z-10" />
            </div>
          </div>
        </div>
      </section>

      {/* Values Section */}
      <section className="py-16 md:py-24 bg-neutral-50">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <span className="text-sm font-medium text-muted-foreground uppercase tracking-wider">
              Lo que nos define
            </span>
            <h2 className="text-3xl md:text-4xl font-bold mt-2">Nuestra Misión</h2>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {values.map((value) => (
              <div
                key={value.title}
                className="bg-white p-6 rounded-2xl border hover:shadow-lg transition-shadow duration-300"
              >
                <div className="inline-flex items-center justify-center w-12 h-12 rounded-xl bg-neutral-900 text-white mb-4">
                  <value.icon className="h-6 w-6" />
                </div>
                <h3 className="font-semibold text-lg mb-2">{value.title}</h3>
                <p className="text-sm text-muted-foreground leading-relaxed">{value.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-16 md:py-24 bg-neutral-900 text-white">
        <div className="container mx-auto px-4 text-center">
          <h2 className="text-3xl md:text-4xl font-bold mb-4">¿Listo para ser parte de la tribu?</h2>
          <p className="text-neutral-400 mb-8 max-w-2xl mx-auto">
            Explora nuestra selección de suplementos premium y comienza tu transformación hoy mismo.
          </p>
          <a
            href="/tienda"
            className="inline-flex items-center justify-center px-8 py-3 bg-white text-neutral-900 font-semibold rounded-lg hover:bg-neutral-100 transition-colors"
          >
            Ver Productos
          </a>
        </div>
      </section>

      <Footer />
    </main>
  )
}
