import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { ProductGrid } from "@/components/product-grid"
import { createStaticClient } from "@/lib/supabase/static"
import Link from "next/link"
import { ChevronLeft, Filter } from "lucide-react"

export const dynamic = "force-dynamic"

// Category name mapping
const categoryNames: Record<string, string> = {
  proteinas: "Proteínas",
  creatina: "Creatina",
  "pre-entrenos": "Pre-Entrenos",
  "vitaminas-minerales": "Vitaminas y Minerales",
  aminoacidos: "Aminoácidos",
  "ganadores-masa": "Ganadores de Masa",
}

async function getProductsByCategory(categorySlug: string) {
  const supabase = createStaticClient()
  if (!supabase) return []

  const { data: category } = await supabase.from("categories").select("id").eq("slug", categorySlug).single()

  if (!category) return []

  const { data } = await supabase
    .from("products")
    .select(`*, category:categories(*), brand:brands(*)`)
    .eq("category_id", category.id)
    .eq("active", true)
    .order("created_at", { ascending: false })

  return data || []
}

async function getCategories() {
  const supabase = createStaticClient()
  if (!supabase) return []

  const { data } = await supabase.from("categories").select("*").order("name")
  return data || []
}

export async function generateMetadata({ params }: { params: Promise<{ category: string }> }) {
  const { category } = await params
  const categoryName = categoryNames[category] || category
  return {
    title: `${categoryName} | Barbaro Nutrition`,
    description: `Explora nuestra selección de ${categoryName.toLowerCase()} de las mejores marcas`,
  }
}

export default async function CategoryPage({ params }: { params: Promise<{ category: string }> }) {
  const { category } = await params
  const [products, categories] = await Promise.all([getProductsByCategory(category), getCategories()])

  const categoryName = categoryNames[category] || category

  // Fallback products for demo
  const displayProducts =
    products.length > 0
      ? products
      : [
          {
            id: "1",
            name: "Gold Standard 100% Whey",
            slug: "gold-standard-whey",
            description: "La proteína de suero más vendida del mundo.",
            price: 2899,
            compare_price: 3299,
            image: "https://images.unsplash.com/photo-1593095948071-474c5cc2989d?w=500",
            stock: 25,
            featured: true,
            active: true,
            brand: { id: "1", name: "Optimum Nutrition" },
            category: { id: "1", name: categoryName, slug: category },
          },
        ]

  const displayCategories =
    categories.length > 0
      ? categories
      : Object.entries(categoryNames).map(([slug, name], i) => ({
          id: String(i + 1),
          name,
          slug,
        }))

  return (
    <main className="min-h-screen">
      <Header />

      {/* Page Header */}
      <section className="bg-neutral-50 border-b pt-24 pb-8">
        <div className="container mx-auto px-4">
          <Link
            href="/tienda"
            className="inline-flex items-center text-sm text-muted-foreground hover:text-foreground mb-4"
          >
            <ChevronLeft className="h-4 w-4 mr-1" />
            Volver a la tienda
          </Link>
          <h1 className="text-3xl md:text-4xl font-bold mb-2">{categoryName}</h1>
          <p className="text-muted-foreground">
            {displayProducts.length} producto{displayProducts.length !== 1 ? "s" : ""} encontrado
            {displayProducts.length !== 1 ? "s" : ""}
          </p>
        </div>
      </section>

      {/* Main Content */}
      <section className="py-8 md:py-12">
        <div className="container mx-auto px-4">
          <div className="flex flex-col lg:flex-row gap-8">
            {/* Sidebar - Categories */}
            <aside className="lg:w-64 flex-shrink-0">
              <div className="sticky top-24">
                <div className="flex items-center gap-2 mb-4">
                  <Filter className="h-5 w-5" />
                  <h2 className="font-semibold">Categorías</h2>
                </div>
                <nav className="space-y-1">
                  <Link
                    href="/tienda"
                    className="block px-3 py-2 rounded-lg hover:bg-neutral-100 transition-colors text-sm text-muted-foreground hover:text-foreground"
                  >
                    Todos los productos
                  </Link>
                  {displayCategories.map((cat: any) => (
                    <Link
                      key={cat.id}
                      href={`/tienda/${cat.slug}`}
                      className={`block px-3 py-2 rounded-lg transition-colors text-sm ${
                        cat.slug === category
                          ? "bg-neutral-100 font-medium text-foreground"
                          : "text-muted-foreground hover:bg-neutral-100 hover:text-foreground"
                      }`}
                    >
                      {cat.name}
                    </Link>
                  ))}
                </nav>
              </div>
            </aside>

            {/* Products */}
            <div className="flex-1">
              <ProductGrid products={displayProducts as any} />
            </div>
          </div>
        </div>
      </section>

      <Footer />
    </main>
  )
}
