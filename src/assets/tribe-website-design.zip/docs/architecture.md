# Arquitectura

## Visión general

- Framework: Next.js (App Router)
- UI: Tailwind + componentes tipo shadcn/ui
- Estado: carrito en contexto (`CartProvider`) + hook (`useCart`)

## Diagrama de alto nivel

\`\`\`mermaid
flowchart TB
  U[Usuario] -->|Navega| NEXT[Next.js App Router]
  NEXT --> PAGES[app/* pages]
  PAGES --> UI[components/*]
  UI --> STATE[CartProvider + useCart]
  UI --> DATA[lib/products + lib/blog]

  DATA -->|datos mock/estáticos| TYPES[types/*]
\`\`\`

## Capas

- `app/`: páginas (rutas) y layout global.
- `components/`: componentes UI (header/footer/cards) y de dominio (carrito, checkout).
- `components/ui/`: primitives (Button, Sheet, Card, etc.).
- `lib/`: funciones de datos (productos/blog) y utilidades.
- `hooks/`: hooks (carrito, toast, etc.).
- `types/`: modelos TypeScript.
