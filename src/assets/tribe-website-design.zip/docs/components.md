# Componentes

## UI base (`components/ui/`)

Primitives reutilizables (Button, Sheet, Card, etc.).

## Componentes de layout

- `Header`: navegación + acceso al carrito + menú mobile.
- `Footer`: enlaces, categorías, contacto, redes.

## Componentes de catálogo

- `ProductGrid`: layout responsive de cards.
- `ProductCard`: card de producto con CTA.
- `FeaturedProducts`: productos destacados.

## Componentes de carrito/checkout

- `CartProvider`: estado global.
- `CartItems`: lista editable.
- `CartSummary`: totales.
- `CheckoutForm`: captura de datos.
