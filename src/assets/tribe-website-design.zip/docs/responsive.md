# Guía responsive / mobile

## Objetivo

- Navegación mobile usable (drawer/sheet accesible).
- Grillas que aprovechen `sm`/`md`.
- Espaciado consistente en `container` con `px-4` o usando la clase `container` de Tailwind.

## Checklist (página profesional)

- Tap targets ≥ 44px (botones y links importantes).
- Estados `hover`, `focus-visible`, `active` consistentes.
- Headings responsivos (`text-3xl md:text-4xl`, etc.).
- Imágenes con `object-contain/cover` según corresponda.
- Formularios mobile-first: inputs a ancho completo, labels claros.

## Componentes recomendados

- `Sheet` para menú móvil.
- `Button` variants (`default`, `outline`, `ghost`) para consistencia.
