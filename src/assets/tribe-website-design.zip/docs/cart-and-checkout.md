# Carrito y checkout

## Flujo del carrito

\`\`\`mermaid
sequenceDiagram
  autonumber
  participant U as Usuario
  participant UI as UI (ProductCard)
  participant C as CartProvider/useCart
  participant P as Página carrito

  U->>UI: Clic "Añadir al carrito"
  UI->>C: addItem(product)
  C-->>UI: items actualizados
  U->>P: Abre /carrito
  P->>C: lee items
  C-->>P: items
\`\`\`

## Puntos a cuidar

- Persistencia (opcional): localStorage para mantener el carrito.
- Validación de checkout: zod + react-hook-form.
- Estados de carga/errores: feedback claro.
