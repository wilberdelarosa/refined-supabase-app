# Rutas (App Router)

Este proyecto usa el App Router de Next (`app/`).

## Mapa de rutas

\`\`\`mermaid
flowchart LR
  HOME[/ /] --> TIENDA[/tienda/]
  TIENDA --> CAT[/tienda/[category]/]
  TIENDA --> PROD[/producto/[id]/]
  HOME --> BLOG[/blog/]
  HOME --> ABOUT[/sobre-nosotros/]
  HOME --> CART[/carrito/]
  CART --> CHECKOUT[/checkout/]
\`\`\`

## Responsabilidades

- Home: hero, categorías, destacados, testimonios.
- Tienda: grilla de productos.
- Producto: detalle + añadir al carrito.
- Carrito: listado + resumen.
- Checkout: formulario.
- Blog: listado/detalle (según implementación actual).
