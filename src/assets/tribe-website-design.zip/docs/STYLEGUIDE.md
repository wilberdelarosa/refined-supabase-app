# Guía de estilo (UI)

- Usa tokens (`bg-background`, `text-foreground`, `text-muted-foreground`, `border-border`).
- Prefiere componentes de `components/ui/` para consistencia.
- Asegura `focus-visible:ring-2` en elementos interactivos.
- Mantén layouts mobile-first (sm/md/lg).
