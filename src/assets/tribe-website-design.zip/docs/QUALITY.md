# Calidad

Comandos útiles:

\`\`\`bash
pnpm lint
pnpm build
pnpm dev
\`\`\`

Recomendación: ejecutar `pnpm lint` antes de publicar.
