# Documentación

Esta carpeta documenta el proyecto por apartados (arquitectura, rutas, componentes, estado y responsive).

## Índice

- [Arquitectura](./architecture.md)
- [Rutas (App Router)](./routes.md)
- [Componentes (UI + dominio)](./components.md)
- [Carrito y checkout (estado/flujo)](./cart-and-checkout.md)
- [Guía responsive/mobile](./responsive.md)
- [Backlog de mejoras](./improvements.md)

## Diagramas

Los diagramas están escritos en Mermaid dentro de los `.md`.

Si los visualizas en GitHub, habilita Mermaid o usa una extensión de VS Code (por ejemplo: “Markdown Preview Mermaid Support”).
