# Backlog de mejoras

## UX/UI

- Unificar colores a tokens (`bg-primary`, `text-muted-foreground`, etc.).
- Mejorar estados `hover/focus-visible` en cards, links y botones.
- Alinear espaciado con `container` + padding.

## Accesibilidad

- Menú mobile con `Sheet` (focus trap + overlay).
- Botones con `aria-label` cuando son solo iconos.

## Performance

- Migrar `<img>` a `next/image` donde aplique.
- Evitar client components innecesarios.

## Calidad

- Lint (`pnpm lint`) y corrección de warnings.
