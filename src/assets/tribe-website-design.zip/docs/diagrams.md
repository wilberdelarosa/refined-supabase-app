# Diagramas (colección)

## Layout global

\`\`\`mermaid
flowchart TB
  L[RootLayout] --> CP[CartProvider]
  CP --> P[Pages]
  P --> H[Header]
  P --> F[Footer]
\`\`\`

## Navegación

\`\`\`mermaid
flowchart LR
  H[Header] --> NAV[NavItems]
  H --> CART[Carrito]
  H --> MOBILE[Sheet (mobile)]
\`\`\`
