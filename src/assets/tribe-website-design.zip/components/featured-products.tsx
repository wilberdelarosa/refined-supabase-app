import Image from "next/image"
import Link from "next/link"
import { ArrowRight } from "lucide-react"
import { getFeaturedProducts } from "@/lib/api/products"

export async function FeaturedProducts() {
  const products = await getFeaturedProducts()

  // Fallback data if no products in database yet
  const displayProducts =
    products.length > 0
      ? products.slice(0, 4)
      : [
          {
            id: "1",
            name: "Gold Standard 100% Whey",
            slug: "gold-standard-whey",
            description: "La proteína de suero más vendida del mundo. 24g de proteína por porción.",
            price: 2899,
            compare_price: 3299,
            image: "https://images.unsplash.com/photo-1593095948071-474c5cc2989d?w=500",
            brand: { name: "Optimum Nutrition" },
          },
          {
            id: "2",
            name: "C4 Ultimate Pre-Workout",
            slug: "c4-ultimate",
            description: "Pre-entreno de alto estímulo con 300mg de cafeína para entrenamientos extremos.",
            price: 1899,
            compare_price: 2199,
            image: "https://images.unsplash.com/photo-1546483875-ad9014c88eba?w=500",
            brand: { name: "Cellucor" },
          },
          {
            id: "3",
            name: "Platinum Creatine",
            slug: "platinum-creatine",
            description: "Creatina monohidrato micronizada de la más alta pureza.",
            price: 1499,
            compare_price: 1799,
            image: "https://images.unsplash.com/photo-1619731338445-4cf6b2a97e50?w=500",
            brand: { name: "MuscleTech" },
          },
          {
            id: "4",
            name: "Xtend BCAA",
            slug: "xtend-bcaa",
            description: "BCAAs en proporción 2:1:1 con electrolitos para recuperación muscular.",
            price: 1399,
            compare_price: 1699,
            image: "https://images.unsplash.com/photo-1594381898411-846e7d193883?w=500",
            brand: { name: "Scivation" },
          },
        ]

  return (
    <section className="py-16 md:py-24">
      <div className="container mx-auto px-4">
        {/* Section Header */}
        <div className="flex flex-col md:flex-row md:items-end md:justify-between mb-12">
          <div>
            <h2 className="text-3xl md:text-4xl font-bold mb-2">Productos Destacados</h2>
            <p className="text-muted-foreground">Los favoritos de nuestros clientes</p>
          </div>
          <Link
            href="/tienda"
            className="inline-flex items-center text-sm font-medium mt-4 md:mt-0 hover:underline group"
          >
            Ver todos los productos
            <ArrowRight className="ml-1 h-4 w-4 transition-transform group-hover:translate-x-1" />
          </Link>
        </div>

        {/* Products Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {displayProducts.map((product: any) => {
            const hasDiscount = product.compare_price && product.compare_price > product.price
            const discountPercent = hasDiscount ? Math.round((1 - product.price / product.compare_price) * 100) : 0

            return (
              <Link
                key={product.id}
                href={`/producto/${product.slug || product.id}`}
                className="group bg-white rounded-xl border border-border overflow-hidden hover:shadow-lg transition-all duration-300"
              >
                {/* Image */}
                <div className="relative aspect-square bg-neutral-50 overflow-hidden">
                  <Image
                    src={product.image || "/placeholder.svg?height=400&width=400"}
                    alt={product.name}
                    fill
                    className="object-cover transition-transform duration-500 group-hover:scale-105"
                    sizes="(max-width: 640px) 100vw, (max-width: 1024px) 50vw, 25vw"
                  />
                  {hasDiscount && (
                    <span className="absolute top-3 left-3 bg-red-500 text-white text-xs font-bold px-2 py-1 rounded">
                      -{discountPercent}%
                    </span>
                  )}
                </div>

                {/* Content */}
                <div className="p-4">
                  {product.brand && (
                    <p className="text-xs font-medium text-muted-foreground uppercase tracking-wider mb-1">
                      {product.brand.name}
                    </p>
                  )}
                  <h3 className="font-semibold line-clamp-2 mb-2 group-hover:underline">{product.name}</h3>
                  <div className="flex items-baseline gap-2">
                    <span className="text-lg font-bold">RD${product.price.toLocaleString("es-DO")}</span>
                    {hasDiscount && (
                      <span className="text-sm text-muted-foreground line-through">
                        RD${product.compare_price.toLocaleString("es-DO")}
                      </span>
                    )}
                  </div>
                </div>
              </Link>
            )
          })}
        </div>
      </div>
    </section>
  )
}
