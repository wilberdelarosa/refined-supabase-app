"use client"

import Image from "next/image"
import { useCart } from "@/hooks/use-cart"
import { Separator } from "@/components/ui/separator"

export function OrderSummary() {
  const { items, total } = useCart()

  const subtotal = total
  const shipping = subtotal >= 2000 ? 0 : 250
  const tax = subtotal * 0.18
  const finalTotal = subtotal + shipping + tax

  return (
    <div className="bg-white rounded-xl border p-6">
      <h2 className="font-semibold text-lg mb-4">Tu Pedido</h2>

      {/* Items */}
      <div className="space-y-3 mb-4">
        {items.map((item) => (
          <div key={item.id} className="flex gap-3">
            <div className="relative h-16 w-16 flex-shrink-0 bg-neutral-50 rounded-lg overflow-hidden">
              <Image
                src={item.image || "/placeholder.svg?height=64&width=64"}
                alt={item.name}
                fill
                className="object-cover"
              />
              <span className="absolute -top-1 -right-1 h-5 w-5 bg-foreground text-background text-xs font-bold rounded-full flex items-center justify-center">
                {item.quantity}
              </span>
            </div>
            <div className="flex-1 min-w-0">
              <p className="font-medium text-sm line-clamp-1">{item.name}</p>
              {item.brand && <p className="text-xs text-muted-foreground">{item.brand}</p>}
            </div>
            <p className="font-medium text-sm">RD${(item.price * item.quantity).toLocaleString("es-DO")}</p>
          </div>
        ))}
      </div>

      <Separator className="my-4" />

      {/* Totals */}
      <div className="space-y-2 text-sm">
        <div className="flex justify-between">
          <span className="text-muted-foreground">Subtotal</span>
          <span>RD${subtotal.toLocaleString("es-DO")}</span>
        </div>
        <div className="flex justify-between">
          <span className="text-muted-foreground">Envío</span>
          <span>{shipping === 0 ? <span className="text-green-600">Gratis</span> : `RD$${shipping}`}</span>
        </div>
        <div className="flex justify-between">
          <span className="text-muted-foreground">ITBIS (18%)</span>
          <span>RD${tax.toLocaleString("es-DO", { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</span>
        </div>
        <Separator className="my-2" />
        <div className="flex justify-between font-bold text-base">
          <span>Total</span>
          <span>RD${finalTotal.toLocaleString("es-DO", { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</span>
        </div>
      </div>
    </div>
  )
}
