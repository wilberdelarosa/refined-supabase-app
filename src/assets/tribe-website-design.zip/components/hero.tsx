import Link from "next/link"
import Image from "next/image"
import { Button } from "@/components/ui/button"
import { ArrowRight } from "lucide-react"

export function Hero() {
  return (
    <section className="relative min-h-[600px] md:min-h-[700px] flex items-center bg-neutral-900 overflow-hidden">
      {/* Background Image */}
      <div className="absolute inset-0">
        <Image
          src="/fitness-model-black-white.png"
          alt="Atleta con suplemento"
          fill
          className="object-cover object-center"
          priority
          sizes="100vw"
        />
        {/* Gradient Overlays */}
        <div className="absolute inset-0 bg-gradient-to-r from-black via-black/80 to-transparent" />
        <div className="absolute inset-0 bg-gradient-to-t from-black/50 via-transparent to-transparent" />
      </div>

      {/* Content */}
      <div className="container mx-auto px-4 relative z-10 pt-20">
        <div className="max-w-xl">
          <h1 className="text-4xl sm:text-5xl md:text-6xl lg:text-7xl font-bold text-white leading-tight mb-6">
            <span className="block">IMPULSA TU</span>
            <span className="block text-neutral-400">RENDIMIENTO</span>
          </h1>

          <p className="text-lg md:text-xl text-neutral-300 mb-8 max-w-md">
            Suplementos deportivos premium al mejor precio en República Dominicana
          </p>

          <div className="flex flex-col sm:flex-row gap-4">
            <Button asChild size="lg" className="text-base px-8">
              <Link href="/tienda">
                Comprar Ahora
                <ArrowRight className="ml-2 h-5 w-5" />
              </Link>
            </Button>
            <Button
              asChild
              variant="outline"
              size="lg"
              className="text-base px-8 bg-transparent border-white text-white hover:bg-white hover:text-black"
            >
              <Link href="/sobre-nosotros">Conocer Más</Link>
            </Button>
          </div>
        </div>
      </div>
    </section>
  )
}
