"use client"

import { useState } from "react"
import Image from "next/image"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { useCart } from "@/hooks/use-cart"
import { useToast } from "@/hooks/use-toast"
import { Minus, Plus, ShoppingCart, Check, ChevronLeft, Truck, Shield, RotateCcw } from "lucide-react"
import type { Product } from "@/types/database"

interface ProductDetailProps {
  product: Product
}

export function ProductDetail({ product }: ProductDetailProps) {
  const [quantity, setQuantity] = useState(1)
  const [isAdding, setIsAdding] = useState(false)
  const [isAdded, setIsAdded] = useState(false)
  const { addItem } = useCart()
  const { toast } = useToast()

  const hasDiscount = product.compare_price && product.compare_price > product.price
  const discountPercent = hasDiscount ? Math.round((1 - product.price / product.compare_price!) * 100) : 0

  const handleAddToCart = async () => {
    setIsAdding(true)

    await new Promise((resolve) => setTimeout(resolve, 300))

    addItem({
      id: product.id,
      name: product.name,
      price: product.price,
      image: product.image,
      quantity,
      brand: product.brand?.name || "",
    })

    setIsAdding(false)
    setIsAdded(true)

    toast({
      title: "Producto añadido",
      description: `${quantity}x ${product.name} se añadió al carrito`,
    })

    setTimeout(() => setIsAdded(false), 2000)
  }

  return (
    <div className="animate-fade-in">
      {/* Breadcrumb */}
      <div className="mb-6">
        <Link
          href="/tienda"
          className="inline-flex items-center text-sm text-muted-foreground hover:text-foreground transition-colors"
        >
          <ChevronLeft className="h-4 w-4 mr-1" />
          Volver a la tienda
        </Link>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 lg:gap-12">
        {/* Image Section */}
        <div className="space-y-4">
          <div className="relative aspect-square bg-neutral-50 rounded-2xl overflow-hidden border">
            <Image
              src={product.image || "/placeholder.svg?height=600&width=600"}
              alt={product.name}
              fill
              className="object-cover"
              sizes="(max-width: 1024px) 100vw, 50vw"
              priority
            />
            {hasDiscount && (
              <span className="absolute top-4 left-4 bg-red-500 text-white text-sm font-bold px-3 py-1 rounded-lg">
                -{discountPercent}% OFF
              </span>
            )}
          </div>
        </div>

        {/* Product Info */}
        <div className="flex flex-col">
          {/* Category & Brand */}
          <div className="flex items-center gap-2 mb-2">
            {product.category && (
              <Link href={`/tienda/${product.category.slug}`}>
                <Badge variant="secondary" className="hover:bg-neutral-200 transition-colors">
                  {product.category.name}
                </Badge>
              </Link>
            )}
            {product.brand && <span className="text-sm text-muted-foreground">{product.brand.name}</span>}
          </div>

          {/* Name */}
          <h1 className="text-2xl md:text-3xl lg:text-4xl font-bold mb-4">{product.name}</h1>

          {/* Price */}
          <div className="flex items-baseline gap-3 mb-6">
            <span className="text-3xl md:text-4xl font-bold">RD${product.price.toLocaleString("es-DO")}</span>
            {hasDiscount && (
              <span className="text-xl text-muted-foreground line-through">
                RD${product.compare_price!.toLocaleString("es-DO")}
              </span>
            )}
          </div>

          {/* Description */}
          <p className="text-muted-foreground mb-6 leading-relaxed">{product.description}</p>

          {/* Product Details */}
          {(product.weight || product.servings || product.flavor) && (
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-4 mb-6 p-4 bg-neutral-50 rounded-xl">
              {product.weight && (
                <div>
                  <p className="text-xs text-muted-foreground uppercase tracking-wider">Peso</p>
                  <p className="font-medium">{product.weight}</p>
                </div>
              )}
              {product.servings && (
                <div>
                  <p className="text-xs text-muted-foreground uppercase tracking-wider">Porciones</p>
                  <p className="font-medium">{product.servings}</p>
                </div>
              )}
              {product.flavor && (
                <div>
                  <p className="text-xs text-muted-foreground uppercase tracking-wider">Sabor</p>
                  <p className="font-medium">{product.flavor}</p>
                </div>
              )}
            </div>
          )}

          {/* Quantity Selector */}
          <div className="mb-6">
            <label className="text-sm font-medium mb-2 block">Cantidad</label>
            <div className="flex items-center gap-3">
              <div className="flex items-center border rounded-lg">
                <Button
                  variant="ghost"
                  size="icon"
                  className="h-10 w-10 rounded-r-none"
                  onClick={() => setQuantity(Math.max(1, quantity - 1))}
                  disabled={quantity <= 1}
                >
                  <Minus className="h-4 w-4" />
                </Button>
                <span className="w-12 text-center font-medium">{quantity}</span>
                <Button
                  variant="ghost"
                  size="icon"
                  className="h-10 w-10 rounded-l-none"
                  onClick={() => setQuantity(quantity + 1)}
                  disabled={product.stock > 0 && quantity >= product.stock}
                >
                  <Plus className="h-4 w-4" />
                </Button>
              </div>
              {product.stock > 0 && product.stock <= 10 && (
                <span className="text-sm text-amber-600 font-medium">Solo quedan {product.stock}</span>
              )}
            </div>
          </div>

          {/* Add to Cart Button */}
          <Button
            onClick={handleAddToCart}
            disabled={isAdding || isAdded || product.stock === 0}
            size="lg"
            className={`w-full mb-6 h-14 text-base transition-all duration-300 ${
              isAdded ? "bg-green-600 hover:bg-green-600" : ""
            }`}
          >
            {isAdded ? (
              <>
                <Check className="h-5 w-5 mr-2" />
                Añadido al carrito
              </>
            ) : isAdding ? (
              <>
                <div className="h-5 w-5 mr-2 border-2 border-white border-t-transparent rounded-full animate-spin" />
                Añadiendo...
              </>
            ) : product.stock === 0 ? (
              "Producto agotado"
            ) : (
              <>
                <ShoppingCart className="h-5 w-5 mr-2" />
                Añadir al Carrito
              </>
            )}
          </Button>

          {/* Trust Badges */}
          <div className="grid grid-cols-3 gap-4 pt-6 border-t">
            <div className="flex flex-col items-center text-center">
              <Truck className="h-6 w-6 mb-2 text-muted-foreground" />
              <span className="text-xs text-muted-foreground">Envío gratis +$2,000</span>
            </div>
            <div className="flex flex-col items-center text-center">
              <Shield className="h-6 w-6 mb-2 text-muted-foreground" />
              <span className="text-xs text-muted-foreground">Productos originales</span>
            </div>
            <div className="flex flex-col items-center text-center">
              <RotateCcw className="h-6 w-6 mb-2 text-muted-foreground" />
              <span className="text-xs text-muted-foreground">Devolución fácil</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
