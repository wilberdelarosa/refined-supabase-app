"use client"

import type React from "react"

import { useState } from "react"
import Link from "next/link"
import Image from "next/image"
import { ShoppingCart, Check } from "lucide-react"
import { Button } from "@/components/ui/button"
import { useCart } from "@/hooks/use-cart"
import { useToast } from "@/hooks/use-toast"
import type { Product } from "@/types/database"
import { cn } from "@/lib/utils"

interface ProductCardProps {
  product: Product
}

export function ProductCard({ product }: ProductCardProps) {
  const { addItem } = useCart()
  const { toast } = useToast()
  const [isAdding, setIsAdding] = useState(false)
  const [isAdded, setIsAdded] = useState(false)

  const handleAddToCart = async (e: React.MouseEvent) => {
    e.preventDefault()
    e.stopPropagation()

    setIsAdding(true)

    // Simulate network delay
    await new Promise((resolve) => setTimeout(resolve, 300))

    addItem({
      id: product.id,
      name: product.name,
      price: product.price,
      image: product.image,
      quantity: 1,
      brand: product.brand?.name || "",
    })

    setIsAdding(false)
    setIsAdded(true)

    toast({
      title: "Producto añadido",
      description: `${product.name} se añadió al carrito`,
    })

    setTimeout(() => setIsAdded(false), 2000)
  }

  const hasDiscount = product.compare_price && product.compare_price > product.price
  const discountPercent = hasDiscount ? Math.round((1 - product.price / product.compare_price!) * 100) : 0

  return (
    <div className="group bg-white rounded-xl border border-border overflow-hidden hover:shadow-lg transition-all duration-300">
      {/* Image Container */}
      <Link href={`/producto/${product.slug || product.id}`} className="block">
        <div className="relative aspect-square bg-neutral-50 overflow-hidden">
          <Image
            src={product.image || "/placeholder.svg?height=400&width=400"}
            alt={product.name}
            fill
            className="object-cover transition-transform duration-500 group-hover:scale-105"
            sizes="(max-width: 640px) 100vw, (max-width: 1024px) 50vw, 25vw"
          />

          {/* Badges */}
          <div className="absolute top-3 left-3 flex flex-col gap-2">
            {hasDiscount && (
              <span className="bg-red-500 text-white text-xs font-bold px-2 py-1 rounded">-{discountPercent}%</span>
            )}
            {product.stock <= 5 && product.stock > 0 && (
              <span className="bg-amber-500 text-white text-xs font-bold px-2 py-1 rounded">
                Últimas {product.stock}
              </span>
            )}
          </div>
        </div>
      </Link>

      {/* Content */}
      <div className="p-4">
        {/* Brand */}
        {product.brand && (
          <p className="text-xs font-medium text-muted-foreground uppercase tracking-wider mb-1">
            {product.brand.name}
          </p>
        )}

        {/* Name */}
        <Link href={`/producto/${product.slug || product.id}`}>
          <h3 className="font-semibold text-foreground line-clamp-2 mb-2 hover:underline">{product.name}</h3>
        </Link>

        {/* Price */}
        <div className="flex items-baseline gap-2 mb-4">
          <span className="text-lg font-bold">RD${product.price.toLocaleString("es-DO")}</span>
          {hasDiscount && (
            <span className="text-sm text-muted-foreground line-through">
              RD${product.compare_price!.toLocaleString("es-DO")}
            </span>
          )}
        </div>

        {/* Add to Cart Button */}
        <Button
          onClick={handleAddToCart}
          disabled={isAdding || isAdded || product.stock === 0}
          className={cn("w-full transition-all duration-300", isAdded && "bg-green-600 hover:bg-green-600")}
        >
          {isAdded ? (
            <>
              <Check className="h-4 w-4 mr-2" />
              Añadido
            </>
          ) : isAdding ? (
            <>
              <div className="h-4 w-4 mr-2 border-2 border-white border-t-transparent rounded-full animate-spin" />
              Añadiendo...
            </>
          ) : product.stock === 0 ? (
            "Agotado"
          ) : (
            <>
              <ShoppingCart className="h-4 w-4 mr-2" />
              Añadir al Carrito
            </>
          )}
        </Button>
      </div>
    </div>
  )
}
