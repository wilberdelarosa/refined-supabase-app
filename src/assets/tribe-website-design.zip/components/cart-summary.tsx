"use client"

import { useCart } from "@/hooks/use-cart"
import { Separator } from "@/components/ui/separator"

export function CartSummary() {
  const { items, total } = useCart()

  const subtotal = total
  const shipping = subtotal >= 2000 ? 0 : 250
  const tax = subtotal * 0.18
  const finalTotal = subtotal + shipping + tax

  return (
    <div className="bg-neutral-50 rounded-xl p-6">
      <h2 className="font-semibold text-lg mb-4">Resumen del Pedido</h2>

      <div className="space-y-3 text-sm">
        <div className="flex justify-between">
          <span className="text-muted-foreground">Subtotal ({items.length} productos)</span>
          <span>RD${subtotal.toLocaleString("es-DO")}</span>
        </div>

        <div className="flex justify-between">
          <span className="text-muted-foreground">Envío</span>
          <span>{shipping === 0 ? <span className="text-green-600">Gratis</span> : `RD$${shipping}`}</span>
        </div>

        <div className="flex justify-between">
          <span className="text-muted-foreground">ITBIS (18%)</span>
          <span>RD${tax.toLocaleString("es-DO", { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</span>
        </div>

        <Separator className="my-3" />

        <div className="flex justify-between text-base font-bold">
          <span>Total</span>
          <span>RD${finalTotal.toLocaleString("es-DO", { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</span>
        </div>
      </div>

      {subtotal < 2000 && (
        <p className="text-xs text-muted-foreground mt-4">
          Agrega RD${(2000 - subtotal).toLocaleString("es-DO")} más para envío gratis
        </p>
      )}
    </div>
  )
}
