"use client"

import type React from "react"
import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import { useCart } from "@/hooks/use-cart"
import { useAuth } from "@/lib/auth/auth-context"
import { createClient } from "@/lib/supabase/client"
import type { Address } from "@/types/database"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { useToast } from "@/hooks/use-toast"
import { Loader2, CreditCard, Truck, AlertCircle, CheckCircle, User } from "lucide-react"
import Link from "next/link"

const provinces = [
  "Distrito Nacional",
  "Santo Domingo",
  "Santiago",
  "La Vega",
  "San Cristóbal",
  "Puerto Plata",
  "Duarte",
  "La Romana",
  "San Pedro de Macorís",
  "Espaillat",
  "La Altagracia",
  "Peravia",
  "Azua",
  "Barahona",
  "Monte Cristi",
  "Valverde",
  "Sánchez Ramírez",
  "Monseñor Nouel",
  "María Trinidad Sánchez",
  "Samaná",
]

type PaymentMethod = "paypal" | "transfer" | "cash_on_delivery"

export function CheckoutForm() {
  const router = useRouter()
  const { items, total, clearCart } = useCart()
  const { user, profile } = useAuth()
  const { toast } = useToast()

  const [isSubmitting, setIsSubmitting] = useState(false)
  const [paymentMethod, setPaymentMethod] = useState<PaymentMethod>("transfer")
  const [savedAddresses, setSavedAddresses] = useState<Address[]>([])
  const [selectedAddressId, setSelectedAddressId] = useState<string>("")
  const [useNewAddress, setUseNewAddress] = useState(true)
  const [stockErrors, setStockErrors] = useState<string[]>([])
  const [orderCreated, setOrderCreated] = useState<{ id: string; orderNumber: string } | null>(null)

  const [formData, setFormData] = useState({
    nombre: "",
    apellido: "",
    email: "",
    telefono: "",
    direccion: "",
    direccion2: "",
    ciudad: "",
    provincia: "",
    notas: "",
  })

  const subtotal = total
  const shipping = subtotal >= 2000 ? 0 : 250
  const tax = subtotal * 0.18
  const finalTotal = subtotal + shipping + tax

  // Load saved addresses for logged-in users
  useEffect(() => {
    if (user) {
      const fetchAddresses = async () => {
        const supabase = createClient()
        const { data } = await supabase
          .from("addresses")
          .select("*")
          .eq("user_id", user.id)
          .order("is_default_shipping", { ascending: false })

        if (data && data.length > 0) {
          setSavedAddresses(data)
          const defaultAddress = data.find((a) => a.is_default_shipping) || data[0]
          setSelectedAddressId(defaultAddress.id)
          setUseNewAddress(false)
        }
      }
      fetchAddresses()

      // Pre-fill user data
      setFormData((prev) => ({
        ...prev,
        email: profile?.email || user.email || "",
        nombre: profile?.full_name?.split(" ")[0] || "",
        apellido: profile?.full_name?.split(" ").slice(1).join(" ") || "",
        telefono: profile?.phone || "",
      }))
    }
  }, [user, profile])

  // Validate stock
  useEffect(() => {
    const validateStock = async () => {
      if (items.length === 0) return

      try {
        const response = await fetch("/api/products/validate-stock", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            items: items.map((i) => ({ productId: i.id, quantity: i.quantity })),
          }),
        })

        const data = await response.json()
        if (!data.valid) {
          setStockErrors(data.errors || [])
        } else {
          setStockErrors([])
        }
      } catch {
        // Silently fail stock validation on network error
      }
    }

    validateStock()
  }, [items])

  const getShippingAddress = () => {
    if (!useNewAddress && selectedAddressId) {
      const address = savedAddresses.find((a) => a.id === selectedAddressId)
      if (address) {
        return {
          full_name: address.full_name,
          phone: address.phone || formData.telefono,
          street_address: address.street_address,
          street_address_2: address.street_address_2 || undefined,
          city: address.city,
          province: address.province,
          postal_code: address.postal_code || undefined,
          country: "República Dominicana",
          instructions: address.instructions || undefined,
        }
      }
    }

    return {
      full_name: `${formData.nombre} ${formData.apellido}`.trim(),
      phone: formData.telefono,
      street_address: formData.direccion,
      street_address_2: formData.direccion2 || undefined,
      city: formData.ciudad,
      province: formData.provincia,
      country: "República Dominicana",
    }
  }

  const handleSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault()

    if (stockErrors.length > 0) {
      toast({
        title: "Error de stock",
        description: "Algunos productos no tienen stock suficiente",
        variant: "destructive",
      })
      return
    }

    setIsSubmitting(true)

    try {
      const shippingAddress = getShippingAddress()

      // Create order in database
      const orderResponse = await fetch("/api/orders", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          customerEmail: formData.email,
          customerName: `${formData.nombre} ${formData.apellido}`.trim(),
          customerPhone: formData.telefono,
          shippingAddress,
          items: items.map((item) => ({
            productId: item.id,
            productName: item.name,
            productSku: item.sku || `SKU-${item.id.slice(0, 8)}`,
            productImage: item.image,
            quantity: item.quantity,
            unitPrice: item.price,
            taxRate: 18,
          })),
          customerNotes: formData.notas,
        }),
      })

      const orderData = await orderResponse.json()

      if (!orderResponse.ok) {
        throw new Error(orderData.error || "Error al crear el pedido")
      }

      setOrderCreated({
        id: orderData.order.id,
        orderNumber: orderData.order.order_number,
      })

      // Also send to Formspree for backup notification
      const formspreeData = new FormData()
      formspreeData.append("nombre", `${formData.nombre} ${formData.apellido}`)
      formspreeData.append("email", formData.email)
      formspreeData.append("telefono", formData.telefono)
      formspreeData.append("direccion", shippingAddress.street_address)
      formspreeData.append("ciudad", shippingAddress.city)
      formspreeData.append("provincia", shippingAddress.province)
      formspreeData.append("productos", items.map((i) => `${i.quantity}x ${i.name}`).join(", "))
      formspreeData.append("total", `RD$${finalTotal.toFixed(2)}`)
      formspreeData.append("pedido_numero", orderData.order.order_number)
      formspreeData.append("metodo_pago", paymentMethod)

      await fetch("https://formspree.io/f/xqaqeazb", {
        method: "POST",
        body: formspreeData,
        headers: { Accept: "application/json" },
      })

      // If payment method is transfer or cash, show success
      if (paymentMethod === "transfer" || paymentMethod === "cash_on_delivery") {
        toast({
          title: "Pedido creado exitosamente",
          description: `Tu número de pedido es ${orderData.order.order_number}`,
        })
        clearCart()
        router.push(`/pedido-confirmado?order=${orderData.order.id}`)
      } else if (paymentMethod === "paypal") {
        // For PayPal, we'll handle it differently
        // In production, you'd redirect to PayPal here
        toast({
          title: "Redirigiendo a PayPal",
          description: "Serás redirigido para completar el pago",
        })

        // Simulate PayPal confirmation for demo
        setTimeout(async () => {
          await fetch(`/api/orders/${orderData.order.id}/confirm-payment`, {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({
              paymentMethod: "paypal",
              transactionId: `PAYPAL-${Date.now()}`,
            }),
          })

          clearCart()
          router.push(`/pedido-confirmado?order=${orderData.order.id}`)
        }, 2000)
      }
    } catch (error) {
      toast({
        title: "Error",
        description: error instanceof Error ? error.message : "Hubo un problema. Por favor intenta de nuevo.",
        variant: "destructive",
      })
      setIsSubmitting(false)
    }
  }

  return (
    <div className="space-y-6">
      {/* Stock Errors */}
      {stockErrors.length > 0 && (
        <Alert variant="destructive">
          <AlertCircle className="h-4 w-4" />
          <AlertDescription>
            <strong>Problemas de stock:</strong>
            <ul className="mt-2 list-disc list-inside">
              {stockErrors.map((error, i) => (
                <li key={i}>{error}</li>
              ))}
            </ul>
          </AlertDescription>
        </Alert>
      )}

      {/* User Status */}
      {!user && (
        <Card className="border-dashed">
          <CardContent className="py-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <User className="h-5 w-5 text-muted-foreground" />
                <div>
                  <p className="font-medium">¿Ya tienes cuenta?</p>
                  <p className="text-sm text-muted-foreground">Inicia sesión para ver tus direcciones guardadas</p>
                </div>
              </div>
              <Button asChild variant="outline" size="sm">
                <Link href={`/cuenta/iniciar-sesion?redirect=/checkout`}>Iniciar Sesión</Link>
              </Button>
            </div>
          </CardContent>
        </Card>
      )}

      <form onSubmit={handleSubmit} className="space-y-6">
        {/* Saved Addresses */}
        {savedAddresses.length > 0 && (
          <Card>
            <CardHeader>
              <CardTitle className="text-lg flex items-center gap-2">
                <Truck className="h-5 w-5" />
                Dirección de Envío
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <RadioGroup
                value={useNewAddress ? "new" : selectedAddressId}
                onValueChange={(value) => {
                  if (value === "new") {
                    setUseNewAddress(true)
                  } else {
                    setUseNewAddress(false)
                    setSelectedAddressId(value)
                  }
                }}
              >
                {savedAddresses.map((address) => (
                  <div key={address.id} className="flex items-start space-x-3 p-3 border rounded-lg">
                    <RadioGroupItem value={address.id} id={address.id} className="mt-1" />
                    <label htmlFor={address.id} className="flex-1 cursor-pointer">
                      <p className="font-medium">{address.label}</p>
                      <p className="text-sm text-muted-foreground">
                        {address.full_name}, {address.street_address}
                      </p>
                      <p className="text-sm text-muted-foreground">
                        {address.city}, {address.province}
                      </p>
                    </label>
                  </div>
                ))}
                <div className="flex items-start space-x-3 p-3 border rounded-lg border-dashed">
                  <RadioGroupItem value="new" id="new-address" className="mt-1" />
                  <label htmlFor="new-address" className="cursor-pointer">
                    <p className="font-medium">Usar otra dirección</p>
                    <p className="text-sm text-muted-foreground">Ingresa una nueva dirección de envío</p>
                  </label>
                </div>
              </RadioGroup>
            </CardContent>
          </Card>
        )}

        {/* Contact & Address Form */}
        {(useNewAddress || savedAddresses.length === 0) && (
          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Información de Contacto y Envío</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="nombre">Nombre *</Label>
                  <Input
                    id="nombre"
                    value={formData.nombre}
                    onChange={(e) => setFormData({ ...formData, nombre: e.target.value })}
                    required
                    placeholder="Tu nombre"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="apellido">Apellido *</Label>
                  <Input
                    id="apellido"
                    value={formData.apellido}
                    onChange={(e) => setFormData({ ...formData, apellido: e.target.value })}
                    required
                    placeholder="Tu apellido"
                  />
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="email">Correo Electrónico *</Label>
                <Input
                  id="email"
                  type="email"
                  value={formData.email}
                  onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                  required
                  placeholder="tu@email.com"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="telefono">Teléfono *</Label>
                <Input
                  id="telefono"
                  type="tel"
                  value={formData.telefono}
                  onChange={(e) => setFormData({ ...formData, telefono: e.target.value })}
                  required
                  placeholder="809-000-0000"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="direccion">Dirección *</Label>
                <Input
                  id="direccion"
                  value={formData.direccion}
                  onChange={(e) => setFormData({ ...formData, direccion: e.target.value })}
                  required
                  placeholder="Calle, número, sector"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="direccion2">Apartamento, edificio, etc. (opcional)</Label>
                <Input
                  id="direccion2"
                  value={formData.direccion2}
                  onChange={(e) => setFormData({ ...formData, direccion2: e.target.value })}
                  placeholder="Apartamento 4B, Edificio Los Pinos"
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="ciudad">Ciudad *</Label>
                  <Input
                    id="ciudad"
                    value={formData.ciudad}
                    onChange={(e) => setFormData({ ...formData, ciudad: e.target.value })}
                    required
                    placeholder="Santo Domingo"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="provincia">Provincia *</Label>
                  <Select
                    value={formData.provincia}
                    onValueChange={(value) => setFormData({ ...formData, provincia: value })}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Selecciona" />
                    </SelectTrigger>
                    <SelectContent>
                      {provinces.map((province) => (
                        <SelectItem key={province} value={province}>
                          {province}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="notas">Notas del pedido (opcional)</Label>
                <Textarea
                  id="notas"
                  value={formData.notas}
                  onChange={(e) => setFormData({ ...formData, notas: e.target.value })}
                  placeholder="Instrucciones especiales para la entrega"
                  rows={3}
                />
              </div>
            </CardContent>
          </Card>
        )}

        {/* Payment Methods */}
        <Card>
          <CardHeader>
            <CardTitle className="text-lg flex items-center gap-2">
              <CreditCard className="h-5 w-5" />
              Método de Pago
            </CardTitle>
          </CardHeader>
          <CardContent>
            <RadioGroup
              value={paymentMethod}
              onValueChange={(value) => setPaymentMethod(value as PaymentMethod)}
              className="space-y-3"
            >
              <div
                className={`flex items-start space-x-3 p-4 border rounded-lg cursor-pointer transition-colors ${paymentMethod === "transfer" ? "border-primary bg-primary/5" : ""}`}
              >
                <RadioGroupItem value="transfer" id="transfer" className="mt-1" />
                <label htmlFor="transfer" className="flex-1 cursor-pointer">
                  <p className="font-medium">Transferencia Bancaria</p>
                  <p className="text-sm text-muted-foreground">
                    Te enviaremos los datos bancarios por correo electrónico
                  </p>
                </label>
              </div>

              <div
                className={`flex items-start space-x-3 p-4 border rounded-lg cursor-pointer transition-colors ${paymentMethod === "cash_on_delivery" ? "border-primary bg-primary/5" : ""}`}
              >
                <RadioGroupItem value="cash_on_delivery" id="cash_on_delivery" className="mt-1" />
                <label htmlFor="cash_on_delivery" className="flex-1 cursor-pointer">
                  <p className="font-medium">Pago Contra Entrega</p>
                  <p className="text-sm text-muted-foreground">Paga en efectivo cuando recibas tu pedido</p>
                </label>
              </div>

              <div
                className={`flex items-start space-x-3 p-4 border rounded-lg cursor-pointer transition-colors ${paymentMethod === "paypal" ? "border-primary bg-primary/5" : ""}`}
              >
                <RadioGroupItem value="paypal" id="paypal" className="mt-1" />
                <label htmlFor="paypal" className="flex-1 cursor-pointer">
                  <div className="flex items-center gap-2">
                    <p className="font-medium">PayPal</p>
                    <span className="text-xs bg-blue-100 text-blue-800 px-2 py-0.5 rounded">Seguro</span>
                  </div>
                  <p className="text-sm text-muted-foreground">Paga con tu cuenta PayPal o tarjeta de crédito</p>
                </label>
              </div>
            </RadioGroup>
          </CardContent>
        </Card>

        {/* Submit Button */}
        <Button
          type="submit"
          size="lg"
          className="w-full"
          disabled={isSubmitting || stockErrors.length > 0 || items.length === 0}
        >
          {isSubmitting ? (
            <>
              <Loader2 className="h-5 w-5 mr-2 animate-spin" />
              Procesando...
            </>
          ) : (
            <>
              <CheckCircle className="h-5 w-5 mr-2" />
              Confirmar Pedido - RD${finalTotal.toLocaleString("es-DO", { minimumFractionDigits: 2 })}
            </>
          )}
        </Button>

        <p className="text-xs text-center text-muted-foreground">
          Al confirmar tu pedido, aceptas nuestros{" "}
          <Link href="/terminos" className="underline">
            términos y condiciones
          </Link>{" "}
          y{" "}
          <Link href="/privacidad" className="underline">
            política de privacidad
          </Link>
        </p>
      </form>
    </div>
  )
}
