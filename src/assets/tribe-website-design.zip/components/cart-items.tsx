"use client"

import { useState } from "react"
import Image from "next/image"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { useCart } from "@/hooks/use-cart"
import { Minus, Plus, Trash2 } from "lucide-react"

export function CartItems() {
  const { items, updateQuantity, removeItem } = useCart()
  const [removingId, setRemovingId] = useState<string | null>(null)

  const handleRemove = (id: string) => {
    setRemovingId(id)
    setTimeout(() => {
      removeItem(id)
      setRemovingId(null)
    }, 200)
  }

  return (
    <div className="space-y-4">
      {items.map((item) => (
        <div
          key={item.id}
          className={`flex gap-4 p-4 bg-white border rounded-xl transition-all duration-200 ${
            removingId === item.id ? "opacity-0 scale-95" : "opacity-100"
          }`}
        >
          {/* Image */}
          <Link
            href={`/producto/${item.id}`}
            className="relative h-24 w-24 flex-shrink-0 bg-neutral-50 rounded-lg overflow-hidden"
          >
            <Image
              src={item.image || "/placeholder.svg?height=100&width=100"}
              alt={item.name}
              fill
              className="object-cover"
            />
          </Link>

          {/* Details */}
          <div className="flex-1 min-w-0">
            <Link href={`/producto/${item.id}`} className="font-medium hover:underline line-clamp-1">
              {item.name}
            </Link>
            {item.brand && <p className="text-sm text-muted-foreground">{item.brand}</p>}
            <p className="text-sm text-muted-foreground">RD${item.price.toLocaleString("es-DO")} c/u</p>

            {/* Quantity Controls */}
            <div className="flex items-center justify-between mt-3">
              <div className="flex items-center border rounded-lg">
                <Button
                  variant="ghost"
                  size="icon"
                  className="h-8 w-8 rounded-r-none"
                  onClick={() => updateQuantity(item.id, item.quantity - 1)}
                >
                  <Minus className="h-3 w-3" />
                </Button>
                <span className="w-8 text-center text-sm font-medium">{item.quantity}</span>
                <Button
                  variant="ghost"
                  size="icon"
                  className="h-8 w-8 rounded-l-none"
                  onClick={() => updateQuantity(item.id, item.quantity + 1)}
                >
                  <Plus className="h-3 w-3" />
                </Button>
              </div>

              <Button
                variant="ghost"
                size="sm"
                className="text-red-500 hover:text-red-600 hover:bg-red-50 h-8 px-2"
                onClick={() => handleRemove(item.id)}
              >
                <Trash2 className="h-4 w-4" />
              </Button>
            </div>
          </div>

          {/* Price */}
          <div className="text-right">
            <p className="font-bold">RD${(item.price * item.quantity).toLocaleString("es-DO")}</p>
          </div>
        </div>
      ))}
    </div>
  )
}
