"use client"

import { useEffect, useState } from "react"
import { useRouter } from "next/navigation"
import { useCart } from "@/hooks/use-cart"
import { useToast } from "@/hooks/use-toast"
import Script from "next/script"

interface PayPalButtonsProps {
  total: number
}

declare global {
  interface Window {
    paypal?: any
  }
}

export function PayPalButtons({ total }: PayPalButtonsProps) {
  const [loaded, setLoaded] = useState(false)
  const router = useRouter()
  const { clearCart } = useCart()
  const { toast } = useToast()

  useEffect(() => {
    if (loaded && window.paypal && typeof window.paypal.Buttons === 'function') {
      try {
        window.paypal
          .Buttons({
            createOrder: (data: any, actions: any) => {
              return actions.order.create({
                purchase_units: [
                  {
                    amount: {
                      value: total.toFixed(2),
                      currency_code: "USD",
                    },
                  },
                ],
              })
            },
            onApprove: async (data: any, actions: any) => {
              const order = await actions.order.capture()

              toast({
                title: "¡Pago completado!",
                description: "Tu pago ha sido procesado correctamente.",
              })

              clearCart()
              router.push("/")
            },
            onError: (err: any) => {
              toast({
                title: "Error en el pago",
                description: "Hubo un problema al procesar tu pago. Por favor, intenta de nuevo.",
                variant: "destructive",
              })
              console.error(err)
            },
          })
          .render("#paypal-button-container")
      } catch (error) {
        console.error("Error rendering PayPal buttons:", error)
      }
    } else if (loaded && window.paypal && typeof window.paypal.Buttons !== 'function') {
      console.warn("PayPal SDK loaded but Buttons is not available. This is expected in demo mode.")
    }
  }, [loaded, total, clearCart, router, toast])

  return (
    <>
      <Script src="https://www.paypal.com/sdk/js?client-id=test&currency=USD" onLoad={() => setLoaded(true)} />
      <div id="paypal-button-container" className="mt-4"></div>
    </>
  )
}
