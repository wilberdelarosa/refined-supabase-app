"use client"

import Link from "next/link"
import Image from "next/image"
import { usePathname } from "next/navigation"
import { cn } from "@/lib/utils"
import { useAuth } from "@/lib/auth/auth-context"
import {
  LayoutDashboard,
  Package,
  ShoppingCart,
  FileText,
  Users,
  FolderTree,
  Tags,
  ImageIcon,
  FileEdit,
  Settings,
  BarChart3,
  MessageSquare,
  History,
} from "lucide-react"
import { Button } from "@/components/ui/button"
import { ScrollArea } from "@/components/ui/scroll-area"
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet"
import { useState } from "react"

const navigation = [
  { name: "Dashboard", href: "/admin", icon: LayoutDashboard, permission: null },
  { name: "Pedidos", href: "/admin/pedidos", icon: ShoppingCart, permission: "orders.view" },
  { name: "Productos", href: "/admin/productos", icon: Package, permission: "products.*" },
  { name: "Categorías", href: "/admin/categorias", icon: FolderTree, permission: "products.*" },
  { name: "Marcas", href: "/admin/marcas", icon: Tags, permission: "products.*" },
  { name: "Facturas", href: "/admin/facturas", icon: FileText, permission: "invoices.*" },
  { name: "Clientes", href: "/admin/clientes", icon: Users, permission: "customers.view" },
  { name: "Blog", href: "/admin/blog", icon: FileEdit, permission: "content.*" },
  { name: "Banners", href: "/admin/banners", icon: ImageIcon, permission: "content.*" },
  { name: "Tickets", href: "/admin/tickets", icon: MessageSquare, permission: "tickets.*" },
  { name: "Reportes", href: "/admin/reportes", icon: BarChart3, permission: "audit.view" },
  { name: "Auditoría", href: "/admin/auditoria", icon: History, permission: "audit.view" },
  { name: "Configuración", href: "/admin/configuracion", icon: Settings, permission: null },
]

function SidebarContent({ onLinkClick }: { onLinkClick?: () => void }) {
  const pathname = usePathname()
  const { hasPermission, isAdmin } = useAuth()

  const filteredNavigation = navigation.filter((item) => !item.permission || isAdmin || hasPermission(item.permission))

  return (
    <div className="flex h-full flex-col">
      <div className="flex h-16 items-center gap-2 border-b px-6">
        <Link href="/admin" className="flex items-center gap-2" onClick={onLinkClick}>
          <Image src="/images/image.png" alt="Barbaro Nutrition" width={32} height={32} className="h-8 w-auto" />
          <span className="font-bold text-lg">Admin</span>
        </Link>
      </div>
      <ScrollArea className="flex-1 px-3 py-4">
        <nav className="space-y-1">
          {filteredNavigation.map((item) => {
            const isActive = pathname === item.href || (item.href !== "/admin" && pathname.startsWith(item.href))
            return (
              <Link
                key={item.name}
                href={item.href}
                onClick={onLinkClick}
                className={cn(
                  "flex items-center gap-3 rounded-lg px-3 py-2 text-sm font-medium transition-colors",
                  isActive
                    ? "bg-primary text-primary-foreground"
                    : "text-muted-foreground hover:bg-muted hover:text-foreground",
                )}
              >
                <item.icon className="h-5 w-5" />
                {item.name}
              </Link>
            )
          })}
        </nav>
      </ScrollArea>
      <div className="border-t p-4">
        <Link
          href="/"
          className="flex items-center gap-2 text-sm text-muted-foreground hover:text-foreground transition-colors"
          onClick={onLinkClick}
        >
          <span>← Volver a la tienda</span>
        </Link>
      </div>
    </div>
  )
}

export function AdminSidebar() {
  const [open, setOpen] = useState(false)

  return (
    <>
      {/* Desktop sidebar */}
      <div className="hidden lg:fixed lg:inset-y-0 lg:z-50 lg:flex lg:w-72 lg:flex-col">
        <div className="flex grow flex-col gap-y-5 overflow-y-auto border-r bg-background">
          <SidebarContent />
        </div>
      </div>

      {/* Mobile sidebar */}
      <Sheet open={open} onOpenChange={setOpen}>
        <SheetTrigger asChild>
          <Button variant="ghost" size="icon" className="lg:hidden fixed left-4 top-4 z-40">
            <svg className="h-6 w-6" fill="none" viewBox="0 0 24 24" strokeWidth="1.5" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" d="M3.75 6.75h16.5M3.75 12h16.5m-16.5 5.25h16.5" />
            </svg>
          </Button>
        </SheetTrigger>
        <SheetContent side="left" className="w-72 p-0">
          <SidebarContent onLinkClick={() => setOpen(false)} />
        </SheetContent>
      </Sheet>
    </>
  )
}
