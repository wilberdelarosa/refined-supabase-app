"use client"

import { usePathname } from "next/navigation"
import Link from "next/link"
import { Home, Store, ShoppingCart, User } from "lucide-react"
import { useCart } from "@/hooks/use-cart"
import { cn } from "@/lib/utils"

const navItems = [
    {
        href: "/",
        label: "Inicio",
        icon: Home,
    },
    {
        href: "/tienda",
        label: "Tienda",
        icon: Store,
    },
    {
        href: "/carrito",
        label: "Carrito",
        icon: ShoppingCart,
    },
    {
        href: "/sobre-nosotros",
        label: "Cuenta",
        icon: User,
    },
]

export function MobileNav() {
    const pathname = usePathname()
    const { items } = useCart()
    const totalItems = items.reduce((acc, item) => acc + item.quantity, 0)

    return (
        <nav className="fixed bottom-0 left-0 right-0 z-50 md:hidden safe-bottom bg-white/90 backdrop-blur-md border-t shadow-lg">
            <div className="grid grid-cols-4 h-16">
                {navItems.map((item) => {
                    const isActive = pathname === item.href
                    const Icon = item.icon
                    const isCart = item.href === "/carrito"

                    return (
                        <Link
                            key={item.href}
                            href={item.href}
                            className={cn(
                                "flex flex-col items-center justify-center gap-1 transition-all duration-300 relative group",
                                isActive
                                    ? "text-blue-600"
                                    : "text-gray-600 hover:text-blue-600 active:scale-95"
                            )}
                        >
                            {/* Active indicator */}
                            {isActive && (
                                <div className="absolute top-0 left-1/2 -translate-x-1/2 w-12 h-1 bg-black rounded-b-full shadow-lg"></div>
                            )}

                            <div className="relative">
                                <Icon
                                    className={cn(
                                        "h-6 w-6 transition-all duration-300",
                                        isActive && "text-black"
                                    )}
                                />

                                {/* Cart badge */}
                                {isCart && totalItems > 0 && (
                                    <span className="absolute -top-2 -right-2 bg-black text-white text-xs rounded-full h-5 w-5 flex items-center justify-center font-bold shadow-lg animate-bounce-subtle">
                                        {totalItems > 99 ? '99+' : totalItems}
                                    </span>
                                )}
                            </div>

                            <span className={cn(
                                "text-xs font-medium transition-all duration-300",
                                isActive ? "scale-95 font-semibold" : "scale-90"
                            )}>
                                {item.label}
                            </span>

                            {/* Tap feedback */}
                            <div className={cn(
                                "absolute inset-0 bg-blue-500/10 rounded-lg opacity-0 group-active:opacity-100 transition-opacity duration-150"
                            )}></div>
                        </Link>
                    )
                })}
            </div>
        </nav>
    )
}
