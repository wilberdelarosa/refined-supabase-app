import { Star, Quote } from "lucide-react"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"

const testimonials = [
  {
    id: 1,
    name: "Carlos Rodríguez",
    role: "Fisicoculturista",
    avatar: "/athletic-man-running.png",
    content:
      "Los suplementos de Barbaro Nutrition han sido clave en mi preparación para competencias. La calidad es excepcional y los resultados hablan por sí solos.",
    rating: 5,
  },
  {
    id: 2,
    name: "María Pérez",
    role: "Entrenadora Personal",
    avatar: "/fitness-woman.png",
    content:
      "Desde que empecé a usar los productos de Barbaro Nutrition, mi recuperación ha mejorado notablemente. Recomiendo especialmente la proteína whey.",
    rating: 5,
  },
  {
    id: 3,
    name: "Juan Méndez",
    role: "Atleta de CrossFit",
    avatar: "/crossfit-athlete.png",
    content:
      "Excelente servicio y productos de primera calidad. Los pre-entrenos me dan la energía que necesito para mis entrenamientos más intensos.",
    rating: 5,
  },
]

export function Testimonials() {
  return (
    <section className="py-16 md:py-24 bg-neutral-900 text-white">
      <div className="container mx-auto px-4">
        {/* Section Header */}
        <div className="text-center mb-12">
          <h2 className="text-3xl md:text-4xl font-bold mb-4">Lo Que Dicen Nuestros Clientes</h2>
          <p className="text-neutral-400 max-w-2xl mx-auto">
            Testimonios reales de atletas que confían en Barbaro Nutrition
          </p>
        </div>

        {/* Testimonials Grid */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 md:gap-8">
          {testimonials.map((testimonial) => (
            <div
              key={testimonial.id}
              className="relative bg-neutral-800/50 rounded-2xl p-6 md:p-8 border border-neutral-700/50"
            >
              {/* Quote Icon */}
              <Quote className="absolute top-6 right-6 h-8 w-8 text-neutral-700" />

              {/* Stars */}
              <div className="flex gap-1 mb-4">
                {Array.from({ length: testimonial.rating }).map((_, i) => (
                  <Star key={i} className="h-4 w-4 fill-yellow-500 text-yellow-500" />
                ))}
              </div>

              {/* Content */}
              <p className="text-neutral-300 mb-6 leading-relaxed">"{testimonial.content}"</p>

              {/* Author */}
              <div className="flex items-center gap-3">
                <Avatar className="h-12 w-12 border-2 border-neutral-600">
                  <AvatarImage src={testimonial.avatar || "/placeholder.svg"} alt={testimonial.name} />
                  <AvatarFallback className="bg-neutral-700 text-white">
                    {testimonial.name
                      .split(" ")
                      .map((n) => n[0])
                      .join("")}
                  </AvatarFallback>
                </Avatar>
                <div>
                  <p className="font-semibold">{testimonial.name}</p>
                  <p className="text-sm text-neutral-400">{testimonial.role}</p>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
