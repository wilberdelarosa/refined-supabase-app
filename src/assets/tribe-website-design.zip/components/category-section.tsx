import Link from "next/link"
import Image from "next/image"
import { ArrowRight } from "lucide-react"

const categories = [
  {
    name: "Proteínas",
    slug: "proteinas",
    image: "https://images.unsplash.com/photo-1593095948071-474c5cc2989d?w=400",
    description: "Whey, Isolate, Caseína",
  },
  {
    name: "Creatina",
    slug: "creatina",
    image: "https://images.unsplash.com/photo-1619731338445-4cf6b2a97e50?w=400",
    description: "Monohidrato, HCl",
  },
  {
    name: "Pre-Entrenos",
    slug: "pre-entrenos",
    image: "https://images.unsplash.com/photo-1546483875-ad9014c88eba?w=400",
    description: "Energía y enfoque",
  },
  {
    name: "Vitaminas",
    slug: "vitaminas-minerales",
    image: "https://images.unsplash.com/photo-1550572017-edd951aa8f72?w=400",
    description: "Multivitamínicos, Omega-3",
  },
]

export function CategorySection() {
  return (
    <section className="py-16 md:py-24 bg-neutral-50">
      <div className="container mx-auto px-4">
        {/* Section Header */}
        <div className="text-center mb-12">
          <h2 className="text-3xl md:text-4xl font-bold mb-4">Categorías</h2>
          <p className="text-muted-foreground max-w-2xl mx-auto">
            Explora nuestra selección de suplementos de las mejores marcas del mundo
          </p>
        </div>

        {/* Categories Grid */}
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 md:gap-6">
          {categories.map((category) => (
            <Link
              key={category.slug}
              href={`/tienda/${category.slug}`}
              className="group relative bg-white rounded-2xl overflow-hidden shadow-sm hover:shadow-lg transition-all duration-300"
            >
              {/* Image Container */}
              <div className="aspect-square relative overflow-hidden bg-neutral-100">
                <Image
                  src={category.image || "/placeholder.svg"}
                  alt={category.name}
                  fill
                  className="object-cover transition-transform duration-500 group-hover:scale-105"
                  sizes="(max-width: 768px) 50vw, 25vw"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-black/20 to-transparent" />
              </div>

              {/* Content */}
              <div className="absolute bottom-0 left-0 right-0 p-4 text-white">
                <h3 className="font-bold text-lg mb-1">{category.name}</h3>
                <p className="text-sm text-white/80 mb-2">{category.description}</p>
                <span className="inline-flex items-center text-sm font-medium group-hover:underline">
                  Ver productos
                  <ArrowRight className="ml-1 h-4 w-4 transition-transform group-hover:translate-x-1" />
                </span>
              </div>
            </Link>
          ))}
        </div>
      </div>
    </section>
  )
}
