export type NavItem = {
  label: string
  href: string
}

export type SiteContact = {
  location: string
  email: string
  phone: string
}

export type SocialLink = {
  label: string
  href: string
}

export type CategoryItem = {
  id: number
  name: string
  slug: string
  image: string
}

export const siteConfig = {
  name: "Barbaro Nutrition",
  title: "Barbaro Nutrition - Suplementos Deportivos",
  description: "Tienda de suplementos deportivos premium al mejor precio",
  nav: [
    { label: "INICIO", href: "/" },
    { label: "TIENDA", href: "/tienda" },
    { label: "SOBRE NOSOTROS", href: "/sobre-nosotros" },
    { label: "BLOG", href: "/blog" },
  ] satisfies NavItem[],
  categories: [
    { id: 1, name: "PROTEÍNAS", slug: "proteinas", image: "/protein-powder-silver.png" },
    { id: 2, name: "CREATINA", slug: "creatina", image: "/creatine-black-jar.png" },
    { id: 3, name: "VITAMINAS Y MINERALES", slug: "vitaminas-minerales", image: "/vitamin-white-bottle.png" },
    { id: 4, name: "PRE-ENTRENOS", slug: "pre-entrenos", image: "/pre-workout-black.png" },
  ] satisfies CategoryItem[],
  footerLinks: {
    enlaces: [
      { label: "Inicio", href: "/" },
      { label: "Tienda", href: "/tienda" },
      { label: "Sobre Nosotros", href: "/sobre-nosotros" },
      { label: "Blog", href: "/blog" },
    ],
    categorias: [
      { label: "Proteínas", href: "/tienda/proteinas" },
      { label: "Creatina", href: "/tienda/creatina" },
      { label: "Vitaminas y Minerales", href: "/tienda/vitaminas-minerales" },
      { label: "Pre-Entrenos", href: "/tienda/pre-entrenos" },
    ],
  },
  contact: {
    location: "Santo Domingo, República Dominicana",
    email: "info@barbaronutrition.com",
    phone: "+1 (809) 555-1234",
  } satisfies SiteContact,
  socials: [
    { label: "Facebook", href: "#" },
    { label: "Instagram", href: "#" },
    { label: "Twitter", href: "#" },
  ] satisfies SocialLink[],
} as const
