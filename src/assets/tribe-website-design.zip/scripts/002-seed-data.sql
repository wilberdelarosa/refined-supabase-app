-- Insertar categorías
INSERT INTO categories (name, slug, description, image) VALUES
  ('Proteínas', 'proteinas', 'Proteínas de alta calidad para recuperación y crecimiento muscular', '/images/categories/proteins.png'),
  ('Creatina', 'creatina', 'Creatina monohidrato para fuerza y rendimiento', '/images/categories/creatine.png'),
  ('Vitaminas y Minerales', 'vitaminas-minerales', 'Suplementos esenciales para tu salud', '/images/categories/vitamins.png'),
  ('Pre-Entrenos', 'pre-entrenos', 'Fórmulas pre-entrenamiento para máxima energía', '/images/categories/preworkout.png'),
  ('Aminoácidos', 'aminoacidos', 'BCAAs y aminoácidos esenciales', '/images/categories/aminos.png'),
  ('Ganadores de Masa', 'ganadores-masa', 'Fórmulas altas en calorías para ganar peso', '/images/categories/mass-gainers.png')
ON CONFLICT (slug) DO NOTHING;

-- Insertar marcas
INSERT INTO brands (name, logo, description) VALUES
  ('Optimum Nutrition', '/images/brands/on.png', 'Líder mundial en suplementos deportivos'),
  ('MuscleTech', '/images/brands/muscletech.png', 'Innovación en nutrición deportiva'),
  ('Dymatize', '/images/brands/dymatize.png', 'Calidad premium en proteínas'),
  ('Cellucor', '/images/brands/cellucor.png', 'Pre-entrenos de alto rendimiento'),
  ('BSN', '/images/brands/bsn.png', 'Nutrición para atletas de élite'),
  ('Universal Nutrition', '/images/brands/universal.png', 'Tradición en suplementación'),
  ('NOW Foods', '/images/brands/now.png', 'Suplementos naturales de calidad'),
  ('Scivation', '/images/brands/scivation.png', 'Especialistas en aminoácidos'),
  ('GAT Sport', '/images/brands/gat.png', 'Fuerza y rendimiento'),
  ('Rule One', '/images/brands/rule1.png', 'Proteína de nueva generación')
ON CONFLICT (name) DO NOTHING;

-- Insertar productos
INSERT INTO products (name, slug, description, price, compare_price, image, category_id, brand_id, stock, sku, featured, weight, servings, flavor) VALUES
  -- Proteínas
  ('Gold Standard 100% Whey', 'gold-standard-whey', 'La proteína de suero más vendida del mundo. 24g de proteína por porción con aminoácidos de rápida absorción para recuperación muscular óptima.', 2899.00, 3299.00, 'https://images.unsplash.com/photo-1593095948071-474c5cc2989d?w=500', (SELECT id FROM categories WHERE slug = 'proteinas'), (SELECT id FROM brands WHERE name = 'Optimum Nutrition'), 25, 'ON-GS-001', true, '2.27 kg', 74, 'Double Rich Chocolate'),
  
  ('ISO 100 Hydrolyzed', 'iso-100-hydrolyzed', 'Proteína hidrolizada de absorción ultra rápida. 25g de proteína pura con 0g de azúcar y lactosa.', 3499.00, 3999.00, 'https://images.unsplash.com/photo-1579722821273-0f6c7d44362f?w=500', (SELECT id FROM categories WHERE slug = 'proteinas'), (SELECT id FROM brands WHERE name = 'Dymatize'), 18, 'DYM-ISO-001', true, '2.3 kg', 71, 'Gourmet Chocolate'),
  
  ('Syntha-6 Edge', 'syntha-6-edge', 'Mezcla de proteínas de liberación prolongada. Perfecta textura y sabor con 24g de proteína por porción.', 2599.00, 2899.00, 'https://images.unsplash.com/photo-1594498653385-d5172c532c00?w=500', (SELECT id FROM categories WHERE slug = 'proteinas'), (SELECT id FROM brands WHERE name = 'BSN'), 20, 'BSN-S6E-001', false, '1.82 kg', 48, 'Chocolate Milkshake'),
  
  ('R1 Protein', 'r1-protein', 'Proteína de suero aislada de alta pureza. 25g de proteína con solo 1g de carbohidratos.', 2799.00, NULL, 'https://images.unsplash.com/photo-1571019614242-c5c5dee9f50b?w=500', (SELECT id FROM categories WHERE slug = 'proteinas'), (SELECT id FROM brands WHERE name = 'Rule One'), 15, 'R1-PRO-001', true, '2.27 kg', 76, 'Vanilla Ice Cream'),
  
  -- Creatina
  ('Platinum Creatine', 'platinum-creatine', 'Creatina monohidrato micronizada de la más alta pureza. 5g por porción para máxima fuerza y potencia.', 1499.00, 1799.00, 'https://images.unsplash.com/photo-1619731338445-4cf6b2a97e50?w=500', (SELECT id FROM categories WHERE slug = 'creatina'), (SELECT id FROM brands WHERE name = 'MuscleTech'), 30, 'MT-CRE-001', true, '400g', 80, 'Sin sabor'),
  
  ('Creatine Powder', 'creatine-powder', 'Creatina monohidrato pura sin aditivos. Aumenta fuerza, potencia y rendimiento muscular.', 1299.00, NULL, 'https://images.unsplash.com/photo-1584116831289-e53912463c35?w=500', (SELECT id FROM categories WHERE slug = 'creatina'), (SELECT id FROM brands WHERE name = 'Optimum Nutrition'), 35, 'ON-CRE-001', false, '300g', 57, 'Sin sabor'),
  
  ('Creatine HCl', 'creatine-hcl', 'Creatina HCl de alta absorción. Menor dosis, mismos resultados sin retención de agua.', 1699.00, 1999.00, 'https://images.unsplash.com/photo-1585238341710-4d3ff484184d?w=500', (SELECT id FROM categories WHERE slug = 'creatina'), (SELECT id FROM brands WHERE name = 'Cellucor'), 22, 'CEL-CRE-001', false, '120 caps', 120, 'Cápsulas'),
  
  -- Pre-Entrenos
  ('C4 Ultimate', 'c4-ultimate', 'Pre-entreno de alto estímulo con 300mg de cafeína, beta-alanina y citrulina para entrenamientos extremos.', 1899.00, 2199.00, 'https://images.unsplash.com/photo-1546483875-ad9014c88eba?w=500', (SELECT id FROM categories WHERE slug = 'pre-entrenos'), (SELECT id FROM brands WHERE name = 'Cellucor'), 28, 'CEL-C4U-001', true, '440g', 20, 'Icy Blue Razz'),
  
  ('Gold Standard Pre-Workout', 'gs-preworkout', 'Pre-entreno con 175mg de cafeína, creatina y beta-alanina. Energía sostenida sin crash.', 1599.00, NULL, 'https://images.unsplash.com/photo-1517836357463-d25dfeac3438?w=500', (SELECT id FROM categories WHERE slug = 'pre-entrenos'), (SELECT id FROM brands WHERE name = 'Optimum Nutrition'), 24, 'ON-PRE-001', false, '300g', 30, 'Fruit Punch'),
  
  ('Nitraflex', 'nitraflex', 'Pre-entreno con fórmula clínicamente dosificada. Máxima energía, bombeo y enfoque mental.', 1799.00, 2099.00, 'https://images.unsplash.com/photo-1434682881908-b43d0467b798?w=500', (SELECT id FROM categories WHERE slug = 'pre-entrenos'), (SELECT id FROM brands WHERE name = 'GAT Sport'), 16, 'GAT-NIT-001', true, '300g', 30, 'Black Cherry'),
  
  -- Vitaminas y Minerales
  ('Animal Pak', 'animal-pak', 'Paquete multivitamínico completo para atletas. Vitaminas, minerales, antioxidantes y enzimas digestivas.', 1299.00, NULL, 'https://images.unsplash.com/photo-1550572017-edd951aa8f72?w=500', (SELECT id FROM categories WHERE slug = 'vitaminas-minerales'), (SELECT id FROM brands WHERE name = 'Universal Nutrition'), 40, 'UNI-PAK-001', true, '44 paks', 44, 'Paquetes'),
  
  ('Omega-3 Fish Oil', 'omega-3-fish-oil', 'Ácidos grasos esenciales EPA y DHA para salud cardiovascular y cerebral.', 899.00, NULL, 'https://images.unsplash.com/photo-1577401239170-897942555fb3?w=500', (SELECT id FROM categories WHERE slug = 'vitaminas-minerales'), (SELECT id FROM brands WHERE name = 'NOW Foods'), 50, 'NOW-OME-001', false, '200 softgels', 200, 'Cápsulas'),
  
  ('Vitamin D3 5000 IU', 'vitamin-d3-5000', 'Vitamina D3 de alta potencia para huesos fuertes y sistema inmune saludable.', 599.00, NULL, 'https://images.unsplash.com/photo-1584308666744-24d5c474f2ae?w=500', (SELECT id FROM categories WHERE slug = 'vitaminas-minerales'), (SELECT id FROM brands WHERE name = 'NOW Foods'), 60, 'NOW-D3-001', false, '240 softgels', 240, 'Cápsulas'),
  
  -- Aminoácidos
  ('Xtend BCAA', 'xtend-bcaa', 'BCAAs en proporción 2:1:1 con electrolitos. Recuperación muscular y hidratación durante el entrenamiento.', 1399.00, 1699.00, 'https://images.unsplash.com/photo-1594381898411-846e7d193883?w=500', (SELECT id FROM categories WHERE slug = 'aminoacidos'), (SELECT id FROM brands WHERE name = 'Scivation'), 32, 'SCI-XTE-001', true, '420g', 30, 'Blue Raspberry'),
  
  ('Amino Energy', 'amino-energy', 'Aminoácidos esenciales con cafeína natural. Energía y recuperación en cualquier momento del día.', 1199.00, NULL, 'https://images.unsplash.com/photo-1579722821273-0f6c7d44362f?w=500', (SELECT id FROM categories WHERE slug = 'aminoacidos'), (SELECT id FROM brands WHERE name = 'Optimum Nutrition'), 28, 'ON-AME-001', false, '270g', 30, 'Grape'),
  
  -- Ganadores de Masa
  ('Serious Mass', 'serious-mass', 'Ganador de masa con 1250 calorías y 50g de proteína por porción. Ideal para hardgainers.', 2299.00, 2599.00, 'https://images.unsplash.com/photo-1593095948071-474c5cc2989d?w=500', (SELECT id FROM categories WHERE slug = 'ganadores-masa'), (SELECT id FROM brands WHERE name = 'Optimum Nutrition'), 12, 'ON-SER-001', true, '5.44 kg', 16, 'Chocolate'),
  
  ('Mass-Tech Extreme', 'mass-tech-extreme', 'Fórmula avanzada con 2000 calorías y 80g de proteína. Máximo aumento de masa muscular.', 2799.00, 3199.00, 'https://images.unsplash.com/photo-1571019614242-c5c5dee9f50b?w=500', (SELECT id FROM categories WHERE slug = 'ganadores-masa'), (SELECT id FROM brands WHERE name = 'MuscleTech'), 10, 'MT-MTE-001', false, '3.17 kg', 14, 'Triple Chocolate')
  
ON CONFLICT (slug) DO NOTHING;
