-- =====================================================
-- CONFIGURAR USUARIO ADMINISTRADOR
-- Ejecutar DESPUÉS de que el usuario se registre
-- =====================================================

-- Buscar el usuario por email y asignarle el rol de admin
UPDATE user_profiles
SET role_id = (SELECT id FROM roles WHERE name = 'admin')
WHERE user_id = (
  SELECT id FROM auth.users WHERE email = 'wilber.alitoeirl@gmail.com'
);

-- Si el perfil no existe, crearlo cuando el usuario se registre
-- Nota: Esto se maneja automáticamente con el trigger de la tabla auth.users

-- Verificar que el rol se asignó correctamente
SELECT 
  up.id,
  au.email,
  r.name as role_name,
  up.created_at
FROM user_profiles up
JOIN auth.users au ON au.id = up.user_id
JOIN roles r ON r.id = up.role_id
WHERE au.email = 'wilber.alitoeirl@gmail.com';
