-- =====================================================
-- DATOS INICIALES: ROLES Y CONFIGURACIÓN
-- =====================================================

-- Insertar roles
INSERT INTO roles (key, name, description, permissions) VALUES
  ('admin', 'Administrador', 'Acceso total al sistema', '["*"]'::jsonb),
  ('manager', 'Gerente de Tienda', 'Gestión de inventario, pedidos y facturas', '["orders.*", "products.*", "inventory.*", "invoices.*", "content.*", "audit.view"]'::jsonb),
  ('support', 'Soporte', 'Atención al cliente y gestión de tickets', '["orders.view", "orders.status.limited", "customers.view", "tickets.*"]'::jsonb),
  ('editor', 'Editor de Contenido', 'Gestión de blog, páginas y banners', '["content.*", "media.*"]'::jsonb),
  ('customer', 'Cliente', 'Usuario registrado que puede comprar', '["profile.*", "orders.own", "invoices.own", "tickets.own"]'::jsonb)
ON CONFLICT (key) DO NOTHING;

-- Configuración inicial de la tienda
INSERT INTO store_settings (key, value, description) VALUES
  ('store_name', '"Barbaro Nutrition"', 'Nombre de la tienda'),
  ('store_email', '"info@barbaronutrition.com"', 'Email de contacto'),
  ('store_phone', '"+1 809-555-0100"', 'Teléfono de contacto'),
  ('store_address', '{"street": "Av. 27 de Febrero", "city": "Santo Domingo", "country": "República Dominicana"}', 'Dirección física'),
  ('currency', '"DOP"', 'Moneda principal'),
  ('currency_symbol', '"RD$"', 'Símbolo de moneda'),
  ('tax_rate', '18', 'Tasa de impuesto ITBIS (%)'),
  ('tax_name', '"ITBIS"', 'Nombre del impuesto'),
  ('free_shipping_threshold', '2000', 'Monto mínimo para envío gratis'),
  ('shipping_cost', '250', 'Costo de envío estándar'),
  ('invoice_series', '"A"', 'Serie de facturación actual'),
  ('invoice_footer', '"Gracias por su compra. Esta factura es válida como comprobante fiscal."', 'Pie de factura'),
  ('social_instagram', '"@barbaronutrition"', 'Instagram'),
  ('social_facebook', '"barbaronutrition"', 'Facebook'),
  ('social_whatsapp', '"+18095550100"', 'WhatsApp')
ON CONFLICT (key) DO UPDATE SET value = EXCLUDED.value;
