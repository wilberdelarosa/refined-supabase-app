-- =====================================================
-- DATOS DE CATÁLOGO: CATEGORÍAS, MARCAS Y PRODUCTOS
-- =====================================================

-- Categorías
INSERT INTO categories (name, slug, description, image_url, sort_order, is_active) VALUES
  ('Proteínas', 'proteinas', 'Whey protein, caseína, proteína vegana y más', 'https://images.unsplash.com/photo-1593095948071-474c5cc2989d?w=400', 1, true),
  ('Creatina', 'creatina', 'Creatina monohidratada y fórmulas avanzadas', 'https://images.unsplash.com/photo-1579722821273-0f6c7d44362f?w=400', 2, true),
  ('Pre-Entrenos', 'pre-entrenos', 'Energía y enfoque para tus entrenamientos', 'https://images.unsplash.com/photo-1546483875-ad9014c88eba?w=400', 3, true),
  ('Vitaminas y Minerales', 'vitaminas-minerales', 'Suplementos esenciales para tu salud', 'https://images.unsplash.com/photo-1584308666744-24d5c474f2ae?w=400', 4, true),
  ('Aminoácidos', 'aminoacidos', 'BCAAs, glutamina y aminoácidos esenciales', 'https://images.unsplash.com/photo-1594381898411-846e7d193883?w=400', 5, true),
  ('Ganadores de Peso', 'ganadores-peso', 'Mass gainers para aumentar masa muscular', 'https://images.unsplash.com/photo-1532384748853-8f54a8f476e2?w=400', 6, true),
  ('Quemadores de Grasa', 'quemadores-grasa', 'Termogénicos y suplementos para definición', 'https://images.unsplash.com/photo-1517836357463-d25dfeac3438?w=400', 7, true),
  ('Accesorios', 'accesorios', 'Shakers, guantes, cinturones y más', 'https://images.unsplash.com/photo-1583454110551-21f2fa2afe61?w=400', 8, true)
ON CONFLICT (slug) DO NOTHING;

-- Marcas
INSERT INTO brands (name, slug, logo_url, description, is_active) VALUES
  ('Optimum Nutrition', 'optimum-nutrition', 'https://www.optimumnutrition.com/on/demandware.static/-/Library-Sites-SharedLibrary/default/dw1234567/images/logo.png', 'Líder mundial en nutrición deportiva', true),
  ('MuscleTech', 'muscletech', 'https://www.muscletech.com/cdn/shop/files/muscletech-logo.png', 'Tecnología de rendimiento muscular', true),
  ('Dymatize', 'dymatize', 'https://dymatize.com/cdn/shop/files/dymatize-logo.png', 'Nutrición atlética premium', true),
  ('BSN', 'bsn', 'https://www.bsnonline.com/images/logo.png', 'Bio-Engineered Supplements and Nutrition', true),
  ('Cellucor', 'cellucor', 'https://cellucor.com/cdn/shop/files/cellucor-logo.png', 'Innovación en suplementos', true),
  ('JYM Supplement Science', 'jym', 'https://jym.com/images/logo.png', 'Ciencia detrás de cada producto', true),
  ('MyProtein', 'myprotein', 'https://www.myprotein.com/images/logo.png', 'Nutrición deportiva accesible', true),
  ('Universal Nutrition', 'universal', 'https://www.universalnutrition.com/images/logo.png', 'Desde 1977, nutrición real', true),
  ('MuscleMeds', 'musclemeds', 'https://musclemeds.com/images/logo.png', 'Investigación y desarrollo avanzado', true),
  ('GAT Sport', 'gat-sport', 'https://gat-sport.com/images/logo.png', 'German American Technologies', true)
ON CONFLICT (slug) DO NOTHING;

-- Productos
INSERT INTO products (sku, name, slug, brand_id, category_id, short_description, description, price, compare_at_price, stock, status, is_featured) VALUES
  -- Proteínas
  ('ON-GS-001', 'Gold Standard 100% Whey 5lb', 'gold-standard-whey-5lb', 
    (SELECT id FROM brands WHERE slug = 'optimum-nutrition'),
    (SELECT id FROM categories WHERE slug = 'proteinas'),
    '24g de proteína por servicio, baja en grasas y carbohidratos',
    'Gold Standard 100% Whey de Optimum Nutrition es la proteína de suero más vendida del mundo. Cada porción proporciona 24 gramos de proteína de rápida absorción con bajo contenido de grasa y carbohidratos. Perfecta para después del entrenamiento.',
    4500.00, 5200.00, 25, 'published', true),
    
  ('ON-GS-002', 'Gold Standard 100% Whey 2lb', 'gold-standard-whey-2lb',
    (SELECT id FROM brands WHERE slug = 'optimum-nutrition'),
    (SELECT id FROM categories WHERE slug = 'proteinas'),
    '24g de proteína por servicio, formato conveniente',
    'La misma calidad Gold Standard en un formato más conveniente de 2 libras.',
    2200.00, 2500.00, 40, 'published', false),
    
  ('MT-NR-001', 'Nitro-Tech 4lb', 'nitro-tech-4lb',
    (SELECT id FROM brands WHERE slug = 'muscletech'),
    (SELECT id FROM categories WHERE slug = 'proteinas'),
    '30g de proteína con creatina incluida',
    'Nitro-Tech es una fórmula de proteína científicamente diseñada con 30g de proteína por servicio, incluyendo péptidos de suero y creatina para máximo rendimiento.',
    4200.00, 4800.00, 18, 'published', true),
    
  ('DYM-ISO-001', 'ISO100 Hydrolyzed 5lb', 'iso100-hydrolyzed-5lb',
    (SELECT id FROM brands WHERE slug = 'dymatize'),
    (SELECT id FROM categories WHERE slug = 'proteinas'),
    'Proteína hidrolizada de absorción ultra rápida',
    'ISO100 es proteína 100% hidrolizada para la absorción más rápida posible. Ideal para atletas serios que buscan recuperación óptima.',
    5800.00, 6500.00, 15, 'published', true),
    
  ('BSN-SYN-001', 'Syntha-6 5lb', 'syntha-6-5lb',
    (SELECT id FROM brands WHERE slug = 'bsn'),
    (SELECT id FROM categories WHERE slug = 'proteinas'),
    'Mezcla de proteínas de absorción prolongada',
    'Syntha-6 combina múltiples fuentes de proteína para una liberación sostenida de aminoácidos durante horas.',
    3800.00, 4200.00, 22, 'published', false),

  -- Creatina
  ('ON-CM-001', 'Creatine Powder 600g', 'on-creatine-600g',
    (SELECT id FROM brands WHERE slug = 'optimum-nutrition'),
    (SELECT id FROM categories WHERE slug = 'creatina'),
    'Creatina monohidratada micronizada pura',
    'Creatina monohidratada micronizada de Optimum Nutrition. 5 gramos por porción para aumentar fuerza y rendimiento.',
    1800.00, 2100.00, 35, 'published', true),
    
  ('MT-CC-001', 'Cell-Tech Creatine 3lb', 'cell-tech-creatine-3lb',
    (SELECT id FROM brands WHERE slug = 'muscletech'),
    (SELECT id FROM categories WHERE slug = 'creatina'),
    'Creatina con sistema de transporte de carbohidratos',
    'Cell-Tech utiliza un sistema avanzado de carbohidratos para maximizar la absorción de creatina y el llenado muscular.',
    2800.00, 3200.00, 20, 'published', false),
    
  ('UNI-CM-001', 'Creatine Caps 100 caps', 'universal-creatine-caps',
    (SELECT id FROM brands WHERE slug = 'universal'),
    (SELECT id FROM categories WHERE slug = 'creatina'),
    'Creatina en cápsulas convenientes',
    'Creatina monohidratada en formato de cápsulas para mayor conveniencia.',
    1200.00, 1400.00, 45, 'published', false),

  -- Pre-Entrenos
  ('CEL-C4-001', 'C4 Original 60 serv', 'c4-original-60serv',
    (SELECT id FROM brands WHERE slug = 'cellucor'),
    (SELECT id FROM categories WHERE slug = 'pre-entrenos'),
    'El pre-entreno más vendido de América',
    'C4 Original proporciona energía explosiva, enfoque mental y bombeo muscular. Con cafeína, beta-alanina y creatina nitrato.',
    2400.00, 2800.00, 30, 'published', true),
    
  ('MT-VX-001', 'Vapor X5 Next Gen', 'vapor-x5-next-gen',
    (SELECT id FROM brands WHERE slug = 'muscletech'),
    (SELECT id FROM categories WHERE slug = 'pre-entrenos'),
    'Pre-entreno de nueva generación con nootropicos',
    'Vapor X5 combina ingredientes para energía, fuerza, bombeo muscular y enfoque mental en una fórmula de próxima generación.',
    2600.00, 3000.00, 25, 'published', false),
    
  ('JYM-PRE-001', 'Pre JYM 30 serv', 'pre-jym-30serv',
    (SELECT id FROM brands WHERE slug = 'jym'),
    (SELECT id FROM categories WHERE slug = 'pre-entrenos'),
    'Pre-entreno con dosis completas, sin mezclas propietarias',
    'Pre JYM del Dr. Jim Stoppani incluye 13 ingredientes en dosis completas. Sin mezclas propietarias, sabes exactamente lo que tomas.',
    3200.00, 3600.00, 18, 'published', true),

  -- Aminoácidos
  ('ON-BCAA-001', 'BCAA 1000 200 caps', 'on-bcaa-1000-200caps',
    (SELECT id FROM brands WHERE slug = 'optimum-nutrition'),
    (SELECT id FROM categories WHERE slug = 'aminoacidos'),
    'BCAAs en proporción 2:1:1',
    'Aminoácidos de cadena ramificada (Leucina, Isoleucina, Valina) en proporción 2:1:1 para recuperación muscular.',
    1600.00, 1900.00, 40, 'published', false),
    
  ('CEL-BCAA-001', 'Alpha Amino 30 serv', 'cellucor-alpha-amino',
    (SELECT id FROM brands WHERE slug = 'cellucor'),
    (SELECT id FROM categories WHERE slug = 'aminoacidos'),
    'BCAAs con electrolitos para hidratación',
    'Alpha Amino combina BCAAs con electrolitos esenciales para hidratación y recuperación durante el entrenamiento.',
    1800.00, 2100.00, 28, 'published', false),

  -- Ganadores de Peso
  ('ON-SM-001', 'Serious Mass 12lb', 'serious-mass-12lb',
    (SELECT id FROM brands WHERE slug = 'optimum-nutrition'),
    (SELECT id FROM categories WHERE slug = 'ganadores-peso'),
    '1,250 calorías por porción para ganar masa',
    'Serious Mass es el ganador de peso definitivo con 1,250 calorías, 50g de proteína y más de 250g de carbohidratos por porción.',
    4800.00, 5400.00, 12, 'published', true),
    
  ('DYM-SM-001', 'Super Mass Gainer 6lb', 'dymatize-super-mass-gainer',
    (SELECT id FROM brands WHERE slug = 'dymatize'),
    (SELECT id FROM categories WHERE slug = 'ganadores-peso'),
    'Fórmula de alto contenido calórico',
    'Super Mass Gainer proporciona calorías de calidad y proteínas para hardgainers que buscan aumentar de peso.',
    3400.00, 3900.00, 20, 'published', false),

  -- Vitaminas
  ('ON-OP-001', 'Opti-Men 150 tabs', 'opti-men-150tabs',
    (SELECT id FROM brands WHERE slug = 'optimum-nutrition'),
    (SELECT id FROM categories WHERE slug = 'vitaminas-minerales'),
    'Multivitamínico completo para hombres activos',
    'Opti-Men es un sistema de nutrientes con más de 75 ingredientes activos para hombres que entrenan.',
    2200.00, 2600.00, 35, 'published', false),
    
  ('ON-OW-001', 'Opti-Women 120 caps', 'opti-women-120caps',
    (SELECT id FROM brands WHERE slug = 'optimum-nutrition'),
    (SELECT id FROM categories WHERE slug = 'vitaminas-minerales'),
    'Multivitamínico diseñado para mujeres activas',
    'Opti-Women incluye 23 vitaminas y minerales, 17 ingredientes especiales y botánicos específicos para mujeres.',
    1900.00, 2200.00, 30, 'published', false),

  -- Quemadores de Grasa
  ('CEL-SHD-001', 'Super HD 60 caps', 'cellucor-super-hd',
    (SELECT id FROM brands WHERE slug = 'cellucor'),
    (SELECT id FROM categories WHERE slug = 'quemadores-grasa'),
    'Termogénico con nootropicos',
    'Super HD combina ingredientes termogénicos con compuestos nootrópicos para energía, enfoque y quema de grasa.',
    2000.00, 2400.00, 25, 'published', false),
    
  ('MT-HX-001', 'Hydroxycut Hardcore Elite', 'hydroxycut-hardcore-elite',
    (SELECT id FROM brands WHERE slug = 'muscletech'),
    (SELECT id FROM categories WHERE slug = 'quemadores-grasa'),
    'Quemador de grasa de alta potencia',
    'Hydroxycut Hardcore Elite es una fórmula termogénica avanzada con ingredientes clínicamente estudiados.',
    1800.00, 2100.00, 22, 'published', true)
ON CONFLICT (sku) DO NOTHING;

-- Imágenes de productos
INSERT INTO product_images (product_id, url, alt_text, sort_order, is_primary)
SELECT 
  p.id,
  CASE 
    WHEN p.slug LIKE '%whey%' THEN 'https://images.unsplash.com/photo-1593095948071-474c5cc2989d?w=600'
    WHEN p.slug LIKE '%creatine%' OR p.slug LIKE '%creatina%' THEN 'https://images.unsplash.com/photo-1579722821273-0f6c7d44362f?w=600'
    WHEN p.slug LIKE '%c4%' OR p.slug LIKE '%pre%' OR p.slug LIKE '%vapor%' THEN 'https://images.unsplash.com/photo-1546483875-ad9014c88eba?w=600'
    WHEN p.slug LIKE '%bcaa%' OR p.slug LIKE '%amino%' THEN 'https://images.unsplash.com/photo-1594381898411-846e7d193883?w=600'
    WHEN p.slug LIKE '%mass%' THEN 'https://images.unsplash.com/photo-1532384748853-8f54a8f476e2?w=600'
    WHEN p.slug LIKE '%opti%' THEN 'https://images.unsplash.com/photo-1584308666744-24d5c474f2ae?w=600'
    ELSE 'https://images.unsplash.com/photo-1593095948071-474c5cc2989d?w=600'
  END,
  p.name || ' - Imagen principal',
  0,
  true
FROM products p
WHERE NOT EXISTS (SELECT 1 FROM product_images pi WHERE pi.product_id = p.id);
