-- =====================================================
-- CATÁLOGO EXPANDIDO DE PRODUCTOS BARBARO NUTRITION
-- Más de 60 productos organizados por categoría
-- =====================================================

-- Limpiar datos anteriores para empezar fresco
DELETE FROM product_images;
DELETE FROM products;
DELETE FROM brands;
DELETE FROM categories;

-- =====================================================
-- CATEGORÍAS
-- =====================================================
INSERT INTO categories (name, slug, description, image_url, sort_order, is_active) VALUES
  ('Proteínas', 'proteinas', 'Whey protein, caseína, proteína vegana, isolate y más', 'https://images.unsplash.com/photo-1593095948071-474c5cc2989d?w=800', 1, true),
  ('Creatina', 'creatina', 'Creatina monohidratada, HCL, y fórmulas avanzadas', 'https://images.unsplash.com/photo-1579722821273-0f6c7d44362f?w=800', 2, true),
  ('Pre-Entrenos', 'pre-entrenos', 'Energía y enfoque para tus entrenamientos más intensos', 'https://images.unsplash.com/photo-1534438327276-14e5300c3a48?w=800', 3, true),
  ('Vitaminas y Minerales', 'vitaminas-minerales', 'Multivitamínicos, vitamina D, zinc y más', 'https://images.unsplash.com/photo-1584308666744-24d5c474f2ae?w=800', 4, true),
  ('Aminoácidos', 'aminoacidos', 'BCAAs, EAAs, glutamina y aminoácidos esenciales', 'https://images.unsplash.com/photo-1594381898411-846e7d193883?w=800', 5, true),
  ('Ganadores de Peso', 'ganadores-peso', 'Mass gainers para aumentar masa muscular', 'https://images.unsplash.com/photo-1532384748853-8f54a8f476e2?w=800', 6, true),
  ('Quemadores de Grasa', 'quemadores-grasa', 'Termogénicos, L-carnitina y suplementos de definición', 'https://images.unsplash.com/photo-1517836357463-d25dfeac3438?w=800', 7, true),
  ('Energía y Rendimiento', 'energia-rendimiento', 'Cafeína, bebidas energéticas y potenciadores', 'https://images.unsplash.com/photo-1571019613454-1cb2f99b2d8b?w=800', 8, true),
  ('Salud y Bienestar', 'salud-bienestar', 'Omega-3, colágeno, probióticos y más', 'https://images.unsplash.com/photo-1505576399279-565b52d4ac71?w=800', 9, true),
  ('Accesorios', 'accesorios', 'Shakers, bolsos, guantes y accesorios de gym', 'https://images.unsplash.com/photo-1583454110551-21f2fa2afe61?w=800', 10, true);

-- =====================================================
-- MARCAS
-- =====================================================
INSERT INTO brands (name, slug, logo_url, description, is_active) VALUES
  ('Optimum Nutrition', 'optimum-nutrition', 'https://i.imgur.com/Kg8GPVK.png', 'La marca #1 en nutrición deportiva mundial', true),
  ('MuscleTech', 'muscletech', 'https://i.imgur.com/VQYx0Lm.png', 'Tecnología de rendimiento muscular avanzada', true),
  ('Dymatize', 'dymatize', 'https://i.imgur.com/XnRw8jE.png', 'Nutrición atlética premium desde 1994', true),
  ('BSN', 'bsn', 'https://i.imgur.com/9QKpZLm.png', 'Bio-Engineered Supplements and Nutrition', true),
  ('Cellucor', 'cellucor', 'https://i.imgur.com/2mGjYKs.png', 'Innovación en suplementos de rendimiento', true),
  ('JYM Supplement Science', 'jym', 'https://i.imgur.com/7YKpNLm.png', 'Ciencia real detrás de cada producto', true),
  ('MyProtein', 'myprotein', 'https://i.imgur.com/8QKpMLm.png', 'Nutrición deportiva accesible de calidad', true),
  ('Universal Nutrition', 'universal', 'https://i.imgur.com/4QKpOLm.png', 'Desde 1977, nutrición real para atletas reales', true),
  ('MuscleMeds', 'musclemeds', 'https://i.imgur.com/5QKpPLm.png', 'Investigación y desarrollo avanzado', true),
  ('GAT Sport', 'gat-sport', 'https://i.imgur.com/6QKpQLm.png', 'German American Technologies', true),
  ('EVL Nutrition', 'evl-nutrition', 'https://i.imgur.com/3QKpRLm.png', 'Evolución en suplementación', true),
  ('Rule One Proteins', 'rule-one', 'https://i.imgur.com/1QKpSLm.png', 'Proteínas de la más alta calidad', true),
  ('Ghost', 'ghost', 'https://i.imgur.com/2QKpTLm.png', 'Suplementos con sabores legendarios', true),
  ('Redcon1', 'redcon1', 'https://i.imgur.com/0QKpULm.png', 'Grado militar en suplementación', true),
  ('Allmax Nutrition', 'allmax', 'https://i.imgur.com/AQKpVLm.png', 'Máxima calidad, máximos resultados', true);

-- =====================================================
-- PROTEÍNAS (15 productos)
-- =====================================================
INSERT INTO products (sku, name, slug, brand_id, category_id, short_description, description, price, compare_at_price, stock, status, is_featured) VALUES
  ('ON-GS-5LB-CH', 'Gold Standard 100% Whey 5lb Chocolate', 'gold-standard-whey-5lb-chocolate', 
    (SELECT id FROM brands WHERE slug = 'optimum-nutrition'),
    (SELECT id FROM categories WHERE slug = 'proteinas'),
    '24g proteína, 5.5g BCAAs por servicio',
    'La proteína de suero #1 del mundo. Gold Standard 100% Whey proporciona 24g de proteína de alta calidad con solo 1g de grasa y 3g de carbohidratos. Contiene enzimas digestivas para mejor absorción. Sabor Chocolate Double Rich.',
    4500.00, 5200.00, 45, 'published', true),
    
  ('ON-GS-5LB-VN', 'Gold Standard 100% Whey 5lb Vainilla', 'gold-standard-whey-5lb-vainilla', 
    (SELECT id FROM brands WHERE slug = 'optimum-nutrition'),
    (SELECT id FROM categories WHERE slug = 'proteinas'),
    '24g proteína, sabor vainilla premium',
    'Gold Standard Whey sabor Vanilla Ice Cream. La misma fórmula premium con un sabor clásico y delicioso.',
    4500.00, 5200.00, 38, 'published', true),

  ('ON-GS-2LB-CH', 'Gold Standard 100% Whey 2lb Chocolate', 'gold-standard-whey-2lb-chocolate', 
    (SELECT id FROM brands WHERE slug = 'optimum-nutrition'),
    (SELECT id FROM categories WHERE slug = 'proteinas'),
    'Formato conveniente de 2 libras',
    'Gold Standard Whey en presentación de 2 libras. Perfecto para probar el producto o para viajes.',
    2200.00, 2500.00, 60, 'published', false),
    
  ('MT-NR-4LB', 'Nitro-Tech 100% Whey Gold 4lb', 'nitro-tech-whey-gold-4lb',
    (SELECT id FROM brands WHERE slug = 'muscletech'),
    (SELECT id FROM categories WHERE slug = 'proteinas'),
    '24g proteína ultra pura, filtración superior',
    'Nitro-Tech Whey Gold utiliza péptidos de suero y aislado para una proteína ultra pura. Ideal para construcción muscular y recuperación.',
    4200.00, 4800.00, 32, 'published', true),

  ('MT-NR-4LB-CK', 'Nitro-Tech 100% Whey Gold 4lb Cookies', 'nitro-tech-whey-gold-4lb-cookies',
    (SELECT id FROM brands WHERE slug = 'muscletech'),
    (SELECT id FROM categories WHERE slug = 'proteinas'),
    'Sabor Cookies & Cream irresistible',
    'Nitro-Tech Whey Gold sabor Cookies & Cream. El mejor sabor con la mejor ciencia.',
    4200.00, 4800.00, 28, 'published', false),
    
  ('DYM-ISO-5LB', 'ISO100 Hydrolyzed 5lb Chocolate', 'iso100-hydrolyzed-5lb-chocolate',
    (SELECT id FROM brands WHERE slug = 'dymatize'),
    (SELECT id FROM categories WHERE slug = 'proteinas'),
    '25g proteína hidrolizada, absorción ultra rápida',
    'ISO100 es 100% proteína de suero hidrolizada para la absorción más rápida. 0g de azúcar, ideal para atletas serios.',
    5800.00, 6500.00, 22, 'published', true),

  ('DYM-ISO-5LB-FD', 'ISO100 Hydrolyzed 5lb Fruity Pebbles', 'iso100-hydrolyzed-5lb-fruity',
    (SELECT id FROM brands WHERE slug = 'dymatize'),
    (SELECT id FROM categories WHERE slug = 'proteinas'),
    'Colaboración exclusiva con Fruity Pebbles',
    'ISO100 con el icónico sabor de Fruity Pebbles. Proteína premium con sabor de cereal.',
    6200.00, 7000.00, 15, 'published', true),
    
  ('BSN-SYN-5LB', 'Syntha-6 5lb Chocolate Milkshake', 'syntha-6-5lb-chocolate',
    (SELECT id FROM brands WHERE slug = 'bsn'),
    (SELECT id FROM categories WHERE slug = 'proteinas'),
    '22g proteína, mezcla de 6 fuentes',
    'Syntha-6 combina 6 fuentes de proteína de absorción rápida y lenta para nutrición prolongada. Textura cremosa incomparable.',
    3800.00, 4200.00, 35, 'published', false),

  ('R1-PROT-5LB', 'R1 Protein 5lb Chocolate Fudge', 'r1-protein-5lb-chocolate',
    (SELECT id FROM brands WHERE slug = 'rule-one'),
    (SELECT id FROM categories WHERE slug = 'proteinas'),
    '25g proteína isolate, cero rellenos',
    'Rule 1 Protein es 100% aislado de suero sin aminoácidos añadidos ni rellenos. Proteína real, resultados reales.',
    4800.00, 5400.00, 25, 'published', false),

  ('GH-WHEY-5LB', 'Ghost Whey 5lb Oreo', 'ghost-whey-5lb-oreo',
    (SELECT id FROM brands WHERE slug = 'ghost'),
    (SELECT id FROM categories WHERE slug = 'proteinas'),
    'Colaboración oficial con Oreo',
    'Ghost Whey con sabor oficial de Oreo. 25g de proteína con el sabor de tu galleta favorita.',
    5200.00, 5800.00, 20, 'published', true),

  ('GH-WHEY-5LB-CB', 'Ghost Whey 5lb Chips Ahoy', 'ghost-whey-5lb-chips-ahoy',
    (SELECT id FROM brands WHERE slug = 'ghost'),
    (SELECT id FROM categories WHERE slug = 'proteinas'),
    'Colaboración oficial con Chips Ahoy',
    'Ghost Whey sabor Chips Ahoy. Proteína premium con sabores legendarios.',
    5200.00, 5800.00, 18, 'published', false),

  ('MP-WHEY-5LB', 'Impact Whey Protein 5lb', 'myprotein-impact-whey-5lb',
    (SELECT id FROM brands WHERE slug = 'myprotein'),
    (SELECT id FROM categories WHERE slug = 'proteinas'),
    '21g proteína, excelente relación calidad-precio',
    'Impact Whey de MyProtein ofrece proteína de alta calidad a precio accesible. Ideal para uso diario.',
    3200.00, 3800.00, 50, 'published', false),

  ('RC1-ISO-5LB', 'Isotope 5lb Chocolate', 'redcon1-isotope-5lb',
    (SELECT id FROM brands WHERE slug = 'redcon1'),
    (SELECT id FROM categories WHERE slug = 'proteinas'),
    '25g isolate, grado militar',
    'Isotope de Redcon1 es 100% aislado de suero de grado militar. Máxima pureza para máximos resultados.',
    4600.00, 5200.00, 28, 'published', false),

  ('ALL-ISOF-5LB', 'IsoFlex 5lb Chocolate', 'allmax-isoflex-5lb',
    (SELECT id FROM brands WHERE slug = 'allmax'),
    (SELECT id FROM categories WHERE slug = 'proteinas'),
    '27g proteína isolate por servicio',
    'IsoFlex de Allmax es uno de los aislados más puros disponibles. 27g de proteína por scoop.',
    5400.00, 6000.00, 22, 'published', false),

  ('EVL-ISO-5LB', 'Stacked Protein 5lb', 'evl-stacked-protein-5lb',
    (SELECT id FROM brands WHERE slug = 'evl-nutrition'),
    (SELECT id FROM categories WHERE slug = 'proteinas'),
    '25g proteína, mezcla de aislado y concentrado',
    'Stacked Protein combina aislado e hidrolizado de suero para una proteína completa y deliciosa.',
    3600.00, 4200.00, 30, 'published', false);

-- =====================================================
-- CREATINA (10 productos)
-- =====================================================
INSERT INTO products (sku, name, slug, brand_id, category_id, short_description, description, price, compare_at_price, stock, status, is_featured) VALUES
  ('ON-CREAT-600', 'Micronized Creatine Powder 600g', 'on-creatine-powder-600g',
    (SELECT id FROM brands WHERE slug = 'optimum-nutrition'),
    (SELECT id FROM categories WHERE slug = 'creatina'),
    'Creatina monohidratada micronizada pura',
    'Creatina monohidratada Creapure de Optimum Nutrition. Micronizada para mejor absorción. 120 porciones de 5g.',
    1800.00, 2100.00, 65, 'published', true),

  ('ON-CREAT-300', 'Micronized Creatine Powder 300g', 'on-creatine-powder-300g',
    (SELECT id FROM brands WHERE slug = 'optimum-nutrition'),
    (SELECT id FROM categories WHERE slug = 'creatina'),
    'Formato conveniente de 60 porciones',
    'La misma creatina premium de ON en presentación de 300g.',
    1100.00, 1300.00, 80, 'published', false),

  ('MT-CELL-3LB', 'Cell-Tech Creatine 3lb', 'muscletech-cell-tech-3lb',
    (SELECT id FROM brands WHERE slug = 'muscletech'),
    (SELECT id FROM categories WHERE slug = 'creatina'),
    'Creatina + carbohidratos para máximo transporte',
    'Cell-Tech usa un sistema de transporte de carbohidratos para maximizar la absorción de creatina y el volumen muscular.',
    2800.00, 3200.00, 35, 'published', true),

  ('MT-PLAT-400', 'Platinum 100% Creatine 400g', 'muscletech-platinum-creatine-400g',
    (SELECT id FROM brands WHERE slug = 'muscletech'),
    (SELECT id FROM categories WHERE slug = 'creatina'),
    'Creatina HPLC-tested, máxima pureza',
    'Platinum Creatine de MuscleTech es creatina monohidratada probada por HPLC para garantizar pureza.',
    1400.00, 1700.00, 55, 'published', false),

  ('DYM-CREAT-500', 'Creatine Monohydrate 500g', 'dymatize-creatine-500g',
    (SELECT id FROM brands WHERE slug = 'dymatize'),
    (SELECT id FROM categories WHERE slug = 'creatina'),
    'Creatina micronizada de alta calidad',
    'Creatina monohidratada de Dymatize. 100 porciones para mejorar fuerza y rendimiento.',
    1500.00, 1800.00, 48, 'published', false),

  ('GH-CREAT-300', 'Ghost Size Creatine 300g', 'ghost-size-creatine-300g',
    (SELECT id FROM brands WHERE slug = 'ghost'),
    (SELECT id FROM categories WHERE slug = 'creatina'),
    'Creatina + epicatechina para volumen',
    'Ghost Size combina creatina monohidratada con epicatechina y betaína para máximo volumen muscular.',
    2200.00, 2600.00, 30, 'published', true),

  ('CEL-COR-400', 'COR-Performance Creatine 400g', 'cellucor-creatine-400g',
    (SELECT id FROM brands WHERE slug = 'cellucor'),
    (SELECT id FROM categories WHERE slug = 'creatina'),
    'Creatina micronizada sin sabor',
    'Creatina monohidratada micronizada de Cellucor. Se mezcla fácilmente con cualquier bebida.',
    1300.00, 1500.00, 42, 'published', false),

  ('ALL-CREAT-400', 'Creatine Monohydrate 400g', 'allmax-creatine-400g',
    (SELECT id FROM brands WHERE slug = 'allmax'),
    (SELECT id FROM categories WHERE slug = 'creatina'),
    'Creatina farmacéutica alemana',
    'Allmax utiliza creatina Creapure de Alemania, el estándar de oro en pureza.',
    1600.00, 1900.00, 38, 'published', false),

  ('RC1-CREAT-300', 'Total War Creatine 300g', 'redcon1-creatine-300g',
    (SELECT id FROM brands WHERE slug = 'redcon1'),
    (SELECT id FROM categories WHERE slug = 'creatina'),
    'Creatina monohidratada grado militar',
    'Creatina de Redcon1 para atletas serios. Aumenta fuerza, potencia y volumen muscular.',
    1400.00, 1700.00, 45, 'published', false),

  ('UN-CREAT-200', 'Creatine 200 Capsules', 'universal-creatine-200caps',
    (SELECT id FROM brands WHERE slug = 'universal'),
    (SELECT id FROM categories WHERE slug = 'creatina'),
    'Creatina en cápsulas convenientes',
    'Creatina en cápsulas de Universal Nutrition. Perfecto para quienes prefieren no tomar polvo.',
    1200.00, 1400.00, 52, 'published', false);

-- =====================================================
-- PRE-ENTRENOS (12 productos)
-- =====================================================
INSERT INTO products (sku, name, slug, brand_id, category_id, short_description, description, price, compare_at_price, stock, status, is_featured) VALUES
  ('CEL-C4-60', 'C4 Original 60 Servicios Pink Lemonade', 'c4-original-60-pink-lemonade',
    (SELECT id FROM brands WHERE slug = 'cellucor'),
    (SELECT id FROM categories WHERE slug = 'pre-entrenos'),
    'El pre-entreno #1 de América',
    'C4 Original proporciona energía explosiva con 150mg de cafeína, beta-alanina para resistencia y creatina nitrato para fuerza.',
    2400.00, 2800.00, 48, 'published', true),

  ('CEL-C4-60-WM', 'C4 Original 60 Servicios Watermelon', 'c4-original-60-watermelon',
    (SELECT id FROM brands WHERE slug = 'cellucor'),
    (SELECT id FROM categories WHERE slug = 'pre-entrenos'),
    'Sabor refrescante de sandía',
    'C4 Original sabor Watermelon. La misma fórmula probada con un sabor refrescante.',
    2400.00, 2800.00, 42, 'published', false),

  ('CEL-C4-ULT', 'C4 Ultimate 20 Servicios', 'c4-ultimate-20',
    (SELECT id FROM brands WHERE slug = 'cellucor'),
    (SELECT id FROM categories WHERE slug = 'pre-entrenos'),
    '300mg cafeína, fórmula avanzada',
    'C4 Ultimate es la versión más potente de C4 con 300mg de cafeína y dosis clínicas de cada ingrediente.',
    2200.00, 2600.00, 35, 'published', true),

  ('GH-LEGEND-25', 'Ghost Legend V2 25 Servicios', 'ghost-legend-v2-25',
    (SELECT id FROM brands WHERE slug = 'ghost'),
    (SELECT id FROM categories WHERE slug = 'pre-entrenos'),
    'Pre-entreno con sabores legendarios',
    'Ghost Legend V2 con citrulina, beta-alanina, cafeína y enfoque nootropico. Sabores de colaboración exclusivos.',
    2800.00, 3200.00, 30, 'published', true),

  ('GH-LEGEND-SOUR', 'Ghost Legend Sour Patch Kids', 'ghost-legend-sour-patch',
    (SELECT id FROM brands WHERE slug = 'ghost'),
    (SELECT id FROM categories WHERE slug = 'pre-entrenos'),
    'Colaboración con Sour Patch Kids',
    'Ghost Legend con el sabor oficial de Sour Patch Kids. Pre-entreno épico con sabor épico.',
    3000.00, 3400.00, 25, 'published', true),

  ('RC1-TOTAL-30', 'Total War Pre-Workout 30 Servicios', 'redcon1-total-war-30',
    (SELECT id FROM brands WHERE slug = 'redcon1'),
    (SELECT id FROM categories WHERE slug = 'pre-entrenos'),
    'Pre-entreno grado militar',
    'Total War de Redcon1 es un pre-entreno de alta intensidad con 320mg de cafeína y citrulina malato.',
    2600.00, 3000.00, 38, 'published', true),

  ('MT-VAPOR-30', 'Vapor X5 Next Gen 30 Servicios', 'muscletech-vapor-x5-30',
    (SELECT id FROM brands WHERE slug = 'muscletech'),
    (SELECT id FROM categories WHERE slug = 'pre-entrenos'),
    'Pre-entreno con enfoque mental avanzado',
    'Vapor X5 combina energía, fuerza, bombeo y enfoque en una fórmula completa de nueva generación.',
    2600.00, 3000.00, 32, 'published', false),

  ('JYM-PRE-30', 'Pre JYM 30 Servicios Rainbow Sherbet', 'pre-jym-30-rainbow',
    (SELECT id FROM brands WHERE slug = 'jym'),
    (SELECT id FROM categories WHERE slug = 'pre-entrenos'),
    'Sin mezclas propietarias, dosis completas',
    'Pre JYM del Dr. Jim Stoppani tiene 13 ingredientes con dosis clínicas completas. Sabes exactamente lo que tomas.',
    3200.00, 3600.00, 25, 'published', true),

  ('BSN-NO-30', 'N.O.-Xplode 30 Servicios', 'bsn-no-xplode-30',
    (SELECT id FROM brands WHERE slug = 'bsn'),
    (SELECT id FROM categories WHERE slug = 'pre-entrenos'),
    'El pre-entreno clásico de BSN',
    'N.O.-Xplode ha sido un favorito por años, proporcionando energía, enfoque y bombeo muscular.',
    2200.00, 2600.00, 40, 'published', false),

  ('EVL-ENGN-30', 'ENGN Pre-Workout 30 Servicios', 'evl-engn-30',
    (SELECT id FROM brands WHERE slug = 'evl-nutrition'),
    (SELECT id FROM categories WHERE slug = 'pre-entrenos'),
    'Pre-entreno potente y económico',
    'ENGN de EVL proporciona energía intensa, enfoque y bombeo a un precio accesible.',
    1800.00, 2200.00, 45, 'published', false),

  ('ALL-IMPACT-30', 'Impact Igniter 30 Servicios', 'allmax-impact-igniter-30',
    (SELECT id FROM brands WHERE slug = 'allmax'),
    (SELECT id FROM categories WHERE slug = 'pre-entrenos'),
    'Pre-entreno completo de Allmax',
    'Impact Igniter combina cafeína, citrulina, beta-alanina y más para un entrenamiento explosivo.',
    2400.00, 2800.00, 35, 'published', false),

  ('GAT-NITRAF-30', 'Nitraflex 30 Servicios', 'gat-nitraflex-30',
    (SELECT id FROM brands WHERE slug = 'gat-sport'),
    (SELECT id FROM categories WHERE slug = 'pre-entrenos'),
    'Pre-entreno con soporte de testosterona',
    'Nitraflex de GAT es único por incluir ingredientes que apoyan los niveles de testosterona mientras entrenas.',
    2600.00, 3000.00, 28, 'published', false);

-- =====================================================
-- AMINOÁCIDOS (10 productos)
-- =====================================================
INSERT INTO products (sku, name, slug, brand_id, category_id, short_description, description, price, compare_at_price, stock, status, is_featured) VALUES
  ('ON-BCAA-400', 'BCAA 5000 Powder 400g', 'on-bcaa-5000-powder-400g',
    (SELECT id FROM brands WHERE slug = 'optimum-nutrition'),
    (SELECT id FROM categories WHERE slug = 'aminoacidos'),
    '5g BCAAs en ratio 2:1:1',
    'BCAA 5000 de ON proporciona 5 gramos de aminoácidos de cadena ramificada en proporción 2:1:1 por porción.',
    1800.00, 2100.00, 55, 'published', true),

  ('ON-BCAA-200C', 'BCAA 1000 Caps 200 Cápsulas', 'on-bcaa-1000-200caps',
    (SELECT id FROM brands WHERE slug = 'optimum-nutrition'),
    (SELECT id FROM categories WHERE slug = 'aminoacidos'),
    'BCAAs en cápsulas convenientes',
    'BCAAs de Optimum Nutrition en formato de cápsulas para consumo fácil en cualquier momento.',
    1600.00, 1900.00, 48, 'published', false),

  ('CEL-ALPHA-30', 'Alpha Amino 30 Servicios Icy Blue', 'cellucor-alpha-amino-30',
    (SELECT id FROM brands WHERE slug = 'cellucor'),
    (SELECT id FROM categories WHERE slug = 'aminoacidos'),
    'BCAAs + electrolitos para hidratación',
    'Alpha Amino combina 14 aminoácidos incluyendo BCAAs con electrolitos para hidratación intra-entreno.',
    1800.00, 2100.00, 42, 'published', true),

  ('GH-AMINO-40', 'Ghost Amino 40 Servicios', 'ghost-amino-40',
    (SELECT id FROM brands WHERE slug = 'ghost'),
    (SELECT id FROM categories WHERE slug = 'aminoacidos'),
    'EAAs completos + hidratación',
    'Ghost Amino tiene los 9 aminoácidos esenciales más electrolitos. Sabores épicos de colaboración.',
    2200.00, 2600.00, 35, 'published', true),

  ('MT-AMINO-300', 'Amino Build 300g', 'muscletech-amino-build-300g',
    (SELECT id FROM brands WHERE slug = 'muscletech'),
    (SELECT id FROM categories WHERE slug = 'aminoacidos'),
    'BCAAs + electrolitos + betaína',
    'Amino Build combina BCAAs con ingredientes adicionales para recuperación y rendimiento.',
    1600.00, 1900.00, 40, 'published', false),

  ('RC1-GRUNT-30', 'Grunt EAA 30 Servicios', 'redcon1-grunt-eaa-30',
    (SELECT id FROM brands WHERE slug = 'redcon1'),
    (SELECT id FROM categories WHERE slug = 'aminoacidos'),
    '9 EAAs esenciales, sabores épicos',
    'Grunt de Redcon1 proporciona los 9 aminoácidos esenciales que tu cuerpo necesita para construir músculo.',
    2000.00, 2400.00, 38, 'published', false),

  ('ALL-AMINO-400', 'AminoCore 400g', 'allmax-aminocore-400g',
    (SELECT id FROM brands WHERE slug = 'allmax'),
    (SELECT id FROM categories WHERE slug = 'aminoacidos'),
    '8.18g BCAAs por porción',
    'AminoCore de Allmax tiene una de las dosis más altas de BCAAs por porción del mercado.',
    2000.00, 2400.00, 32, 'published', false),

  ('ON-GLUT-300', 'Glutamine Powder 300g', 'on-glutamine-powder-300g',
    (SELECT id FROM brands WHERE slug = 'optimum-nutrition'),
    (SELECT id FROM categories WHERE slug = 'aminoacidos'),
    '5g glutamina pura por porción',
    'Glutamina de Optimum Nutrition para recuperación muscular y salud intestinal.',
    1400.00, 1700.00, 45, 'published', false),

  ('EVL-BCAA-30', 'BCAA Energy 30 Servicios', 'evl-bcaa-energy-30',
    (SELECT id FROM brands WHERE slug = 'evl-nutrition'),
    (SELECT id FROM categories WHERE slug = 'aminoacidos'),
    'BCAAs + cafeína natural',
    'BCAA Energy combina aminoácidos con cafeína natural para energía y recuperación.',
    1500.00, 1800.00, 50, 'published', false),

  ('JYM-POST-30', 'Post JYM 30 Servicios', 'jym-post-jym-30',
    (SELECT id FROM brands WHERE slug = 'jym'),
    (SELECT id FROM categories WHERE slug = 'aminoacidos'),
    'Recuperación post-entreno completa',
    'Post JYM tiene BCAAs, glutamina, creatina y más para recuperación óptima después del entrenamiento.',
    2800.00, 3200.00, 25, 'published', true);

-- =====================================================
-- GANADORES DE PESO (6 productos)
-- =====================================================
INSERT INTO products (sku, name, slug, brand_id, category_id, short_description, description, price, compare_at_price, stock, status, is_featured) VALUES
  ('ON-SM-12LB', 'Serious Mass 12lb Chocolate', 'on-serious-mass-12lb-chocolate',
    (SELECT id FROM brands WHERE slug = 'optimum-nutrition'),
    (SELECT id FROM categories WHERE slug = 'ganadores-peso'),
    '1,250 calorías, 50g proteína por porción',
    'Serious Mass es el ganador de peso definitivo con 1,250 calorías de calidad, 50g de proteína y más de 250g de carbohidratos.',
    4800.00, 5400.00, 18, 'published', true),

  ('ON-SM-6LB', 'Serious Mass 6lb Vainilla', 'on-serious-mass-6lb-vainilla',
    (SELECT id FROM brands WHERE slug = 'optimum-nutrition'),
    (SELECT id FROM categories WHERE slug = 'ganadores-peso'),
    'Formato mediano de Serious Mass',
    'Serious Mass en presentación de 6 libras. Perfecto para probar o para atletas con menor consumo.',
    2800.00, 3200.00, 25, 'published', false),

  ('DYM-SUPER-6LB', 'Super Mass Gainer 6lb', 'dymatize-super-mass-6lb',
    (SELECT id FROM brands WHERE slug = 'dymatize'),
    (SELECT id FROM categories WHERE slug = 'ganadores-peso'),
    '1,280 calorías, 52g proteína',
    'Super Mass Gainer de Dymatize proporciona calorías de calidad y proteína para hardgainers.',
    3400.00, 3900.00, 22, 'published', false),

  ('BSN-TRUE-10LB', 'True Mass 10lb', 'bsn-true-mass-10lb',
    (SELECT id FROM brands WHERE slug = 'bsn'),
    (SELECT id FROM categories WHERE slug = 'ganadores-peso'),
    'Ganador de peso ultra premium',
    'True Mass de BSN usa una matriz de proteínas de múltiples fuentes para nutrición sostenida.',
    4200.00, 4800.00, 15, 'published', true),

  ('MT-MASS-7LB', 'Mass Tech Extreme 2000 7lb', 'muscletech-mass-tech-7lb',
    (SELECT id FROM brands WHERE slug = 'muscletech'),
    (SELECT id FROM categories WHERE slug = 'ganadores-peso'),
    '2,000 calorías, 80g proteína',
    'Mass Tech Extreme tiene una de las dosis más altas de calorías y proteína del mercado.',
    4600.00, 5200.00, 12, 'published', false),

  ('UN-REALGAIN-6LB', 'Real Gains 6lb', 'universal-real-gains-6lb',
    (SELECT id FROM brands WHERE slug = 'universal'),
    (SELECT id FROM categories WHERE slug = 'ganadores-peso'),
    'Ganador de peso tradicional',
    'Real Gains de Universal es un ganador de peso clásico con proteína de calidad y carbohidratos complejos.',
    3000.00, 3500.00, 20, 'published', false);

-- =====================================================
-- QUEMADORES DE GRASA (8 productos)
-- =====================================================
INSERT INTO products (sku, name, slug, brand_id, category_id, short_description, description, price, compare_at_price, stock, status, is_featured) VALUES
  ('CEL-SHD-60', 'Super HD 60 Cápsulas', 'cellucor-super-hd-60',
    (SELECT id FROM brands WHERE slug = 'cellucor'),
    (SELECT id FROM categories WHERE slug = 'quemadores-grasa'),
    'Termogénico con nootropicos',
    'Super HD combina ingredientes termogénicos con compuestos nootrópicos para energía, enfoque y quema de grasa.',
    2000.00, 2400.00, 40, 'published', true),

  ('MT-HYDRO-100', 'Hydroxycut Hardcore Elite 100 Caps', 'muscletech-hydroxycut-100',
    (SELECT id FROM brands WHERE slug = 'muscletech'),
    (SELECT id FROM categories WHERE slug = 'quemadores-grasa'),
    'Quemador de grasa de alta potencia',
    'Hydroxycut Hardcore Elite es un termogénico avanzado respaldado por estudios clínicos.',
    1800.00, 2100.00, 35, 'published', true),

  ('GH-BURN-40', 'Ghost Burn 40 Servicios', 'ghost-burn-40',
    (SELECT id FROM brands WHERE slug = 'ghost'),
    (SELECT id FROM categories WHERE slug = 'quemadores-grasa'),
    'Quemador de grasa sabor épico',
    'Ghost Burn es un termogénico en polvo con sabores legendarios. Energía y metabolismo acelerado.',
    2400.00, 2800.00, 28, 'published', true),

  ('RC1-DOUBLE-60', 'Double Tap 60 Cápsulas', 'redcon1-double-tap-60',
    (SELECT id FROM brands WHERE slug = 'redcon1'),
    (SELECT id FROM categories WHERE slug = 'quemadores-grasa'),
    'Quemador de grasa grado militar',
    'Double Tap de Redcon1 es un quemador de grasa potente para atletas serios sobre su definición.',
    2200.00, 2600.00, 32, 'published', false),

  ('EVL-LEANM-60', 'LeanMode 60 Cápsulas', 'evl-leanmode-60',
    (SELECT id FROM brands WHERE slug = 'evl-nutrition'),
    (SELECT id FROM categories WHERE slug = 'quemadores-grasa'),
    'Quemador de grasa sin estimulantes',
    'LeanMode es un quemador de grasa sin cafeína, perfecto para uso nocturno o personas sensibles.',
    1600.00, 1900.00, 45, 'published', false),

  ('ON-LCAR-500', 'L-Carnitine 500mg 60 Tabs', 'on-l-carnitine-500-60',
    (SELECT id FROM brands WHERE slug = 'optimum-nutrition'),
    (SELECT id FROM categories WHERE slug = 'quemadores-grasa'),
    'L-Carnitina para transporte de grasas',
    'L-Carnitina de ON ayuda a transportar ácidos grasos a las mitocondrias para ser usados como energía.',
    1200.00, 1500.00, 55, 'published', false),

  ('ALL-LCAR-LIQ', 'Liquid L-Carnitine 473ml', 'allmax-liquid-carnitine-473ml',
    (SELECT id FROM brands WHERE slug = 'allmax'),
    (SELECT id FROM categories WHERE slug = 'quemadores-grasa'),
    'L-Carnitina líquida de rápida absorción',
    'L-Carnitina líquida de Allmax para absorción rápida. 1500mg por porción.',
    1400.00, 1700.00, 40, 'published', false),

  ('GAT-JETFUEL-90', 'JetFuel Superburn 90 Caps', 'gat-jetfuel-90',
    (SELECT id FROM brands WHERE slug = 'gat-sport'),
    (SELECT id FROM categories WHERE slug = 'quemadores-grasa'),
    'Termogénico de triple acción',
    'JetFuel Superburn actúa en 3 frentes: termogénesis, control de apetito y energía sostenida.',
    2000.00, 2400.00, 30, 'published', false);

-- =====================================================
-- VITAMINAS Y MINERALES (8 productos)
-- =====================================================
INSERT INTO products (sku, name, slug, brand_id, category_id, short_description, description, price, compare_at_price, stock, status, is_featured) VALUES
  ('ON-OPTIM-150', 'Opti-Men 150 Tabletas', 'on-opti-men-150',
    (SELECT id FROM brands WHERE slug = 'optimum-nutrition'),
    (SELECT id FROM categories WHERE slug = 'vitaminas-minerales'),
    'Multivitamínico completo para hombres',
    'Opti-Men contiene más de 75 ingredientes activos incluyendo vitaminas, minerales, aminoácidos y extractos botánicos.',
    2200.00, 2600.00, 45, 'published', true),

  ('ON-OPTIW-120', 'Opti-Women 120 Cápsulas', 'on-opti-women-120',
    (SELECT id FROM brands WHERE slug = 'optimum-nutrition'),
    (SELECT id FROM categories WHERE slug = 'vitaminas-minerales'),
    'Multivitamínico diseñado para mujeres',
    'Opti-Women incluye 23 vitaminas y minerales más 17 ingredientes especiales específicos para mujeres activas.',
    1900.00, 2200.00, 40, 'published', true),

  ('UN-ANIM-44', 'Animal Pak 44 Packs', 'universal-animal-pak-44',
    (SELECT id FROM brands WHERE slug = 'universal'),
    (SELECT id FROM categories WHERE slug = 'vitaminas-minerales'),
    'El multivitamínico de los campeones',
    'Animal Pak de Universal ha sido usado por culturistas profesionales por décadas. Packs completos de nutrientes.',
    2800.00, 3200.00, 30, 'published', true),

  ('ON-FISH-200', 'Fish Oil 200 Softgels', 'on-fish-oil-200',
    (SELECT id FROM brands WHERE slug = 'optimum-nutrition'),
    (SELECT id FROM categories WHERE slug = 'vitaminas-minerales'),
    'Omega-3 de alta pureza',
    'Fish Oil de ON proporciona ácidos grasos EPA y DHA esenciales para salud cardiovascular y recuperación.',
    1400.00, 1700.00, 50, 'published', false),

  ('ON-VITD-200', 'Vitamin D 5000 IU 200 Caps', 'on-vitamin-d-200',
    (SELECT id FROM brands WHERE slug = 'optimum-nutrition'),
    (SELECT id FROM categories WHERE slug = 'vitaminas-minerales'),
    'Vitamina D3 de alta potencia',
    'Vitamina D3 esencial para salud ósea, inmunidad y función muscular. 5000 IU por cápsula.',
    1100.00, 1300.00, 60, 'published', false),

  ('EVL-VITAM-120', 'VitaMode 120 Tabletas', 'evl-vitamode-120',
    (SELECT id FROM brands WHERE slug = 'evl-nutrition'),
    (SELECT id FROM categories WHERE slug = 'vitaminas-minerales'),
    'Multivitamínico completo económico',
    'VitaMode de EVL ofrece un multivitamínico completo a precio accesible para atletas.',
    1500.00, 1800.00, 55, 'published', false),

  ('ALL-VITA-60', 'VitaStack 30 Packs', 'allmax-vitastack-30',
    (SELECT id FROM brands WHERE slug = 'allmax'),
    (SELECT id FROM categories WHERE slug = 'vitaminas-minerales'),
    'Packs de vitaminas para atletas',
    'VitaStack de Allmax proporciona vitaminas, minerales y electrolitos en packs convenientes.',
    2400.00, 2800.00, 35, 'published', false),

  ('ON-ZMA-90', 'ZMA 90 Cápsulas', 'on-zma-90',
    (SELECT id FROM brands WHERE slug = 'optimum-nutrition'),
    (SELECT id FROM categories WHERE slug = 'vitaminas-minerales'),
    'Zinc, Magnesio y B6 para recuperación',
    'ZMA de ON combina zinc, magnesio y vitamina B6 para apoyar la recuperación y el sueño.',
    1300.00, 1500.00, 48, 'published', false);

-- =====================================================
-- SALUD Y BIENESTAR (4 productos)
-- =====================================================
INSERT INTO products (sku, name, slug, brand_id, category_id, short_description, description, price, compare_at_price, stock, status, is_featured) VALUES
  ('ON-COLAG-200', 'Gold Standard Collagen 200g', 'on-collagen-200g',
    (SELECT id FROM brands WHERE slug = 'optimum-nutrition'),
    (SELECT id FROM categories WHERE slug = 'salud-bienestar'),
    'Colágeno hidrolizado + Vitamina C',
    'Colágeno de Optimum Nutrition con vitamina C para piel, cabello, uñas y articulaciones saludables.',
    1800.00, 2100.00, 35, 'published', true),

  ('ALL-OMEGA-180', 'Omega-3 180 Softgels', 'allmax-omega3-180',
    (SELECT id FROM brands WHERE slug = 'allmax'),
    (SELECT id FROM categories WHERE slug = 'salud-bienestar'),
    'Aceite de pescado de alta pureza',
    'Omega-3 de Allmax con EPA y DHA de alta concentración para salud cardiovascular y antiinflamación.',
    1600.00, 1900.00, 40, 'published', false),

  ('EVL-PROB-40', 'Probiotic 40 Billion', 'evl-probiotic-40billion',
    (SELECT id FROM brands WHERE slug = 'evl-nutrition'),
    (SELECT id FROM categories WHERE slug = 'salud-bienestar'),
    'Probióticos de alta potencia',
    'Probiotic de EVL con 40 billones de CFU de múltiples cepas para salud digestiva óptima.',
    1400.00, 1700.00, 45, 'published', false),

  ('UN-JOINT-60', 'Animal Flex 44 Packs', 'universal-animal-flex-44',
    (SELECT id FROM brands WHERE slug = 'universal'),
    (SELECT id FROM categories WHERE slug = 'salud-bienestar'),
    'Complejo completo para articulaciones',
    'Animal Flex de Universal protege articulaciones, ligamentos y tendones de atletas que entrenan duro.',
    2600.00, 3000.00, 28, 'published', true);

-- =====================================================
-- ACCESORIOS (4 productos)
-- =====================================================
INSERT INTO products (sku, name, slug, brand_id, category_id, short_description, description, price, compare_at_price, stock, status, is_featured) VALUES
  ('ACC-SHAK-ON', 'Shaker Optimum Nutrition 700ml', 'shaker-on-700ml',
    (SELECT id FROM brands WHERE slug = 'optimum-nutrition'),
    (SELECT id FROM categories WHERE slug = 'accesorios'),
    'Shaker oficial de Optimum Nutrition',
    'Shaker de 700ml con tapa anti-derrames y bola mezcladora. Logo oficial de Optimum Nutrition.',
    450.00, 550.00, 80, 'published', false),

  ('ACC-SHAK-GH', 'Ghost Shaker 700ml', 'ghost-shaker-700ml',
    (SELECT id FROM brands WHERE slug = 'ghost'),
    (SELECT id FROM categories WHERE slug = 'accesorios'),
    'Shaker Ghost edición limitada',
    'Shaker Ghost con diseño exclusivo. Perfecto para mezclar tus suplementos favoritos.',
    550.00, 650.00, 60, 'published', true),

  ('ACC-SHAK-RC1', 'Redcon1 Shaker 800ml', 'redcon1-shaker-800ml',
    (SELECT id FROM brands WHERE slug = 'redcon1'),
    (SELECT id FROM categories WHERE slug = 'accesorios'),
    'Shaker militar Redcon1',
    'Shaker Redcon1 de 800ml con compartimento para suplementos. Diseño militar.',
    500.00, 600.00, 55, 'published', false),

  ('ACC-GUANT-UN', 'Guantes Universal Nutrition', 'guantes-universal',
    (SELECT id FROM brands WHERE slug = 'universal'),
    (SELECT id FROM categories WHERE slug = 'accesorios'),
    'Guantes de entrenamiento profesionales',
    'Guantes de gimnasio Universal Nutrition con muñequera integrada y agarre premium.',
    850.00, 1000.00, 40, 'published', false);

-- =====================================================
-- IMÁGENES DE PRODUCTOS
-- =====================================================
INSERT INTO product_images (product_id, url, alt_text, sort_order, is_primary)
SELECT 
  p.id,
  CASE 
    -- Proteínas
    WHEN p.slug LIKE '%gold-standard%' AND p.slug LIKE '%chocolate%' THEN 'https://m.media-amazon.com/images/I/71SRCwJX7qL._AC_SL1500_.jpg'
    WHEN p.slug LIKE '%gold-standard%' AND p.slug LIKE '%vainilla%' THEN 'https://m.media-amazon.com/images/I/71XUi8TZt3L._AC_SL1500_.jpg'
    WHEN p.slug LIKE '%nitro-tech%' THEN 'https://m.media-amazon.com/images/I/71B3-17MAUL._AC_SL1500_.jpg'
    WHEN p.slug LIKE '%iso100%' AND p.slug LIKE '%chocolate%' THEN 'https://m.media-amazon.com/images/I/71C5i2GpZnL._AC_SL1500_.jpg'
    WHEN p.slug LIKE '%iso100%' AND p.slug LIKE '%fruity%' THEN 'https://m.media-amazon.com/images/I/71LwXQJsLyL._AC_SL1500_.jpg'
    WHEN p.slug LIKE '%syntha-6%' THEN 'https://m.media-amazon.com/images/I/71Gj6NU5kvL._AC_SL1500_.jpg'
    WHEN p.slug LIKE '%ghost-whey%' AND p.slug LIKE '%oreo%' THEN 'https://m.media-amazon.com/images/I/61yt+hMNg0L._AC_SL1500_.jpg'
    WHEN p.slug LIKE '%ghost-whey%' AND p.slug LIKE '%chips%' THEN 'https://m.media-amazon.com/images/I/61FFZoVRvGL._AC_SL1500_.jpg'
    WHEN p.slug LIKE '%r1-protein%' THEN 'https://m.media-amazon.com/images/I/71gfX-BRVhL._AC_SL1500_.jpg'
    WHEN p.slug LIKE '%redcon1-isotope%' THEN 'https://m.media-amazon.com/images/I/61O8F5Q6W1L._AC_SL1500_.jpg'
    WHEN p.slug LIKE '%myprotein%' THEN 'https://m.media-amazon.com/images/I/61xJzXQRMfL._AC_SL1500_.jpg'
    WHEN p.slug LIKE '%allmax-isoflex%' THEN 'https://m.media-amazon.com/images/I/71T7f7tJ+jL._AC_SL1500_.jpg'
    WHEN p.slug LIKE '%evl-stacked%' THEN 'https://m.media-amazon.com/images/I/71JbQbJNj0L._AC_SL1500_.jpg'
    -- Creatina
    WHEN p.slug LIKE '%on-creatine%' THEN 'https://m.media-amazon.com/images/I/61TcgFaU4hL._AC_SL1200_.jpg'
    WHEN p.slug LIKE '%cell-tech%' THEN 'https://m.media-amazon.com/images/I/71IuWPrn3CL._AC_SL1500_.jpg'
    WHEN p.slug LIKE '%ghost-size%' THEN 'https://m.media-amazon.com/images/I/617mJRZ9kUL._AC_SL1500_.jpg'
    WHEN p.slug LIKE '%muscletech-platinum%' THEN 'https://m.media-amazon.com/images/I/71Kg7pXFg0L._AC_SL1500_.jpg'
    WHEN p.slug LIKE '%dymatize-creatine%' THEN 'https://m.media-amazon.com/images/I/61cVbB6F3sL._AC_SL1500_.jpg'
    WHEN p.slug LIKE '%cellucor-creatine%' THEN 'https://m.media-amazon.com/images/I/61gKwYeRk6L._AC_SL1500_.jpg'
    WHEN p.slug LIKE '%allmax-creatine%' THEN 'https://m.media-amazon.com/images/I/71Cg7LS3eeL._AC_SL1500_.jpg'
    WHEN p.slug LIKE '%redcon1-creatine%' THEN 'https://m.media-amazon.com/images/I/61pWdGDHn0L._AC_SL1500_.jpg'
    WHEN p.slug LIKE '%universal-creatine%' THEN 'https://m.media-amazon.com/images/I/71JU1r-hUxL._AC_SL1500_.jpg'
    -- Pre-entrenos
    WHEN p.slug LIKE '%c4-original%' AND p.slug LIKE '%pink%' THEN 'https://m.media-amazon.com/images/I/61dYO5VTIHL._AC_SL1500_.jpg'
    WHEN p.slug LIKE '%c4-original%' AND p.slug LIKE '%watermelon%' THEN 'https://m.media-amazon.com/images/I/61NfB3vpTsL._AC_SL1500_.jpg'
    WHEN p.slug LIKE '%c4-ultimate%' THEN 'https://m.media-amazon.com/images/I/61zALMK9GhL._AC_SL1500_.jpg'
    WHEN p.slug LIKE '%ghost-legend%' AND NOT p.slug LIKE '%sour%' THEN 'https://m.media-amazon.com/images/I/61+fXvZQ2WL._AC_SL1500_.jpg'
    WHEN p.slug LIKE '%ghost-legend%' AND p.slug LIKE '%sour%' THEN 'https://m.media-amazon.com/images/I/61Bnl8KpYQL._AC_SL1500_.jpg'
    WHEN p.slug LIKE '%total-war%' THEN 'https://m.media-amazon.com/images/I/71k9mF7pHSL._AC_SL1500_.jpg'
    WHEN p.slug LIKE '%vapor-x5%' THEN 'https://m.media-amazon.com/images/I/71sKQ-3pYEL._AC_SL1500_.jpg'
    WHEN p.slug LIKE '%pre-jym%' THEN 'https://m.media-amazon.com/images/I/71lB9QbAWOL._AC_SL1500_.jpg'
    WHEN p.slug LIKE '%no-xplode%' THEN 'https://m.media-amazon.com/images/I/711KfXXqH+L._AC_SL1500_.jpg'
    WHEN p.slug LIKE '%evl-engn%' THEN 'https://m.media-amazon.com/images/I/71d2O4M9F0L._AC_SL1500_.jpg'
    WHEN p.slug LIKE '%impact-igniter%' THEN 'https://m.media-amazon.com/images/I/71TPeDiIbUL._AC_SL1500_.jpg'
    WHEN p.slug LIKE '%nitraflex%' THEN 'https://m.media-amazon.com/images/I/61+URvRVi4L._AC_SL1500_.jpg'
    -- Aminoácidos
    WHEN p.slug LIKE '%on-bcaa-5000%' THEN 'https://m.media-amazon.com/images/I/71FTAZUzMeL._AC_SL1500_.jpg'
    WHEN p.slug LIKE '%on-bcaa-1000%' THEN 'https://m.media-amazon.com/images/I/612GYuzfDQL._AC_SL1200_.jpg'
    WHEN p.slug LIKE '%alpha-amino%' THEN 'https://m.media-amazon.com/images/I/61DqLcC2bqL._AC_SL1500_.jpg'
    WHEN p.slug LIKE '%ghost-amino%' THEN 'https://m.media-amazon.com/images/I/61wklvUQn7L._AC_SL1500_.jpg'
    WHEN p.slug LIKE '%amino-build%' THEN 'https://m.media-amazon.com/images/I/71rpIWZvH4L._AC_SL1500_.jpg'
    WHEN p.slug LIKE '%grunt-eaa%' THEN 'https://m.media-amazon.com/images/I/61lrXhNF-TL._AC_SL1500_.jpg'
    WHEN p.slug LIKE '%aminocore%' THEN 'https://m.media-amazon.com/images/I/71Ct3u-dJSL._AC_SL1500_.jpg'
    WHEN p.slug LIKE '%on-glutamine%' THEN 'https://m.media-amazon.com/images/I/61LBwTX0THL._AC_SL1200_.jpg'
    WHEN p.slug LIKE '%bcaa-energy%' THEN 'https://m.media-amazon.com/images/I/71qPL2AqXnL._AC_SL1500_.jpg'
    WHEN p.slug LIKE '%post-jym%' THEN 'https://m.media-amazon.com/images/I/71ORJcDpkYL._AC_SL1500_.jpg'
    -- Ganadores de peso
    WHEN p.slug LIKE '%serious-mass-12lb%' THEN 'https://m.media-amazon.com/images/I/71QEOPq+jGL._AC_SL1500_.jpg'
    WHEN p.slug LIKE '%serious-mass-6lb%' THEN 'https://m.media-amazon.com/images/I/71FWA-LZKQL._AC_SL1500_.jpg'
    WHEN p.slug LIKE '%super-mass%' THEN 'https://m.media-amazon.com/images/I/81jJFFZpGRL._AC_SL1500_.jpg'
    WHEN p.slug LIKE '%true-mass%' THEN 'https://m.media-amazon.com/images/I/71j7yxQnwjL._AC_SL1500_.jpg'
    WHEN p.slug LIKE '%mass-tech%' THEN 'https://m.media-amazon.com/images/I/71g4F5rCG5L._AC_SL1500_.jpg'
    WHEN p.slug LIKE '%real-gains%' THEN 'https://m.media-amazon.com/images/I/71OY3e0LZRL._AC_SL1500_.jpg'
    -- Quemadores
    WHEN p.slug LIKE '%super-hd%' THEN 'https://m.media-amazon.com/images/I/71P6aRR48-L._AC_SL1500_.jpg'
    WHEN p.slug LIKE '%hydroxycut%' THEN 'https://m.media-amazon.com/images/I/71+VBHJmn5L._AC_SL1500_.jpg'
    WHEN p.slug LIKE '%ghost-burn%' THEN 'https://m.media-amazon.com/images/I/61TQzNfVlmL._AC_SL1500_.jpg'
    WHEN p.slug LIKE '%double-tap%' THEN 'https://m.media-amazon.com/images/I/71e3s5CtO4L._AC_SL1500_.jpg'
    WHEN p.slug LIKE '%leanmode%' THEN 'https://m.media-amazon.com/images/I/71+mddRk7RL._AC_SL1500_.jpg'
    WHEN p.slug LIKE '%on-l-carnitine%' THEN 'https://m.media-amazon.com/images/I/61C3n9QQDYL._AC_SL1200_.jpg'
    WHEN p.slug LIKE '%liquid-carnitine%' THEN 'https://m.media-amazon.com/images/I/61CvSXAFP3L._AC_SL1500_.jpg'
    WHEN p.slug LIKE '%jetfuel%' THEN 'https://m.media-amazon.com/images/I/71yAhxP7JpL._AC_SL1500_.jpg'
    -- Vitaminas
    WHEN p.slug LIKE '%opti-men%' THEN 'https://m.media-amazon.com/images/I/71hFw4qA3lL._AC_SL1500_.jpg'
    WHEN p.slug LIKE '%opti-women%' THEN 'https://m.media-amazon.com/images/I/71l1JyX+N-L._AC_SL1500_.jpg'
    WHEN p.slug LIKE '%animal-pak%' THEN 'https://m.media-amazon.com/images/I/71hvJOMNtcL._AC_SL1500_.jpg'
    WHEN p.slug LIKE '%fish-oil%' THEN 'https://m.media-amazon.com/images/I/71C4d7b+k0L._AC_SL1500_.jpg'
    WHEN p.slug LIKE '%vitamin-d%' THEN 'https://m.media-amazon.com/images/I/71QihWnHqPL._AC_SL1500_.jpg'
    WHEN p.slug LIKE '%vitamode%' THEN 'https://m.media-amazon.com/images/I/71rMBKhRDbL._AC_SL1500_.jpg'
    WHEN p.slug LIKE '%vitastack%' THEN 'https://m.media-amazon.com/images/I/71j8Kxf8lkL._AC_SL1500_.jpg'
    WHEN p.slug LIKE '%zma%' THEN 'https://m.media-amazon.com/images/I/71P4P4gPm8L._AC_SL1500_.jpg'
    -- Salud
    WHEN p.slug LIKE '%collagen%' THEN 'https://m.media-amazon.com/images/I/61nNn3FHfAL._AC_SL1500_.jpg'
    WHEN p.slug LIKE '%omega3%' THEN 'https://m.media-amazon.com/images/I/71N3PxZjciL._AC_SL1500_.jpg'
    WHEN p.slug LIKE '%probiotic%' THEN 'https://m.media-amazon.com/images/I/71BDMqF2t1L._AC_SL1500_.jpg'
    WHEN p.slug LIKE '%animal-flex%' THEN 'https://m.media-amazon.com/images/I/71f5l0+z8TL._AC_SL1500_.jpg'
    -- Accesorios
    WHEN p.slug LIKE '%shaker-on%' THEN 'https://m.media-amazon.com/images/I/61aGOXXKFRL._AC_SL1500_.jpg'
    WHEN p.slug LIKE '%ghost-shaker%' THEN 'https://m.media-amazon.com/images/I/61D4sVrCxCL._AC_SL1500_.jpg'
    WHEN p.slug LIKE '%redcon1-shaker%' THEN 'https://m.media-amazon.com/images/I/61bPBq+u+9L._AC_SL1500_.jpg'
    WHEN p.slug LIKE '%guantes%' THEN 'https://m.media-amazon.com/images/I/71cqVjMBURL._AC_SL1500_.jpg'
    ELSE 'https://images.unsplash.com/photo-1593095948071-474c5cc2989d?w=600'
  END,
  p.name || ' - Imagen principal',
  0,
  true
FROM products p
WHERE NOT EXISTS (SELECT 1 FROM product_images pi WHERE pi.product_id = p.id);
